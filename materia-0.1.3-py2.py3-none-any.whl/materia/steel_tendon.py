# Standard library imports
import inspect
import math
from dataclasses import dataclass

# Third party imports
import matplotlib.pyplot as plt

# Local applications imports


@dataclass
class SteelTendon:
    """
    Prestressing steel Class

    @param tensile_strength_fpk: Characteristic tensile strength of prestressing steel - [MPa]
    @param proof_strength_fp01k: Characteristic 0,1 % proof-stress of prestressing steel - [MPa]
    @param young_modulus_ep: Design value of modulus of elasticity of prestressing steel - [MPa]
    @param gamma_s: Partial factor for reinforcing or prestressing steel - [-]
    """

    tensile_strength_fpk: float = 1860
    proof_strength_fp01k: float = 1640
    young_modulus_ep: int = 195_000
    diagram_type: str = "uls_slope"
    gamma_s: float = 1.15

    def __post_init__(self):
        self.diagram_type = self.diagram_type.lower()
        self.tuple_diagram_type = ("elastic", "uls_slope", "uls_horizontal")
        self.ensure_valid_diagram_type()

    def ensure_valid_diagram_type(self):
        if not self.is_diagram_type_valid():
            raise ValueError(f"Diagram type mismatch: [{self.tuple_diagram_type}]")

    def is_diagram_type_valid(self) -> bool:
        return self.diagram_type in self.tuple_diagram_type

    @property
    def fpd(self) -> float:
        return self.proof_strength_fp01k / self.gamma_s

    @property
    def epsilon_ud(self):
        if self.diagram_type == self.tuple_diagram_type[0]:
            return 1
        elif self.diagram_type == self.tuple_diagram_type[1]:
            return 2 / 100
        elif self.diagram_type == self.tuple_diagram_type[2]:
            return 10 / 100
        else:
            return None

    @property
    def epsilon_uk(self):
        return self.epsilon_ud / 0.9

    @property
    def _epsilon_pd(self) -> float:
        if self.diagram_type == self.tuple_diagram_type[0]:
            return self.epsilon_ud
        else:
            return self.fpd / self.young_modulus_ep

    @property
    def ductility(self) -> float:
        """
        Return the ratio of the tensile strength over the proof strength
        """
        return self.tensile_strength_fpk / self.proof_strength_fp01k

    @property
    def slope(self) -> float:
        """
        Returns the post-elastic slope of the EC2 strain / stress diagram.
        """
        if self.diagram_type == self.tuple_diagram_type[1]:
            slope = (self.fpd * (self.ductility - 1)) / (
                self.epsilon_uk
                - self.proof_strength_fp01k / (self.gamma_s * self.young_modulus_ep)
            )
        else:
            slope = 0.0
        return slope

    def set_gamma_s(self, gamma_s: float) -> None:
        self.gamma_s = gamma_s
        return None

    def set_tensile_strength_fpk(self, tensile_strength_fpk: float) -> None:
        self.tensile_strength_fpk = tensile_strength_fpk
        return None

    def set_proof_strength_fp01k(self, proof_strength_fp01k: float) -> None:
        self.proof_strength_fp01k = proof_strength_fp01k
        return None

    def set_young_modulus(self, young_modulus: int) -> None:
        self.young_modulus_ep = young_modulus
        return None

    def set_diagram_type(self, diagram_type: str) -> None:
        self.diagram_type = diagram_type.lower()
        self.ensure_valid_diagram_type()
        return None

    def get_stress(self, epsilon) -> float:
        """
        Returns the stress in the materials for the given strain, according to the diagram type.
        """
        return self.diagram_steel_ec2(epsilon)

    def diagram_steel_ec2(self, epsilon: float) -> float:
        """
        Design stress-strain diagram for prestressing steel with inclined
        or horizontal post-elastic top branch, according to EC2 §3.

        @param epsilon:  The strain in the prestressing steel - [-]
        @return: The stress level in prestressing tendon - [MPa]
        """
        if epsilon < -self.epsilon_ud:
            return 0
        elif epsilon < -self._epsilon_pd:
            return -self.fpd - (-epsilon - self._epsilon_pd) * self.slope
        elif epsilon < 0.0:
            return epsilon * self.young_modulus_ep
        elif epsilon < self._epsilon_pd:
            return epsilon * self.young_modulus_ep
        elif epsilon <= self.epsilon_ud:
            return self.fpd + (epsilon - self._epsilon_pd) * self.slope
        else:
            return 0

    def relaxation(self, relax_class=2, t_hours=500_000, mu=0.75) -> float:
        """
        Calculation of the losses due to the relaxation of the prestressing steel

        @param relax_class: class of relaxation [1; 2; 3]
        @param t_hours: is the time after tensioning - [hours]
        @param mu: σpi / fpk - [-]
        @return: Relaxation losses - [MPa]
        """
        index = relax_class - 1
        ro_1000_tuple = (8.0, 2.5, 4.0)
        k1_tuple = (5.39, 0.66, 1.98)
        k2_tuple = (6.7, 9.1, 8.0)

        ro_1000 = ro_1000_tuple[index]
        k1 = k1_tuple[index]
        k2 = k2_tuple[index]

        relax = (
            k1
            * ro_1000
            * math.exp(k2 * mu)
            * (t_hours / 1000) ** (0.75 * (1 - mu))
            * 10 ** (-5)
            * (mu * self.tensile_strength_fpk)
        )

        return relax

    def build_curve(
        self,
        initial_strain: float | None = None,
        final_strain: float | None = None,
    ):
        """
        Prints the strain / stress curve according to the selected diagram type.
        """
        if initial_strain == None:
            initial_strain = -self.epsilon_uk
        if final_strain == None:
            final_strain = self.epsilon_uk

        strain = []
        stress = []
        epsilon = initial_strain

        while epsilon <= final_strain:
            strain.append(epsilon)
            stress.append(self.get_stress(epsilon))
            epsilon += 0.0001

        return strain, stress

    def plot_curve(
        self, initial_strain: float | None = None, final_strain: float | None = None
    ):
        """
        Prints the strain / stress curve according to the selected diagram type.
        """
        strain, stress = self.build_curve(initial_strain, final_strain)

        fig, cb_strain_stress = plt.subplots()
        cb_strain_stress.plot(strain, stress)
        cb_strain_stress.set(
            xlabel="Déformation [‰]",
            ylabel="Contrainte [MPa]",
            title="Loi contrainte / déformation",
        )
        cb_strain_stress.grid()
        plt.show

        return None

    def __str__(self) -> str:
        instance_name = [
            k for k, v in inspect.currentframe().f_back.f_locals.items() if v is self
        ][0]
        result = f"Material Definition - Steel Tendon:  {instance_name}\n"
        result += f"\tCharacteristic tensile strength of prestressing steel: fpk = {self.tensile_strength_fpk} MPa\n"
        result += f"\tCharacteristic 0,1% proof-stress of prestressing steel: fp01k = {self.proof_strength_fp01k} MPa\n"
        result += f"\tYoung modulus: Ep = {round(self.young_modulus_ep/1000, 1)} GPa\n"
        return result


if __name__ == "__main__":
    tendon = SteelTendon()
    tendon.plot_curve()
