# Nom du fichier:   constantes.py
"""Module des constantes de l'EC2 relatives aux matériaux
"""

# Compression limite pour le béton [MPa]
C_MIN = 12
C_MAX = 90

# Situations et définition Coefficients partiels sur les matériaux
SITUATIONS = {
    'Transitoire': [1.5, 1.15, 1.15],
    'Durable': [1.5, 1.15, 1.15],
    'Accidentelle': [1.2, 1, 1],
    'Sismique': [1.3, 1, 1],
    'Custom': [1, 1, 1],
}

# Coefficients partiels sur les matériaux
GAMMA_C, GAMMA_S, GAMMA_P = SITUATIONS['Durable']

# Coefficients à long terme en compression et en traction
ALPHA_C = 1
ALPHA_CT = 1

# Coefficient pour les instabilités
GAMMA_CE = 1.2

# Types de ciments autorisés
TYPE_CIMENT_EC2 = ['N', 'R', 'S']

# Clé pour le coefficient s (évolution temporelle)
S_EC2 = {'S': 0.38, 'N': 0.25, 'R': 0.2}

# clé pour le coefficient alpha (fluage)
ALPHA_EC2 = {'S': -1, 'N': 0, 'R': 1}
ALPHA_CREEP = {"S": -1, "N": 0, "R": 1}

# clé pour le coefficient alpha_ds (retrait)
ALPHA_DS_1 = {"S": 3, "N": 4, "R": 6}
ALPHA_DS_2 = {"S": 0.13, "N": 0.12, "R": 0.11}

# Coefficient sc eq(3.2)
SC_FACTOR = {"S": 0.38, "N": 0.25, "R": 0.2}

# Masse volumique de l'acier et du béton [kg/m3]
RHO_S = 7850
RHO_C = 2500

# Module d'élasticité de l'acier passif [MPa]
ES = 200_000


EPSILON = 1e-9
