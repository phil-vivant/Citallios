# Standard library imports
import inspect
import math
from math import isclose
from dataclasses import dataclass

# Third party imports
import hvplot
import matplotlib.pyplot as plt

# Local applications imports


@dataclass
class SteelRebar:
    """
    Reinforcing steel Class

    @param ductility_class: Ductility class of the reinforcing steel - ['A', 'B', 'C', 'H', 'F']
            with:   ['A', 'B', 'C']     Ductility class according EN 1992-1-1 Annex C
                    ['H']               Design stress-strain diagram with horizontal post-elastic top branch
                    ['F']               Design stress-strain diagram according BAEL91-99
    @param yield_strength_fyk: Characteristic value of yield strength of reinforcement - [MPa]
    @param young_modulus_es: Design value of modulus of elasticity of ordinary reinforcing steel - [MPa]
    @param diagram_type: Type of stress / strain diagram, with :
                ['sls']                   Perfectly elastic stress-strain diagram (no limit !)
                ['uls']                   ULS design stress-strain diagram
    @param tension_only:
                [True]      No compression taken into account
                [False]     Compression in the steel (default value)
    @param gamma_s: Partial factor for reinforcing or prestressing steel - [-]
    """

    ductility_class: str = "B"
    yield_strength_fyk: float = 500
    young_modulus_es: int = 200_000
    diagram_type: str = "uls"
    tension_only: bool = False
    gamma_s: float = 1.15

    def __post_init__(self):
        self.diagram_type = self.diagram_type.lower()
        self.tuple_ductility = ("A", "B", "C", "H", "F")
        self.dico_epsilon_uk = {
            "A": 2.5 / 100,
            "B": 5 / 100,
            "C": 7.5 / 100,
            "H": 10 / 90,
            "F": 1 / 90,
        }
        self.dico_k_param = {"A": 1.05, "B": 1.08, "C": 1.15, "H": 1, "F": 1}
        self.tuple_diagram_type = ("sls", "uls")

        self.ensure_valid_ductility()
        self.ensure_valid_diagram_type()

    def ensure_valid_ductility(self):
        if not self.is_ductility_valid():
            raise ValueError(f"Ductility class mismatch: [{self.tuple_ductility}]")

    def is_ductility_valid(self) -> bool:
        return self.ductility_class in self.tuple_ductility

    def ensure_valid_diagram_type(self):
        if not self.is_diagram_type_valid():
            raise ValueError(f"Diagram type mismatch: [{self.tuple_diagram_type}]")

    def is_diagram_type_valid(self) -> bool:
        return self.diagram_type in self.tuple_diagram_type

    @property
    def epsilon_uk(self) -> float:
        if self.diagram_type == self.tuple_diagram_type[0]:
            return 1.0
        return self.dico_epsilon_uk.get(str(self.ductility_class))

    @property
    def epsilon_ud(self) -> float:
        return self.epsilon_uk * 0.9

    @property
    def k_param(self) -> float:
        return self.dico_k_param.get(str(self.ductility_class))

    @property
    def fyd(self) -> float:
        if self.diagram_type == self.tuple_diagram_type[0]:
            return self.epsilon_ud * self.young_modulus_es
        return self.yield_strength_fyk / self.gamma_s

    @property
    def epsilon_yd(self) -> float:
        return self.fyd / self.young_modulus_es

    @property
    def slope(self) -> float:
        slope = (self.fyd * (self.k_param - 1)) / (
            self.epsilon_uk
            - self.yield_strength_fyk / (self.gamma_s * self.young_modulus_es)
        )
        return slope

    def set_gamma_s(self, gamma_s: float) -> None:
        """
        Modifies the partial coefficient gamma_s (default value is 1.15).
        """
        self.gamma_s = gamma_s
        return None

    def set_ductility_class(self, ductility_class: str) -> None:
        """
        Modifies the ductility class of the steel (default value is 'B').
        @param ductility_class: Ductility class of the reinforcing steel - ['A', 'B', 'C', 'H', 'F']
        with:   ['A', 'B', 'C']     Ductility class according EN 1992-1-1 Annex C
                ['H']               Design stress-strain diagram with horizontal post-elastic top branch
                ['F']               Design stress-strain diagram according BAEL91-99
        """
        self.ductility_class = ductility_class.upper()
        self.ensure_valid_ductility()
        return None

    def set_fyk(self, fyk: float) -> None:
        """
        Modifies yield strength (default value is 500 MPa).
        """
        self.yield_strength_fyk = fyk
        return None

    def set_young_modulus(self, young_modulus: int) -> None:
        """
        Modifies the young modulus (default value is 200 000 MPa).
        """
        self.young_modulus_es = young_modulus
        return None

    def set_diagram_type(self, diagram_type: str) -> None:
        """
        Modifies the diagram type of the steel (default value is 'uls').
        @param diagram_type:    Type of stress / strain diagram, with :
                    ['sls'] Perfectly elastic stress-strain diagram (no limit !)
                    ['uls'] ULS design stress-strain diagram
        """
        self.diagram_type = diagram_type.lower()
        self.ensure_valid_diagram_type()
        return None

    def set_tension_only(self, tension_only: bool) -> None:
        """
        Modifies the tension only parameter (default value is 'False').
        @param tension_only: Boolean :
            [True]        The steel develop no compression
            [False]       The steel can work either in tension or compression
        """
        self.tension_only = tension_only
        return None

    def get_stress(self, epsilon) -> float:
        """
        Returns the stress in the materials for the given strain, according to
        the diagram type.
        """
        return self.diagram_steel_ec2(epsilon)

    def diagram_steel_ec2(self, epsilon: float) -> float:
        """
        Design stress-strain diagram for reinforcement steel with inclined
        or horizontal post-elastic top branch, according to EC2 §3.

        @param epsilon:  The strain in the prestressing steel - [-]
        @return: The stress level in the reinforcement steel - [MPa]
        """
        if isclose(epsilon, -self.epsilon_ud):
            return -self.fyd - (-epsilon - self.epsilon_yd) * self.slope
        elif epsilon < -self.epsilon_ud:
            return 0
        elif epsilon < -self.epsilon_yd:
            return -self.fyd - (-epsilon - self.epsilon_yd) * self.slope
        elif epsilon < 0.0:
            return epsilon * self.young_modulus_es
        elif epsilon < self.epsilon_yd:
            return epsilon * self.young_modulus_es * (1 - self.tension_only)
        elif epsilon <= self.epsilon_ud:
            return (self.fyd + (epsilon - self.epsilon_yd) * self.slope) * (
                1 - self.tension_only
            )
        elif isclose(epsilon, self.epsilon_ud):
            return (self.fyd + (epsilon - self.epsilon_yd) * self.slope) * (
                1 - self.tension_only
            )
        else:
            return 0

    def build_curve(
        self,
        initial_strain: float | None = None,
        final_strain: float | None = None,
    ):
        """
        Build the strain / stress curve according to the selected diagram type.
        """
        if initial_strain == None:
            initial_strain = -self.epsilon_uk
        if final_strain == None:
            final_strain = self.epsilon_uk

        strain = []
        stress = []
        epsilon = initial_strain

        while epsilon <= final_strain:
            strain.append(epsilon)
            stress.append(self.get_stress(epsilon))
            epsilon += 0.0001

        return strain, stress

    def plot_curve(
        self,
        initial_strain: float | None = None,
        final_strain: float | None = None,
    ):
        """
        Prints the strain / stress curve according to the selected diagram type.
        """
        strain, stress = self.build_curve(initial_strain, final_strain)

        fig, cb_strain_stress = plt.subplots()
        cb_strain_stress.plot(strain, stress)
        cb_strain_stress.set(
            xlabel="Déformation [‰]",
            ylabel="Contrainte [MPa]",
            title="Loi contrainte / déformation",
        )
        cb_strain_stress.grid()
        plt.show

        return None

    def __str__(self) -> str:
        instance_name = [
            k for k, v in inspect.currentframe().f_back.f_locals.items() if v is self
        ][0]
        Es = round(self.young_modulus_es/1000, 1)
        result = f"Material Definition - Steel Rebar:  {instance_name}\n"
        result += f"\tDuctility Class: { self.ductility_class}\n"
        result += f"\tDiagram Type: {self.diagram_type}\n"
        result += f"\tYield Strength: fyk = {self.yield_strength_fyk} MPa\n"
        result += f"\tYoung modulus: Es = {Es} GPa\n"
        return result


if __name__ == "__main__":
    B500B = SteelRebar()
    B500B.plot_curve()
