# Standard library imports
import inspect
import math
from math import isclose
from dataclasses import dataclass

# Third party imports
import hvplot
import matplotlib.pyplot as plt

# Local applications imports
from materia.constantes import *


DUCTILITY_CLASS = ("A", "B", "C", "H", "F")
EPSILON_UK = {
    "A": 2.5 / 100,
    "B": 5 / 100,
    "C": 7.5 / 100,
    "H": 10 / 90,
    "F": 1 / 90,
}
K_PARAM = {"A": 1.05, "B": 1.08, "C": 1.15, "H": 1, "F": 1}
EPSILON = 1e-9



def ensure_valid_ductility(ductility_class: str) -> None:
    if not is_ductility_valid(ductility_class.upper()):
        raise ValueError(f"Ductility class mismatch: [{DUCTILITY_CLASS}]")


def is_ductility_valid(ductility_class: str) -> bool:
    return ductility_class in DUCTILITY_CLASS


def epsilon_uk(ductility_class: str) -> float:
    ensure_valid_ductility(ductility_class)
    return EPSILON_UK.get(str(ductility_class.upper()))


def epsilon_ud(ductility_class: str) -> float:
    ensure_valid_ductility(ductility_class)
    return 0.9 * epsilon_uk(ductility_class.upper())


def k_param(ductility_class: str) -> float:
    ensure_valid_ductility(ductility_class)
    return K_PARAM.get(str(ductility_class.upper()))


def fyd(fyk: float, gamma_s: float|None=None) -> float:
    if gamma_s == None:
        gamma_s = GAMMA_S
    return fyk / gamma_s


def epsilon_yd(fyk: float, gamma_s: float, young_modul: float) -> float:
    return fyd(fyk, gamma_s) / young_modul


def steel_uls_diagram_points(
        fyk: float,
        ductility_class: str,
        gamma_s: float,
        young_modul: float,
        tension_only: bool=False,
) -> tuple[list[float]]:
    """Construction des points du diagramme ELU contrainte / Déformations.

    Args:
        fyk (float):            Limite élastique de l'acier
        ductility (str):        Classe de ductilité de l'acier parmi:
                                    ["A", "B", "C", "H", "F"]
        gamma_s (float):        Coefficient partiel
        young_modul (float):    Module d'Young de l'acier
        tension_only (bool, optional):  Compression de l'acier négligée ?
                                        Defaults to False.

    Returns:
        tuple[list[float]]: epsilons [eps_0, eps_1...], sigmas [sig_0, sig_1...]
    """
    ductility = ductility_class.upper()
    ensure_valid_ductility(ductility)
    _fyd = fyd(fyk, gamma_s)
    eps_yd = epsilon_yd(fyk, gamma_s, young_modul)
    k = k_param(ductility)
    eps_uk = epsilon_uk(ductility)
    eps_ud = epsilon_ud(ductility)
    fud = _fyd * (1 + (k - 1) * (eps_ud - eps_yd) / (eps_uk - eps_yd))

    epsilons = [-eps_ud - EPSILON, -eps_ud, -eps_yd, 0]
    sigmas = [0, -fud, -_fyd, 0]

    if not tension_only:
        epsilons_add = [eps_yd, eps_ud, eps_ud + EPSILON]
        sigmas_add = [_fyd, fud, 0]
        epsilons += epsilons_add
        sigmas += sigmas_add

    return epsilons, sigmas


def steel_sls_diagram_points(
        young_modul: float,
        tension_only: bool=False,
) -> tuple[list[float]]:
    """Construction des points du diagramme ELU contrainte / Déformations.

    Args:
        young_modul (float): Module d'Young de l'acier.
        tension_only (bool, optional):  Compression de l'acier négligée ?
                                        Defaults to False.

    Returns:
        tuple[list[float]]: epsilons [eps_0, eps_1...], sigmas [sig_0, sig_1...]
    """
    epsilon_max = 1
    sigma_max = epsilon_max * young_modul
    epsilons = [-epsilon_max - EPSILON, -epsilon_max, 0]
    sigmas = [0, -sigma_max, 0]

    if not tension_only:
        epsilons_comp = [epsilon_max, epsilon_max + EPSILON]
        sigmas_comp = [sigma_max, 0]
        epsilons += epsilons_comp
        sigmas += sigmas_comp

    return epsilons, sigmas
