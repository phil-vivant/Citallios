# Standard library imports
import inspect
import math
from math import isclose
from dataclasses import dataclass

# Third party imports
import hvplot
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Local applications imports
import materia.steel_laws as sl

@dataclass
class SteelRebar:
    """
    Reinforcing steel Class

    @param ductility_class: Ductility class of the reinforcing steel - ['A', 'B', 'C', 'H', 'F']
            with:   ['A', 'B', 'C']     Ductility class according EN 1992-1-1 Annex C
                    ['H']               Design stress-strain diagram with horizontal post-elastic top branch
                    ['F']               Design stress-strain diagram according BAEL91-99
    @param yield_strength_fyk: Characteristic value of yield strength of reinforcement - [MPa]
    @param young_modulus_es: Design value of modulus of elasticity of ordinary reinforcing steel - [MPa]
    @param diagram_type: Type of stress / strain diagram, with :
                ['sls']                   Perfectly elastic stress-strain diagram (no limit !)
                ['uls']                   ULS design stress-strain diagram
    @param tension_only:
                [True]      No compression taken into account
                [False]     Compression in the steel (default value)
    @param gamma_s: Partial factor for reinforcing or prestressing steel - [-]
    """

    name: str|None=None
    ductility_class: str = "B"
    fyk: float = 500
    young_modulus_es: int = 200_000
    tension_only: bool = False
    gamma_s: float = 1.15

    def __post_init__(self):
        self.ductility_class = self.ductility_class.upper()
        self.ensure_valid_ductility()
        self.name = self._name()
        self.uls_strains, self.uls_stresses = None, None
        self.sls_strains, self.sls_stresses = None, None
        self.update_uls_diagram_points()
        self.update_sls_diagram_points()

    def _name(self) -> str:
        if self.name == "" or self.name == None:
            if self.ductility_class == "F":
                return f"FE{self.fyk}"
            return f"B{int(self.fyk)}{self.ductility_class}"
        return self.name

    def ensure_valid_ductility(self):
        if not self.is_ductility_valid():
            raise ValueError(f"Ductility class mismatch: [{sl.DUCTILITY_CLASS}]")

    def is_ductility_valid(self) -> bool:
        return self.ductility_class in sl.DUCTILITY_CLASS

    def update_uls_diagram_points(self) -> None:
        self.uls_strains, self.uls_stresses = sl.steel_uls_diagram_points(
            fyk=self.fyk,
            ductility_class=self.ductility_class,
            gamma_s=self.gamma_s,
            young_modul=self.young_modulus_es,
            tension_only=self.tension_only
        )
        return None

    def update_sls_diagram_points(self) -> None:
        self.sls_strains, self.sls_stresses = sl.steel_sls_diagram_points(
            young_modul=self.young_modulus_es,
            tension_only=self.tension_only,
        )
        return None

    def set_gamma_s(self, gamma_s: float) -> None:
        """
        Modifies the partial coefficient gamma_s (default value is 1.15).
        """
        self.gamma_s = gamma_s
        self.update_uls_diagram_points()
        return None

    def set_ductility_class(self, ductility_class: str) -> None:
        """
        Modifies the ductility class of the steel (default value is 'B').
        @param ductility_class: Ductility class of the reinforcing steel - ['A', 'B', 'C', 'H', 'F']
        with:   ['A', 'B', 'C']     Ductility class according EN 1992-1-1 Annex C
                ['H']               Design stress-strain diagram with horizontal post-elastic top branch
                ['F']               Design stress-strain diagram according BAEL91-99
        """
        self.ductility_class = ductility_class.upper()
        self.ensure_valid_ductility()
        self.update_uls_diagram_points()
        return None

    def set_fyk(self, fyk: float) -> None:
        """
        Modifies yield strength (default value is 500 MPa).
        """
        self.fyk = fyk
        self.update_uls_diagram_points()
        return None

    def set_young_modulus(self, young_modulus: int) -> None:
        """
        Modifies the young modulus (default value is 200 000 MPa).
        """
        self.young_modulus_es = young_modulus
        self.update_uls_diagram_points()
        self.update_sls_diagram_points()
        return None

    def set_tension_only(self, tension_only: bool) -> None:
        """
        Modifies the tension only parameter (default value is 'False').
        @param tension_only: Boolean :
            [True]        The steel develop no compression
            [False]       The steel can work either in tension or compression
        """
        self.tension_only = tension_only
        self.update_uls_diagram_points()
        self.update_sls_diagram_points()
        return None

    def uls_stress(self, epsilon: float) -> float:
        """
        Returns the uls stress in the material for the given strain.
        """
        return np.interp(
            epsilon, self.uls_strains, self.uls_stresses, left=0, right=0,
        )

    def sls_stress(self, epsilon: float) -> float:
        """
        Returns the sls stress in the material for the given strain.
        """
        return np.interp(
            epsilon, self.sls_strains, self.sls_stresses, left=0, right=0,
        )

    def get_stress(self, epsilon: float, type:str="uls") -> float:
        """
        Returns the stress in the material for the given strain, according to
        the diagram type.
        """
        type = type.lower()
        if type == "sls":
            return self.sls_stress(epsilon)
        if type == "uls":
            return self.uls_stress(epsilon)

    def plot_curve(
        self, type: str="uls"
    ):
        """
        Prints the strain / stress curve according to the selected diagram type.
        """
        if type.lower() == "sls":
            strain, stress = self.sls_strains, self.sls_stresses
        if type.lower() == "uls":
            strain, stress = self.uls_strains, self.uls_stresses

        strain = [x * 1e3 for x in strain]
        df = pd.DataFrame({
            "strain": strain,
            "stress": stress,
        })
        strain_min, strain_max = min(strain), max(strain)
        sigma_min, sigma_max = min(stress), max(stress)

        fig = df.hvplot(
            width=500,
            xlim=(strain_min-1, strain_max+1),
            ylim=(sigma_min, sigma_max+1),
            x="strain",
            y="stress",
            xlabel="Déformation [‰]",
            ylabel="Contrainte [MPa]",
            title=f"{self.name} - Loi contrainte / déformation - {type.upper()}",
        )
        return fig

    def plot_curve_old(self, type: str="uls",) -> None:
        """
        Prints the strain / stress curve according to the selected diagram type.
        """
        if type.lower() == "sls":
            strain, stress = self.sls_strains, self.sls_stresses
        if type.lower() == "uls":
            strain, stress = self.uls_strains, self.uls_stresses

        strain = [x * 1e3 for x in strain]

        fig, cb_strain_stress = plt.subplots()
        cb_strain_stress.plot(strain, stress)
        cb_strain_stress.set(
            xlabel="Déformation [‰]",
            ylabel="Contrainte [MPa]",
            title="Loi contrainte / déformation",
        )
        cb_strain_stress.grid()
        plt.show

        return None

    def __str__(self) -> str:
        Es = round(self.young_modulus_es/1000, 1)
        result = f"Material Definition - Steel Rebar:\n"
        result += f"\tName:\t\t{ self.name}\n"
        result += f"\tDuctility Class: { self.ductility_class}\n"
        result += f"\tYield Strength:\tfyk = {self.fyk: .1f} MPa\n"
        result += f"\tYoung modulus:\tEs =  {Es: .1f} GPa\n"
        return result

B500B = SteelRebar()
B500B.plot_curve()
