"""
Ce Package est une bibliothèque des matériaux de construction pour le calcul des structures.

Les matériaux suivants sont définis suivant le chapitre 3 de l'EN-1992-1-1:
    - Le béton (§3.1);
    - Les armatures de béton armé (§3.2);
    - Les armatures de précontrainte (§3.3);
    - Les armatures FRP, ou 'Fiber Reinforced Polymer' pour les matériaux carbones (définition générale).

Typical usage examples:
    - C35 = EC2Concrete(fck=35, diagram_type='uls_parabola')
    - C35_advanced = EC2AdvancedConcrete(fck=35, t_days=5000, cement='N')
    - B500B = SteelRebar(ductility_class='B', yield_strength_fyk=500)
    - Y1860 = SteelTendon(tensile_strength_fpk=1860, proof_strength_fp01k=1640)é
    - TFC = FibreReinforcedPolymer(modulus_elasticity_ef=200_000)

Les matériaux couramment utilisés sont déjà créés et peuvent être directement importés:
    - Les bétons pour les classes courantes:  C20 < -- < C60
    - Les aciers HA 500 MPa pour les différentes classes de ductilités (B500A, B500B, etc...)
    - Le TFC350 de Freyssinet
    - L'acier de précontrainte Y1860.
"""

__version__ = "0.1.3"


from materia.ec2_concrete_advanced import EC2AdvancedConcrete
from materia.ec2_concrete import EC2Concrete
from materia.fibre_reinforced_polymer import FibreReinforcedPolymer
from materia.steel_rebar import SteelRebar
from materia.steel_tendon import SteelTendon


C20 = EC2Concrete(fck=20)
C25 = EC2Concrete(fck=25)
C30 = EC2Concrete(fck=30)
C35 = EC2Concrete(fck=35)
C40 = EC2Concrete(fck=40)
C45 = EC2Concrete(fck=45)
C50 = EC2Concrete(fck=50)
C55 = EC2Concrete(fck=55)
C60 = EC2Concrete(fck=60)

B500A = SteelRebar(ductility_class="A")
B500B = SteelRebar(ductility_class="B")
B500C = SteelRebar(ductility_class="C")
B500H = SteelRebar(ductility_class="H")
FE500 = SteelRebar(ductility_class="F")

TFC_350 = FibreReinforcedPolymer(
    modulus_elasticity_ef=220_000,
    sigma_f_sls=1576,
    sigma_f_uls=1870,
)

Y1860 = SteelTendon()
