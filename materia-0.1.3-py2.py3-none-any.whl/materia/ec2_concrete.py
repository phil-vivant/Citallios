"""
EC2 Concrete Module.

Defines the concrete material in accordance with Eurocode 2 Part 1-1 § 3.1.
Based on characteristic compressive strength and other optional parameters,
defines all the properties and behavior of the concrete.
Advanced behavior (creep, shrinkage) of concrete material is coverd by the
EC2AdvancedConcrete class.
"""

# Standard library imports
from dataclasses import dataclass

# Third party imports
import hvplot.pandas
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from rich import print

# Local applications imports
import materia.concrete_laws as cl



@dataclass
class EC2Concrete:
    """
    EC2 Concrete Class.

    Defines the concrete material in accordance with Eurocode 2 Part 1-1 § 3.1.
    Based on characteristic compressive strength and other optional parameters,
    defines all the properties and behavior of the concrete.
    Advanced behavior (creep, shrinkage) of concrete material is covered by the
    EC2AdvancedConcrete class.

    @param fck: Characteristic concrete cylinder compressive strength at age 28
                days - [MPa]
    @param name:    Name of the concrete material. If not specified, a default
                    value of type "CXX" is provided.
    @param uls_diagram_type:    Type of ULS stress / strain diagram among :
                                    ['sargin']
                                    ['parabola']
                                    ['rectangle']
                                    ['bi_linear']
    @param sls_tensile_strength:    Tensile strength used for the SLS Diagram
    @param gamma_c:     Partial factor for concrete - [-]
    @param phi_creep:   Creep coefficient - [-]
    """

    fck: float
    name: str=None
    uls_diagram_type: str = "parabola"
    sls_tensile_strength: float = 0
    gamma_c: float = 1.5
    phi_creep: float = 0.0

    def __post_init__(self):
        self.name = self._name()
        self.uls_diagram_type = self.uls_diagram_type.lower()
        cl.ensure_valid_uls_diagram_type(self.uls_diagram_type)
        self.uls_strains, self.uls_stresses = None, None
        self.sls_strains, self.sls_stresses = None, None
        self.update_uls_diagram_points()
        self.update_sls_diagram_points()

    def _name(self) -> str:
        if self.name == "" or self.name == None:
            return f"C{self.fck}"
        return self.name

    def update_uls_diagram_points(self) -> None:
        self.uls_strains, self.uls_stresses = cl.concrete_uls_diagram_points(
            fck=self.fck,
            diagram_type=self.uls_diagram_type,
            gamma_c=self.gamma_c,
            phi_creep=self.phi_creep
        )
        return None

    def update_sls_diagram_points(self) -> None:
        self.sls_strains, self.sls_stresses = cl.concrete_sls_diagram_points(
            young_modul=self.modul_Ec_eff,
            tensile_strength=self.sls_tensile_strength,
        )
        return None

    @property
    def fcm(self) -> float:
        """
        Mean compressive strenght of concrete at 28 days
        [EN 1992-1-1 - Table 3.1].
        """
        return cl.fcm(self.fck)

    @property
    def fcd(self) -> float:
        """
        Concrete design compressive strength [EN 1992-1-1 - §3.1.6 (1)P].
        """
        return cl.fcd(self.fck, self.gamma_c)

    @property
    def fctm(self) -> float:
        """
        Mean axial tensile strength [EN 1992-1-1 - Table 3.1].
        """
        return cl.fctm(self.fck)

    @property
    def fctk_005(self) -> float:
        """
        Characteristic axial tensile strength of concrete - 5 % fractile
        [EN 1992-1-1 - Table 3.1].
        """
        return cl.fctk_005(self.fck)

    @property
    def fctk_095(self) -> float:
        """
        Characteristic axial tensile strength of concrete - 95 % fractile
        [EN 1992-1-1 - Table 3.1].
        """
        return cl.fctk_095(self.fck)

    @property
    def fctd(self) -> float:
        """
        Design tensile strength [EN 1992-1-1 - §3.1.6 (2)P].
        """
        return cl.fctd(self.fck, self.gamma_c)

    @property
    def nu_eq_6N(self) -> float:
        """
        Strength reduction factor for concrete cracked due shear
        [EN 1992-1-1 - 6.2.1 (6) - eq (6N)].
        """
        return cl.nu_eq_66N(self.fck)

    @property
    def nu1_eq_69(self) -> float:
        """
        Strength reduction factor for concrete cracked due shear
        [EN 1992-1-1 - 6.2.3 (3) - eq (6.9)].
        """
        return cl.nu1_eq_69(self.fck)

    @property
    def modul_Ecm(self) -> float:
        """
        Secant modulus of elasticity of concrete [EN 1992-1-1 - Table 3.1].
        """
        return cl.modul_Ecm(self.fck)

    @property
    def modul_Ec_eff(self) -> float:
        """
        Effective modulus of elasticity of concrete accounting for creep
        deformations [EN 1992-1-1 - eq (7.20)].
        """
        return cl.modul_Ec_eff(self.fck, self.phi_creep)

    @property
    def modul_Ecd(self) -> float:
        """
        Design value of the modulus of elasticity of concrete accounting for
        creep deformations [EN 1992-1-1 - eq (5.20)].
        """
        return cl.modul_Ecd(self.fck)

    @property
    def modul_Ecd_eff(self) -> float:
        """
        Design effective modulus of elasticity of concrete accounting for creep
        deformations [EN 1992-1-1 - eq (5.27)].
        """
        return cl.modul_Ecd_eff(self.fck, self.phi_creep)

    @property
    def modul_Etan_0(self) -> float:
        if self.uls_diagram_type == cl.ULS_DIAGRAM_TYPE[0]:
            return 1.05 * self.modul_Ecd_eff
        if self.uls_diagram_type == cl.ULS_DIAGRAM_TYPE[1]:
            return self.fcd * cl.n_2(self.fck) / self.epsilon_c
        return 0

    @property
    def epsilon_c(self) -> float:
        """
        Returns the compressive strain in the concrete at the peak stress fc,
        according to the diagram type
        """
        return cl.epsilon_c(self.fck, self.uls_diagram_type)

    @property
    def epsilon_cu(self) -> float:
        """
        Returns the ultimate compressive strain in the concrete, according to
        the diagram type
        """
        return cl.epsilon_cu(self.fck, self.uls_diagram_type)

    def set_gamma_c(self, gamma_c: float) -> None:
        """Modifies the partial coefficient gamma_c (default value is 1.5).

        Args:
            gamma_c (float):    Partial factor for concrete.

        Returns:
            None:   No comment.
        """
        self.gamma_c = gamma_c
        self.update_uls_diagram_points()
        return None

    def set_phi_creep(self, phi_creep: float) -> None:
        """Modifies the creep coefficient (default value is 0.).

        Args:
            phi_creep (float):  Crrep coefficient.

        Returns:
            None:   No comment.
        """
        self.phi_creep = phi_creep
        self.update_sls_diagram_points()
        self.update_uls_diagram_points()
        return None

    def set_uls_diagram_type(self, diagram_type: str) -> None:
        """Modifies the ULS diagram type of the concrete.

        Args:
            diagram_type (str): Type of stress / strain diagram, with :
                                    ['sargin']
                                    ['parabola']
                                    ['rectangle']
                                    ['bi_linear']                           

        Returns:
            None:   No comment.
        """
        self.uls_diagram_type = diagram_type.lower()
        cl.ensure_valid_uls_diagram_type(diagram_type)
        self.update_uls_diagram_points()
        return None

    def set_sls_tensile_strength(self, sigma_lim: float) -> None:
        """Modifies the tensile strength for the SLS Diagram.

        The tensile limit strength be negative. Otherwise, it is neglected.

        Args:
            sigma_lim (float):  New tensile strength (negative!) in [MPa]

        Returns:
            None:   No comment.
        """
        self.sls_tensile_strength = sigma_lim
        self.update_sls_diagram_points()
        return None

    def set_uls_diagram(
            self, strains: tuple[float], stresses: tuple[float],
    ) -> None:
        """Permet de renseigner une courbe Contrainte / Déformation sur mesure.

        Args:
            strains (tuple[float]):     liste des déformations [ε0, ε1, ε2...]
            stresses (tuple[float]):    liste des contraintes [σ0, σ1, σ2...]

        Raises:
            ValueError: Renvoie une erreur si les listes "strains" et "stresses"
                        n'ont pas la même longueur. 

        Returns:
            None:   No comment.
        """
        if len(strains) != len(stresses):
            error_msg = "La longueur des deux listes doit être identique!"
            raise ValueError(error_msg)
        self.uls_strains = strains
        self.uls_stresses = stresses
        return None

    def set_sls_diagram(
            self, strains: tuple[float], stresses: tuple[float],
    ) -> None:
        """Permet de renseigner une courbe Contrainte / Déformation sur mesure.

        Args:
            strains (tuple[float]):     liste des déformations [ε0, ε1, ε2...]
            stresses (tuple[float]):    liste des contraintes [σ0, σ1, σ2...]

        Raises:
            ValueError: Renvoie une erreur si les listes "strains" et "stresses"
                        n'ont pas la même longueur. 

        Returns:
            None:   No comment.
        """
        if len(strains) != len(stresses):
            error_msg = "La longueur des deux listes doit être identique!"
            raise ValueError(error_msg)
        self.sls_strains = strains
        self.sls_stresses = stresses
        return None

    def uls_stress(self, epsilon: float) -> float:
        """Returns the ULS stress in the material for the given strain.

        Args:
            epsilon (float):    Strain of the concrete fibre.

        Returns:
            float:  Stress in [MPa]
        """
        return np.interp(
            epsilon, self.uls_strains, self.uls_stresses, left=0, right=0,
        )

    def sls_stress(self, epsilon: float) -> float:
        """Returns the ULS stress in the material for the given strain.

        Args:
            epsilon (float):    Strain of the concrete fibre.

        Returns:
            float:  Stress in [MPa]
        """
        return np.interp(
            epsilon, self.sls_strains, self.sls_stresses, left=0, right=0,
        )

    def get_stress(self, epsilon: float, type:str="uls") -> float:
        """Returns the stress in the material for the given strain, according to
        the diagram type.

        Args:
            epsilon (float):    Strain of the concrete fibre.
            type (str):         "uls" or "sls

        Returns:
            float:  Stress in [MPa]
        """
        type = type.lower()
        if type == "sls":
            return self.sls_stress(epsilon)
        if type == "uls":
            return self.uls_stress(epsilon)

    # def sls_uncracked_stress(self, epsilon: float) -> float:
    #     """
    #     Perfectly elastic stress-strain diagram (including tension)
    #     No stress limitation

    #     @param epsilon: The strain in the concrete - [-]
    #     @return: The stress level in the concrete for epsilon - [MPa]
    #     """
    #     return cl.sls_uncracked_stress(epsilon, self.modul_Ec_eff)

    # def sls_cracked_stress(self, epsilon: float, sigma_lim: float = 0) -> float:
    #     """
    #     Elastic stress-strain diagram (no tension)
    #     No stress limitation

    #     @param epsilon: The strain in the concrete - [-]
    #     @param sigma_lim: Limited tensile stress in concrete - [MPa]
    #     @return: The compressive stress level in the concrete for epsilon [MPa]
    #     """
    #     young_modulus = cl.modul_Ec_eff(self.fck, self.phi_creep)
    #     return cl.sls_cracked_stress(epsilon, young_modulus, sigma_lim)

    # def uls_sargin_stress(self, epsilon: float) -> float:
    #     """
    #     Stress-strain relation for concrete in compression (Sargin or "real"
    #     diagram)

    #     @param epsilon: The strain in the concrete - [-]
    #     @return: The compressive stress level in the concrete for epsilon [MPa]
    #     """
    #     return cl.uls_sargin_stress(
    #         epsilon=epsilon,
    #         fck=self.fck,
    #         gamma_c=self.gamma_c,
    #         phi_creep=self.phi_creep,
    #     )

    # def uls_parabola_stress(self, epsilon: float) -> float:
    #     """
    #     Parabola-rectangle diagram for concrete under compression

    #     @param epsilon: The strain in the concrete - [-]
    #     @return: The compressive stress level in the concrete for epsilon [MPa]
    #     """
    #     return cl.uls_parabola_stress(epsilon, self.fck, self.gamma_c)

    # def uls_rectangle_stress(self, epsilon: float) -> float:
    #     """
    #     Rectangular stress distribution for concrete under compression

    #     @param epsilon: The strain in the concrete - [-]
    #     @return: The compressive stress level in the concrete for epsilon [MPa]
    #     """
    #     return cl.uls_rectangle_stress(epsilon, self.fck, self.gamma_c)

    # def uls_bi_linear_stress(self, epsilon: float) -> float:
    #     """
    #     Bi-linear stress-strain relation for concrete under compression

    #     @param epsilon: The strain in the concrete - [-]
    #     @return: The compressive stress level in the concrete for epsilon [MPa]
    #     """
    #     return cl.uls_bi_linear_stress(epsilon, self.fck, self.gamma_c)

    def build_df_diag(
        self,
        type: str="uls",
    ) -> pd.DataFrame:
        """
        Build the dataframe containing the strain / stress curve points.
        """
        if type == "uls":
            strain = self.uls_strains
            stress = self.uls_stresses
        if type == "sls":
            strain = self.sls_strains
            stress = self.sls_stresses

        return pd.DataFrame({
            "strain": strain,
            "stress": stress,
        })

    def plot_curve(
        self, type: str="uls"
    ):
        """
        Prints the strain / stress curve according to the selected diagram type.
        """
        if type.lower() == "sls":
            strain, stress = self.sls_strains, self.sls_stresses
        if type.lower() == "uls":
            strain, stress = self.uls_strains, self.uls_stresses

        strain = [x * 1e3 for x in strain]
        df = pd.DataFrame({
            "strain": strain,
            "stress": stress,
        })
        strain_min, strain_max = min(strain), max(strain)
        sigma_min, sigma_max = min(stress), max(stress)

        fig = df.hvplot(
            width=500,
            xlim=(strain_min, strain_max+0.1),
            ylim=(sigma_min, sigma_max+1),
            x="strain",
            y="stress",
            xlabel="Déformation [‰]",
            ylabel="Contrainte [MPa]",
            title=f"Loi contrainte / déformation - {type.upper()}",
        )
        return fig

    # def plot_curve_old(self, type: str="uls",) -> None:
    #     """
    #     Prints the strain / stress curve according to the selected diagram type.
    #     """
    #     if type.lower() == "sls":
    #         strain, stress = self.sls_strains, self.sls_stresses
    #     if type.lower() == "uls":
    #         strain, stress = self.uls_strains, self.uls_stresses

    #     strain = [x * 1e3 for x in strain]

    #     fig, cb_strain_stress = plt.subplots()
    #     cb_strain_stress.plot(strain, stress)
    #     cb_strain_stress.set(
    #         xlabel="Déformation [‰]",
    #         ylabel="Contrainte [MPa]",
    #         title=f"Loi contrainte / déformation - {type.upper()}",
    #     )
    #     plt.show

    #     return None

    def __str__(self) -> str:
        Ecm = round(self.modul_Ecm/1000, 1)
        result = f"Material Definition - EC2 Concrete:  {self.name}\n"
        result += f"\tCharacteristic compressive strength:"
        result += f"\tfck = {self.fck} MPa\n"
        result += f"\tSecant modulus of elasticity:\t\tEcm = {Ecm} GPa\n"
        result += f"\tCreep coefficient:\t\t\t\u03C6 = {self.phi_creep}\n"
        return result

    def __repr__(self) -> str:
        Ecm = round(self.modul_Ecm/1000, 1)
        result = f"Material Definition - EC2 Concrete:  {self.name}\n"
        result += f"\tCharacteristic compressive strength:"
        result += f"\tfck = {self.fck} MPa\n"
        result += f"\tSecant modulus of elasticity:\t\tEcm = {Ecm} GPa\n"
        result += f"\tCreep coefficient:\t\t\t\u03C6 = {self.phi_creep}\n"
        return result



if __name__ == "__main__":
    import random
    import time

    start_time = time.time()
    C30 = EC2Concrete(30, uls_diagram_type="sargin")
    eps_0 = 0
    eps_1 = 0.0035
    n = 1_000_000
    epsilons = []
    sigmas = []
    for i in range(n):
        eps = eps_0 + (eps_1 - eps_0) * random.random()
        sig = C30.uls_stress(eps)
        epsilons.append(eps)
        sigmas.append(sig)
    
    print(len(epsilons), len(sigmas))
    print(min(sigmas), max(sigmas))

    print(f"Temps de calculs : {time.time() - start_time: .2f} s")
