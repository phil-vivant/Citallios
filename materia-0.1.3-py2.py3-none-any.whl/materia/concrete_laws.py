"""
EC2 Concrete Module.

Defines the concrete material in accordance with Eurocode 2 Part 1-1 § 3.1.
Based on characteristic compressive strength and other optional parameters,
defines all the properties and behavior of the concrete.
Advanced behavior (creep, shrinkage) of concrete material is coverd by the
EC2AdvancedConcrete class.
"""

# Standard library imports
import math

# Third party imports
from rich import print

# Local applications imports
from materia.constantes import *


SLS_DIAGRAM_TYPE = (
    "uncracked",
    "cracked",
)
ULS_DIAGRAM_TYPE = (
    "sargin",
    "parabola",
    "rectangle",
    "bi_linear",
)
BETA_MODUL_TRACT = 1/10


def ensure_valid_uls_diagram_type(uls_diagram_type: str) -> None:
    if not is_uls_diagram_type_valid(uls_diagram_type.lower()):
        raise ValueError(f"ULS Diagram Type mismatch: [{ULS_DIAGRAM_TYPE}]")


def ensure_valid_sls_diagram_type(sls_diagram_type: str) -> None:
    if not is_sls_diagram_type_valid(sls_diagram_type.lower()):
        raise ValueError(f"SLS Diagram Type mismatch: [{SLS_DIAGRAM_TYPE}]")


def ensure_valid_cement(cement: str) -> None:
    if not is_cement_valid(cement.upper()):
        raise ValueError(f"Cement type mismatch: [{TYPE_CIMENT_EC2}]")


def ensure_valid_fck(fck: float) -> None:
    if not is_fck_valid(fck):
        error_msg = f"Il convient de respecter :"
        error_msg += f"\tC{C_MIN} <= fck <= C{C_MAX} (EC2-3.1.2(2)P"
        raise ValueError(error_msg)


def is_uls_diagram_type_valid(uls_diagram_type: str) -> bool:
    return uls_diagram_type in ULS_DIAGRAM_TYPE


def is_sls_diagram_type_valid(sls_diagram_type: str) -> bool:
    return sls_diagram_type in SLS_DIAGRAM_TYPE


def is_cement_valid(cement: str) -> bool:
    return cement in TYPE_CIMENT_EC2


def is_fck_valid(fck: float) -> bool:
    return C_MIN <= fck <= C_MAX


def fcm(fck: float) -> float:
    """
    Mean compressive strenght of concrete at 28 days
    [EN 1992-1-1 - Table 3.1].
    """
    ensure_valid_fck(fck)
    return fck + 8


def fcd(fck: float, gamma_c: float | None=None) -> float:
    """
    Concrete design compressive strength [EN 1992-1-1 - §3.1.6 (1)P].
    """
    ensure_valid_fck(fck)
    if gamma_c is None:
        gamma_c = GAMMA_C
    return ALPHA_C * fck / gamma_c


def fctm(fck: float) -> float:
    """
    Mean axial tensile strength [EN 1992-1-1 - Table 3.1].
    """
    ensure_valid_fck(fck)
    return min(
        0.30 * fck ** (2 / 3),
        2.12 * math.log(1 + fcm(fck) / 10),
    )


def fctk_005(fck: float) -> float:
    """
    Characteristic axial tensile strength of concrete - 5 % fractile
    [EN 1992-1-1 - Table 3.1].

    Args:
        fck (float):    Characteristic concrete cylinder compressive strength

    Returns:
        None:   Tensile Strength in [MPa].
    """
    ensure_valid_fck(fck)
    return 0.7 * fctm(fck)


def fctk_095(fck: float) -> float:
    """
    Characteristic axial tensile strength of concrete - 95 % fractile
    [EN 1992-1-1 - Table 3.1].

    Args:
        fck (float):    Characteristic concrete cylinder compressive strength

    Returns:
        None:   Tensile Strength in [MPa].
    """
    ensure_valid_fck(fck)
    return 1.3 * fctm(fck)


def fctd(fck: float, gamma_c: float | None=None) -> float:
    """
    Design tensile strength [EN 1992-1-1 - §3.1.6 (2)P].

    Args:
        fck (float):    Characteristic concrete cylinder compressive strength
        gamma_c (float):    Partial factor for concrete

    Returns:
        None:   Tensile Strength in [MPa].
    """
    ensure_valid_fck(fck)
    if gamma_c is None:
        gamma_c = GAMMA_C
    return ALPHA_CT * fctk_005(fck) / gamma_c


def nu_eq_66N(fck: float) -> float:
    """
    Strength reduction factor for concrete cracked due shear
    [EN 1992-1-1 - 6.2.1 (6) - eq (6.6N)].

    Args:
        fck (float):    Characteristic concrete cylinder compressive strength

    Returns:
        float:  Coefficient adimensionnel
    """
    ensure_valid_fck(fck)
    return 0.60 * (1 - fck / 250)


def nu1_eq_69(fck: float) -> float:
    """
    Strength reduction factor for concrete cracked due shear
    [EN 1992-1-1 - 6.2.3 (3) - eq (6.9)].

    Args:
        fck (float):    Characteristic concrete cylinder compressive strength

    Returns:
        float:  Coefficient adimensionnel
    """
    ensure_valid_fck(fck)
    return nu_eq_66N(fck)


def modul_Ecm(fck: float) -> float:
    """
    Secant modulus of elasticity of concrete [EN 1992-1-1 - Table 3.1].
    """
    ensure_valid_fck(fck)
    return 22 * (fcm(fck) / 10) ** 0.3 * 10**3


def modul_Ec_eff(fck: float, phi_creep: float=2) -> float:
    """
    Effective modulus of elasticity of concrete accounting for creep
    deformations [EN 1992-1-1 - eq (7.20)].
    """
    ensure_valid_fck(fck)
    return modul_Ecm(fck) / (1 + phi_creep)


def modul_Ecd(fck: float) -> float:
    """
    Design value of the modulus of elasticity of concrete accounting for
    creep deformations [EN 1992-1-1 - eq (5.20)].
    """
    ensure_valid_fck(fck)
    return modul_Ecm(fck) / 1.2


def modul_Ecd_eff(fck: float, phi_creep: float=2) -> float:
    """
    Design effective modulus of elasticity of concrete accounting for creep
    deformations [EN 1992-1-1 - eq (5.27)].
    """
    ensure_valid_fck(fck)
    return modul_Ecd(fck) / (1 + phi_creep)


def epsilon_c1(fck: float) -> float:
    """
    Compressive strain in the concrete at the peak strenght fc
    [EN 1992-1-1 - Table 3.1].
    """
    ensure_valid_fck(fck)
    return min(0.7 * fcm(fck)**0.31, 2.8) * 10 ** (-3)


def epsilon_cu1(fck: float) -> float:
    """
    Ultimate compressive strain in the concrete [EN 1992-1-1 - Table 3.1].
    """
    ensure_valid_fck(fck)
    return min(2.8 + 27 * ((98 - fcm(fck)) / 100) ** 4, 3.5) * 10 ** (-3)


def epsilon_c2(fck: float) -> float:
    """
    Compressive strain in the concrete at the peak strenght fc
    [EN 1992-1-1 - Table 3.1].
    """
    ensure_valid_fck(fck)
    if fck <= 50:
        return 2.0 * 10 ** (-3)
    else:
        return (2 + 0.085 * (fck - 50) ** 0.53) * 10 ** (-3)


def epsilon_cu2(fck: float) -> float:
    """
    Ultimate compressive strain in the concrete [EN 1992-1-1 - Table 3.1].
    """
    ensure_valid_fck(fck)
    return min(2.6 + 35 * ((90 - fck) / 100) ** 4, 3.5) * 10 ** (-3)


def epsilon_c3(fck: float) -> float:
    """
    Compressive strain in the concrete at the peak strenght fc
    [EN 1992-1-1 - Table 3.1].
    """
    ensure_valid_fck(fck)
    return max(1.75 + 0.55 * ((fck - 50) / 40), 1.75) * 10 ** (-3)


def epsilon_cu3(fck: float) -> float:
    """
    Ultimate compressive strain in the concrete [EN 1992-1-1 - Table 3.1].
    """
    ensure_valid_fck(fck)
    return min(2.6 + 35 * ((90 - fck) / 100) ** 4, 3.5) * 10 ** (-3)


def epsilon_c(fck: float, diagram_type: str="parabola") -> float:
    """Déformation relative du béton.

    Args:
        fck (float):    Résistance caractéristique à la compression en [MPa].
        diagram_type (str, optional):   Type de diagramme contrainte / déformations.
                                        Defaults to "parabola".

    Returns:
        float:  coefficient adimensionnel
    """
    ensure_valid_fck(fck)
    ensure_valid_uls_diagram_type(diagram_type)
    if diagram_type.lower() == ULS_DIAGRAM_TYPE[0]:
        return epsilon_c1(fck)
    if diagram_type.lower() == ULS_DIAGRAM_TYPE[1]:
        return epsilon_c2(fck)
    return epsilon_c3(fck)


def epsilon_cu(fck: float, diagram_type: str="parabola") -> float:
    """Déformation relative ultime dui béton en compression.

    Args:
        fck (float):    Résistance caractéristique à la compression en [MPa].
        diagram_type (str, optional):   Type de diagramme contrainte / déformation.
                                        Defaults to "parabola".

    Returns:
        float:  coefficient adimensionnel
    """
    ensure_valid_fck(fck)
    ensure_valid_uls_diagram_type(diagram_type)
    if diagram_type.lower() == ULS_DIAGRAM_TYPE[0]:
        return epsilon_cu1(fck)
    if diagram_type.lower() == ULS_DIAGRAM_TYPE[1]:
        return epsilon_cu2(fck)
    return epsilon_cu3(fck)


def n_2(fck: float) -> float:
    """
    n2 parameter according to Table 3.1 of EN 1992-1-1.
    """
    ensure_valid_fck(fck)
    return min(1.4 + 23.4 * ((90 - fck) / 100) ** 4, 2.0)


def lambda_3(fck: float) -> float:
    """
    Factor lambda, defining the effective height of the compression zone for
    the ULS rectangular diagram.
    """
    ensure_valid_fck(fck)
    return min(0.8 - (fck - 50) / 400, 0.8)


def eta_3(fck: float) -> float:
    """
    Factor eta, defining the effective concrete strength for the ULS
    rectangular diagram.
    """
    ensure_valid_fck(fck)
    return min(1 - (fck - 50) / 200, 1.0)


def sls_uncracked_stress(epsilon: float, young_modulus: float) -> float:
    """
    Perfectly elastic stress-strain diagram (including tension)
    No stress limitation

    @param epsilon: The strain in the concrete - [-]
    @return: The stress level in the concrete for epsilon - [MPa]
    """
    return epsilon * young_modulus


def sls_cracked_stress(
        epsilon: float,
        young_modulus: float,
        sigma_lim: float = 0,
) -> float:
    """
    Elastic stress-strain diagram (no tension)
    No stress limitation

    @param epsilon: The strain in the concrete - [-]
    @param sigma_lim: Limited tensile stress in concrete - [MPa]
    @return: The compressive stress level in the concrete for epsilon [MPa]
    """
    sigma = sls_uncracked_stress(epsilon, young_modulus)
    return sigma if sigma >= sigma_lim else 0


def uls_sargin_stress(
        epsilon: float,
        fck: float,
        gamma_c: float | None=None,
        phi_creep: float=0,
) -> float:
    """
    Stress-strain relation for concrete in compression (Sargin or "real"
    diagram)

    @param epsilon: The strain in the concrete - [-]
    @return: The compressive stress level in the concrete for epsilon [MPa]
    """
    ensure_valid_fck(fck)
    epsilon_c_eff = epsilon_c1(fck) * (1 + phi_creep)
    epsilon_cu_eff = epsilon_cu1(fck) * (1 + phi_creep)
    if epsilon <= 0:
        stress = 0
    elif epsilon <= epsilon_cu_eff:
        eta = epsilon / epsilon_c_eff
        module_cd_eff = modul_Ecd_eff(fck, phi_creep)
        k = 1.05 * module_cd_eff * epsilon_c_eff / (fcd(fck))
        stress = fcd(fck, gamma_c) * (k * eta - eta**2) / (1 + (k - 2) * eta)
    else:
        stress = 0

    return stress


def uls_parabola_stress(
        epsilon: float, fck: float, gamma_c: float | None=None,
) -> float:
    """
    Parabola-rectangle diagram for concrete under compression

    @param epsilon: The strain in the concrete - [-]
    @return: The compressive stress level in the concrete for epsilon [MPa]
    """
    ensure_valid_fck(fck)
    eps_c2 = epsilon_c2(fck)
    eps_cu2 = epsilon_cu2(fck)
    if epsilon <= 0:
        stress = 0
    elif epsilon <= eps_c2:
        stress = fcd(fck, gamma_c)
        stress *= (1 - (1 - epsilon / eps_c2) ** n_2(fck))
    elif epsilon <= eps_cu2:
        stress = fcd(fck, gamma_c)
    else:
        stress = 0

    return stress


def uls_rectangle_stress(
        epsilon: float, fck: float, gamma_c: float | None=None,
) -> float:
    """
    Rectangular stress distribution for concrete under compression

    @param epsilon: The strain in the concrete - [-]
    @return: The compressive stress level in the concrete for epsilon [MPa]
    """
    ensure_valid_fck(fck)
    if epsilon <= (1 - lambda_3(fck)) * epsilon_cu3(fck):
        stress = 0
    elif epsilon <= epsilon_cu3(fck):
        stress = eta_3(fck) * fcd(fck, gamma_c)
    else:
        stress = 0

    return stress


def uls_bi_linear_stress(
        epsilon: float, fck: float, gamma_c: float | None=None,
) -> float:
    """
    Bi-linear stress-strain relation for concrete under compression

    @param epsilon: The strain in the concrete - [-]
    @return: The compressive stress level in the concrete for epsilon [MPa]
    """
    ensure_valid_fck(fck)
    if epsilon <= 0:
        stress = 0
    elif epsilon <= epsilon_c3(fck):
        stress = fcd(fck) * epsilon / epsilon_c3(fck)
    elif epsilon <= epsilon_cu3(fck):
        stress = fcd(fck, gamma_c)
    else:
        stress = 0

    return stress


def concrete_sls_diagram_points(
        young_modul: float,
        tensile_strength: float|None=None,
        beta_modul: float|None=None,
):
    if beta_modul == None:
        beta_modul = BETA_MODUL_TRACT
    eps_max = 0.01
    if tensile_strength == None:
        eps_t0 = -eps_max
        eps_t1 = eps_t0 - EPSILON
        sigma_min = eps_t0 * young_modul
    else:
        tensile_strength = min(tensile_strength, 0)
        eps_t0 = tensile_strength / young_modul
        eps_t1 = eps_t0 * (1 + beta_modul) / beta_modul
        sigma_min = tensile_strength
    
    sigma_max = eps_max * young_modul
    strains = [eps_t1, eps_t0, eps_max, eps_max + EPSILON]
    stresses = [0, sigma_min, sigma_max, 0]

    return strains, stresses


def concrete_uls_diagram_points(
        fck: float,
        diagram_type: str="parabola",
        gamma_c: float|None=None,
        phi_creep: float=0,
        step: float=1e-4,
) -> float:
    ensure_valid_fck(fck)
    epsilon_max = epsilon_cu(fck, diagram_type) * (1 + phi_creep)
    strains = []
    epsilon = 0
    while epsilon <= epsilon_max:
        strains.append(epsilon)
        epsilon += step
    if diagram_type.lower() == ULS_DIAGRAM_TYPE[0]:
        stresses = [uls_sargin_stress(epsilon, fck, gamma_c, phi_creep)
                    for epsilon in strains]
    if diagram_type.lower() == ULS_DIAGRAM_TYPE[1]:
        stresses = [uls_parabola_stress(epsilon, fck, gamma_c)
                    for epsilon in strains]
    if diagram_type.lower() == ULS_DIAGRAM_TYPE[2]:
        stresses = [uls_rectangle_stress(epsilon, fck, gamma_c)
                    for epsilon in strains]
    if diagram_type.lower() == ULS_DIAGRAM_TYPE[3]:
        stresses = [uls_bi_linear_stress(epsilon, fck, gamma_c)
                    for epsilon in strains]
    strains.append(epsilon_max + EPSILON)
    stresses.append(0)
    return strains, stresses


def krawsky(notional_size: int) -> float:
    """
    Krawsky coefficient for the shrink strain calculation

    @param notional_size:  Notional size of the concrete member - [mm]
    @return: Krawsky coefficient - [-]
    """
    return 2.5e-06 * notional_size**2 - 2.25e-03 * notional_size + 1.2


def shrink(
    cement: str,
    fck: float,
    notional_size: int,
    humidity_rh: int = 60,
    drying_start: int = 3,
    t_shrink: int = 18250,
) -> list[float]:
    """
    Calculate the total shrinkage strain according EN 1992-1-1 Annex B.

    @param notional_size: Notional size of the concrete member - [mm]
    @param humidity_rh: Ambient relative humidity - [%]
    @param drying_start:  Age of the concrete at the beginning of drying shrinkage (or swelling) - [days]
    @return: The total shrinkage strain at age t and at long term [-]
    """
    ensure_valid_fck(fck)
    # alpha parameters calculation
    alpha_ds_1 = ALPHA_DS_1.get(cement)
    alpha_ds_2 = ALPHA_DS_2.get(cement)
    humidity_0 = 100
    fcm1 = fcm(fck)
    fcm0 = 10

    # autogenous shrinkage strain
    beta_as_t = 1 - math.exp(-0.2 * t_shrink ** (1 / 2))
    epsilon_ca_infinite = 2.5 * (fck - 10) * 1e-6
    epsilon_ca_t = beta_as_t * epsilon_ca_infinite

    # drying shrinkage strain
    beta_ds_t = (t_shrink - drying_start) / (
        (t_shrink - drying_start) + 0.04 * notional_size ** (3 / 2)
    )
    beta_rh = 1.55 * (1 - (humidity_rh / humidity_0) ** 3)
    epsilon_cd_0 = (
        0.85 * beta_rh *
        ((220 + 110 * alpha_ds_1) * math.exp(-alpha_ds_2 * fcm1 / fcm0) * 1e-6)
    )
    kh = krawsky(notional_size)
    epsilon_cd_infinite = kh * epsilon_cd_0
    epsilon_cd_t = beta_ds_t * epsilon_cd_infinite

    # total shrinkage strain
    epsilon_cs_t = epsilon_ca_t + epsilon_cd_t
    epsilon_cs_infinite = epsilon_ca_infinite + epsilon_cd_infinite

    return epsilon_cs_t, epsilon_cs_infinite


def creep(
    cement: str,
    fck: float,
    notional_size: int,
    t0_start: int,
    t_creep: int = 18250,
    humidity_rh: int = 60,
    sigma_c: float = 0.0,
) -> list[float, float]:
    """
    This method calculate the creep coefficient, at t days and infinite time according EN 1992-1-1 Annex B.

    @param notional_size: Notional size of the concrete member - [mm]
    @param t0_start:  Age of concrete at loading - [days]
    @param sigma_c: Compressive stress - [MPa]
    @param humidity_rh: Ambient relative humidity, in [%]
    @return: The creep coefficient at t days and the long term creep coefficient - [-]
    """
    ensure_valid_fck(fck)
    # Compression resistance
    fcm1 = fcm(fck)
    fck_t0 = beta_cc_func(t0_start) * fcm(fck) - 8

    # alpha parameters calculation
    alpha_creep = ALPHA_CREEP.get(cement)
    alpha1, alpha2, alpha3 = alpha_eq_B8c(fck)

    # creep non-linearity
    if sigma_c / fck_t0 > 0.45:
        non_linear_coefficient = math.exp(1.5 * (sigma_c / fck_t0 - 0.45))
    else:
        non_linear_coefficient = 1

    t0_prim = max(t0_start * (9 / (2 + t0_start**1.2) + 1) ** alpha_creep, 0.5)

    beta_t0 = 1 / (0.1 + t0_prim**0.2)
    beta_fcm = 16.8 / fcm1 ** (1 / 2)
    phi_rh = (
        1 + (1 - humidity_rh / 100) / (0.1 * notional_size ** (1 / 3)) * alpha1
    ) * alpha2

    # final creep coefficient
    phi_0 = phi_rh * beta_fcm * beta_t0 * non_linear_coefficient

    beta_h = 1.5 * (1 + (0.012 * humidity_rh) ** 18) * notional_size
    beta_h += 250 * alpha3
    beta_h = min(beta_h, 1500 * alpha3)
    beta_c_t_t0 = ((t_creep - t0_prim) / (beta_h + t_creep - t0_prim)) ** 0.3

    phi_t_t0 = beta_c_t_t0 * phi_0

    return phi_t_t0, phi_0


def fcm_t(fck: float, t_days: int) -> float:
    """
    Mean concrete compressive strength at the age of t days.
    """
    return beta_cc_func(t_days) * fcm(fck)


def fck_t(fck: float, t_days: int) -> float:
    """
    Concrete compressive strength at time t [EN 1992-1-1 - § 3.1.2 (5)].
    """
    return fcm_t(fck, t_days) - 8


def fctm_t(fck: int, t_days: int, cement: str) -> float:
    """
    Mean axial tensile strength at time t [EN 1992-1-1 - § 3.1.2 (9)].
    """
    if t_days < 28:
        alpha = 1
    else:
        alpha = 2 / 3

    return beta_cc_func(t_days, cement) ** alpha * fctm(fck)

    @property
    def fctk_005_t(self) -> float:
        return 0.70 * self.fctm_t

    @property
    def fctk_095_t(self) -> float:
        return 1.30 * self.fctm_t

    @property
    def modul_ecm_t(self) -> float:
        return self.beta_cc**0.30 * self.modul_Ecm

    def set_days(self, days: int) -> int:
        self.t_days = days
        return self.t_days

    def shrink(
        self,
        notional_size: int,
        humidity_rh: int = 60,
        drying_start: int = 3,
        t_shrink: int | None = None,
    ) -> list[float]:
        """
        This method calculate the total shrinkage strain according EN 1992-1-1 Annex B.

        @param notional_size: Notional size of the concrete member - [mm]
        @param humidity_rh: Ambient relative humidity - [%]
        @param drying_start:  Age of the concrete at the beginning of drying shrinkage (or swelling) - [days]
        @return: The total shrinkage strain at age t and at long term [-]
        """
        # alpha parameters calculation
        dico_alpha_ds_1 = {"S": 3, "N": 4, "R": 6}
        dico_alpha_ds_2 = {"S": 0.13, "N": 0.12, "R": 0.11}

        alpha_ds_1 = dico_alpha_ds_1.get(self.cement)
        alpha_ds_2 = dico_alpha_ds_2.get(self.cement)
        humidity_0 = 100
        fcm = self.fck + 8
        fcm0 = 10

        # t_shrink
        if t_shrink is None:
            t_shrink = self.t_days

        # autogenous shrinkage strain
        beta_as_t = 1 - math.exp(-0.2 * t_shrink ** (1 / 2))
        epsilon_ca_infinite = 2.5 * (self.fck - 10) * 1e-06
        epsilon_ca_t = beta_as_t * epsilon_ca_infinite

        # drying shrinkage strain
        beta_ds_t = (t_shrink - drying_start) / (
            (t_shrink - drying_start) + 0.04 * notional_size ** (3 / 2)
        )
        beta_rh = 1.55 * (1 - (humidity_rh / humidity_0) ** 3)
        epsilon_cd_0 = (
            0.85
            * ((220 + 110 * alpha_ds_1) * math.exp(-alpha_ds_2 * fcm / fcm0) * 1e-06)
            * beta_rh
        )
        kh = krawsky(notional_size)
        epsilon_cd_infinite = kh * epsilon_cd_0
        epsilon_cd_t = beta_ds_t * epsilon_cd_infinite

        # total shrinkage strain
        epsilon_cs_t = epsilon_ca_t + epsilon_cd_t
        epsilon_cs_infinite = epsilon_ca_infinite + epsilon_cd_infinite

        return epsilon_cs_t, epsilon_cs_infinite

    def creep(
        self,
        notional_size: int,
        t0_start: int,
        t_creep: int | None = None,
        humidity_rh: int = 60,
        sigma_c: float = 0.0,
    ) -> list[float]:
        """
        This method calculate the creep coefficient, at t days and infinite time according EN 1992-1-1 Annex B.

        @param notional_size: Notional size of the concrete member - [mm]
        @param t0_start:  Age of concrete at loading - [days]
        @param sigma_c: Compressive stress - [MPa]
        @param humidity_rh: Ambient relative humidity, in [%]
        @return: The creep coefficient at t days and the long term creep coefficient - [-]
        """
        # t_creep
        if t_creep is None:
            t_creep = self.t_days

        # Compression resistance
        fcm = self.fck + 8
        fck_t0 = self._beta_cc_func(t0_start) * self.fcm - 8

        # alpha parameters calculation
        alpha_eq_B8c = self._alpha_param()
        alpha = alpha_eq_B8c[0]
        alpha1 = alpha_eq_B8c[1]
        alpha2 = alpha_eq_B8c[2]
        alpha3 = alpha_eq_B8c[3]

        # creep non-linearity
        if sigma_c / fck_t0 > 0.45:
            non_linear_coefficient = math.exp(1.5 * (sigma_c / fck_t0 - 0.45))
        else:
            non_linear_coefficient = 1

        t0_prim = max(t0_start * (9 / (2 + t0_start**1.2) + 1) ** alpha, 0.5)

        beta_t0 = 1 / (0.1 + t0_prim**0.2)
        beta_fcm = 16.8 / fcm ** (1 / 2)
        phi_rh = (
            1 + (1 - humidity_rh / 100) / (0.1 * notional_size ** (1 / 3)) * alpha1
        ) * alpha2

        # final creep coefficient
        phi_0 = phi_rh * beta_fcm * beta_t0 * non_linear_coefficient

        beta_h = 1.5 * (1 + (0.012 * humidity_rh) ** 18) * notional_size + 250 * alpha3
        beta_c_t_t0 = ((t_creep - t0_start) / (beta_h + t_creep - t0_start)) ** 0.3

        phi_t_t0 = beta_c_t_t0 * phi_0

        return phi_t_t0, phi_0


def beta_cc_func(t_days: int, cement: str="N") -> float:
    """
    Calculation of the beta_cc coefficient according EN 1992-1-1 § 3.1.2 (6).

    @param t_days: Age of the concrete [days]
    @return: The beta_cc coefficient (=1 if t_days > 28) - [-]
    """
    ensure_valid_cement(cement)
    sc_ec2 = SC_FACTOR.get(cement)
    return min(math.exp(sc_ec2 * (1 - (28 / t_days) ** (1 / 2))), 1)


def alpha_eq_B8c(fck: float) -> list[float]:
    fcm1 = fcm(fck)
    if fcm1 > 35:
        alpha_1 = (35 / fcm1) ** 0.7
        alpha_2 = (35 / fcm1) ** 0.2
        alpha_3 = (35 / fcm1) ** 0.5
    else:
        alpha_1 = 1
        alpha_2 = 1
        alpha_3 = 1

    return alpha_1, alpha_2, alpha_3
