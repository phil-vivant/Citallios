import hvplot.pandas
import numpy as np
import pandas as pd
np.random.seed(1)

idx = pd.date_range('1/1/2000', periods=1000)
df = pd.DataFrame(np.random.randn(1000, 4), index=idx, columns=list('ABCD')).cumsum()
# df.hvplot()


def plot(df):
    fig = df.hvplot()
    return fig


if __name__ == "__main__":
    plot(df)
