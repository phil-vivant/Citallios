# Standard library imports
import inspect
from dataclasses import dataclass
from math import isclose

# Third party imports
import matplotlib.pyplot as plt

# Local applications imports


@dataclass
class FibreReinforcedPolymer:
    """
    Fiber Reinforced Polymer Class

    @param modulus_elasticity_ef:  Average mean value of modulus of elasticity in [MPa]
    @param sigma_f_sls: SLS stress limitation in [MPa]
    @param sigma_f_uls: ULS design tensile strength in [MPa]
    @param diagram_type: Type of stress / strain diagram, with :
        ['elastic']     Perfectly elastic stress-strain diagram (no limit ! but no compression !)
        ['sls']         SLS design stress-strain diagram (no compression !)
        ['uls']         ULS design stress-strain diagram (no compression !)
    """

    modulus_elasticity_ef: int = 200_000
    sigma_f_sls: float = 1400
    sigma_f_uls: float = 1800
    diagram_type: str = "uls"
    ftk: float = 1.

    def __post_init__(self):
        self.diagram_type = self.diagram_type.lower()
        self.tuple_diagram_type = ("elastic", "sls", "uls")
        self.ensure_valid_diagram_type()

    def ensure_valid_diagram_type(self):
        if not self.is_diagram_type_valid():
            raise ValueError(f"Diagram type mismatch: [{self.tuple_diagram_type}]")

    def is_diagram_type_valid(self) -> bool:
        return self.diagram_type in self.tuple_diagram_type

    def set_sigma_f_sls(self, sigma_f_sls: float) -> None:
        """
        Modifies the SLS stress limitation (default value is 1400 MPa).
        """
        self.sigma_f_sls = sigma_f_sls
        return None

    def set_sigma_f_uls(self, sigma_f_uls: float) -> None:
        """
        Modifies the ULS stress limitation (default value is 1400 MPa).
        """
        self.sigma_f_uls = sigma_f_uls
        return None

    def set_diagram_type(self, diagram_type: str) -> None:
        """
        Modifies the diagram type of the steel (default value is 'uls').
        @param diagram_type: Type of stress / strain diagram, with :
            ['elastic']     Perfectly elastic stress-strain diagram (no limit ! but no compression !)
            ['sls']         SLS design stress-strain diagram (no compression !)
            ['uls']         ULS design stress-strain diagram (no compression !)
        """
        self.diagram_type = diagram_type.lower()
        self.ensure_valid_diagram_type()
        return None
    
    @property
    def sigma_ad_u(self) -> float:
        return min(2., self.ftk / 1.5)

    @property
    def sigma_ad_s(self) -> float:
        return min(1.5, self.ftk / 2.)

    def sigma_ad_lim(self, t_f: float, l_anc: float) -> float:
        return self.sigma_ad_u * t_f / l_anc

    @property
    def limit_strain(self) -> float:
        """
        Returns the limit strain for the FRP.
        """
        if self.diagram_type == self.tuple_diagram_type[0]:
            limit_strain = -1.0
        elif self.diagram_type == self.tuple_diagram_type[1]:
            limit_strain = -1 * self.sigma_f_sls / self.modulus_elasticity_ef
        elif self.diagram_type == self.tuple_diagram_type[2]:
            limit_strain = -1 * self.sigma_f_uls / self.modulus_elasticity_ef
        else:
            limit_strain = 0.0
        return limit_strain

    def get_stress(self, epsilon) -> float:
        """
        Returns the stress in the materials for the given strain, according to the diagram type.
        """
        return self.diagram_frp(epsilon, self.limit_strain)

    def diagram_frp(self, epsilon: float, limit_strain: float) -> float:
        """
        Perfectly elastic stress-strain diagram - General (tension only).

        @param epsilon: The strain in the FRP - [-]
        @param limit_strain: The strain corresponding to the design stress limitation - [-]
        @return: The stress level in the FRP - [MPa]
        """
        if epsilon > 0:
            return 0
        if isclose(epsilon, limit_strain):
            return epsilon * self.modulus_elasticity_ef
        if  epsilon < limit_strain:
            return 0
        else:
            return epsilon * self.modulus_elasticity_ef

    def build_curve(
        self,
        initial_strain: float | None = None,
        final_strain: float | None = None,
    ):
        """
        Build the strain / stress curve according to the selected diagram type.
        """
        if initial_strain == None:
            initial_strain = self.limit_strain - 0.0001
        if final_strain == None:
            final_strain = 0.001

        strain = []
        stress = []
        epsilon = initial_strain

        while epsilon <= final_strain:
            strain.append(epsilon)
            stress.append(self.get_stress(epsilon))
            epsilon += 0.0001

        return strain, stress

    def plot_curve(
        self,
        initial_strain: float | None = None,
        final_strain: float | None = None,
    ):
        """
        Prints the strain / stress curve according to the selected diagram type.
        """
        strain, stress = self.build_curve(initial_strain, final_strain)

        fig, cb_strain_stress = plt.subplots()
        cb_strain_stress.plot(strain, stress)
        cb_strain_stress.set(
            xlabel="Déformation [‰]",
            ylabel="Contrainte [MPa]",
            title="Loi contrainte / déformation",
        )
        cb_strain_stress.grid()
        plt.show

        return None

    def __str__(self) -> str:
        instance_name = [
            k for k, v in inspect.currentframe().f_back.f_locals.items() if v is self
        ][0]
        result = f"Material Definition - Fibre Reinforced Polymer:  {instance_name}\n"
        result += f"\tSLS stress limitation: \u03C3f,sls = { self.sigma_f_sls} MPa\n"
        result += (
            f"\tULS design tensile strength: \u03C3f,uls = {self.sigma_f_uls} MPa\n"
        )
        result += f"\tModulus of elasticity: Ef = {round(self.modulus_elasticity_ef/1000, 1)} GPa\n"
        return result


if __name__ == "__main__":
    TFC = FibreReinforcedPolymer()
    TFC.plot_curve()
