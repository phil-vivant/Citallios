# Standard library imports
import inspect
import math
from dataclasses import dataclass

# Third party imports
import matplotlib.pyplot as plt

# Local applications imports
from materia.ec2_concrete import EC2Concrete


def krawsky(notional_size: int) -> float:
    """
    Krawsky coefficient for the shrink strain calculation

    @param notional_size:  Notional size of the concrete member - [mm]
    @return: Krawsky coefficient - [-]
    """
    return 2.5e-06 * notional_size**2 - 2.25e-03 * notional_size + 1.2


@dataclass
class EC2AdvancedConcrete(EC2Concrete):
    """
    Advanced EC2 Concrete Class

    @param t_days: age of the concrete (50 years by default) - [days]
    @param cement: Cement class - ['S', 'N', 'R'] (class 'N' by default)
    """

    t_days: int = 18250
    cement: str = "N"

    @property
    def beta_cc(self) -> float:
        """
        Coefficient beta_cc wich depend on the age of the concrete [EN 1992-1-1 - § 3.1.2 (6)].
        """
        return self._beta_cc_func(self.t_days)

    @property
    def fcm_t(self) -> float:
        """
        Mean concrete compressive strength at the age of t days.
        """
        return self.beta_cc * self.fcm

    @property
    def fck_t(self) -> float:
        """
        Concrete compressive strength at time t [EN 1992-1-1 - § 3.1.2 (5)].
        """
        return self.fcm_t - 8

    @property
    def fctm_t(self) -> float:
        """
        Mean axial tensile strength at time t [EN 1992-1-1 - § 3.1.2 (9)].
        """
        if self.t_days < 28:
            alpha = 1
        else:
            alpha = 2 / 3

        return self.beta_cc**alpha * self.fctm

    @property
    def fctk_005_t(self) -> float:
        return 0.70 * self.fctm_t

    @property
    def fctk_095_t(self) -> float:
        return 1.30 * self.fctm_t

    @property
    def modul_ecm_t(self) -> float:
        return self.beta_cc**0.30 * self.modul_Ecm

    def set_days(self, days: int) -> int:
        self.t_days = days
        return self.t_days

    def shrink(
        self,
        notional_size: int,
        humidity_rh: int = 60,
        drying_start: int = 3,
        t_shrink: int | None = None,
    ) -> list[float]:
        """
        This method calculate the total shrinkage strain according EN 1992-1-1 Annex B.

        @param notional_size: Notional size of the concrete member - [mm]
        @param humidity_rh: Ambient relative humidity - [%]
        @param drying_start:  Age of the concrete at the beginning of drying shrinkage (or swelling) - [days]
        @return: The total shrinkage strain at age t and at long term [-]
        """
        # alpha parameters calculation
        dico_alpha_ds_1 = {"S": 3, "N": 4, "R": 6}
        dico_alpha_ds_2 = {"S": 0.13, "N": 0.12, "R": 0.11}

        alpha_ds_1 = dico_alpha_ds_1.get(self.cement)
        alpha_ds_2 = dico_alpha_ds_2.get(self.cement)
        humidity_0 = 100
        fcm = self.fck + 8
        fcm0 = 10

        # t_shrink
        if t_shrink is None:
            t_shrink = self.t_days

        # autogenous shrinkage strain
        beta_as_t = 1 - math.exp(-0.2 * t_shrink ** (1 / 2))
        epsilon_ca_infinite = 2.5 * (self.fck - 10) * 1e-06
        epsilon_ca_t = beta_as_t * epsilon_ca_infinite

        # drying shrinkage strain
        beta_ds_t = (t_shrink - drying_start) / (
            (t_shrink - drying_start) + 0.04 * notional_size ** (3 / 2)
        )
        beta_rh = 1.55 * (1 - (humidity_rh / humidity_0) ** 3)
        epsilon_cd_0 = (
            0.85
            * ((220 + 110 * alpha_ds_1) * math.exp(-alpha_ds_2 * fcm / fcm0) * 1e-06)
            * beta_rh
        )
        kh = krawsky(notional_size)
        epsilon_cd_infinite = kh * epsilon_cd_0
        epsilon_cd_t = beta_ds_t * epsilon_cd_infinite

        # total shrinkage strain
        epsilon_cs_t = epsilon_ca_t + epsilon_cd_t
        epsilon_cs_infinite = epsilon_ca_infinite + epsilon_cd_infinite

        return epsilon_cs_t, epsilon_cs_infinite

    def creep(
        self,
        notional_size: int,
        t0_start: int,
        t_creep: int | None = None,
        humidity_rh: int = 60,
        sigma_c: float = 0.0,
    ) -> list[float]:
        """
        This method calculate the creep coefficient, at t days and infinite time according EN 1992-1-1 Annex B.

        @param notional_size: Notional size of the concrete member - [mm]
        @param t0_start:  Age of concrete at loading - [days]
        @param sigma_c: Compressive stress - [MPa]
        @param humidity_rh: Ambient relative humidity, in [%]
        @return: The creep coefficient at t days and the long term creep coefficient - [-]
        """
        # t_creep
        if t_creep is None:
            t_creep = self.t_days

        # Compression resistance
        fcm = self.fck + 8
        fck_t0 = self._beta_cc_func(t0_start) * self.fcm - 8

        # alpha parameters calculation
        alpha_param = self._alpha_param()
        alpha = alpha_param[0]
        alpha1 = alpha_param[1]
        alpha2 = alpha_param[2]
        alpha3 = alpha_param[3]

        # creep non-linearity
        if sigma_c / fck_t0 > 0.45:
            non_linear_coefficient = math.exp(1.5 * (sigma_c / fck_t0 - 0.45))
        else:
            non_linear_coefficient = 1

        t0_prim = max(t0_start * (9 / (2 + t0_start**1.2) + 1) ** alpha, 0.5)

        beta_t0 = 1 / (0.1 + t0_prim**0.2)
        beta_fcm = 16.8 / fcm ** (1 / 2)
        phi_rh = (
            1 + (1 - humidity_rh / 100) / (0.1 * notional_size ** (1 / 3)) * alpha1
        ) * alpha2

        # final creep coefficient
        phi_0 = phi_rh * beta_fcm * beta_t0 * non_linear_coefficient

        beta_h = 1.5 * (1 + (0.012 * humidity_rh) ** 18) * notional_size + 250 * alpha3
        beta_c_t_t0 = ((t_creep - t0_start) / (beta_h + t_creep - t0_start)) ** 0.3

        phi_t_t0 = beta_c_t_t0 * phi_0

        return phi_t_t0, phi_0

    def _beta_cc_func(self, t_days: int) -> float:
        """
        Calculation of the beta_cc coefficient according EN 1992-1-1 § 3.1.2 (6).

        @param t_days: Age of the concrete [days]
        @return: The beta_cc coefficient (=1 if t_days > 28) - [-]
        """
        coefficient_s = self._alpha_param()[4]

        return min(math.exp(coefficient_s * (1 - (28 / t_days) ** (1 / 2))), 1)

    def _alpha_param(self) -> list[float]:
        fcm = self.fck + 8

        if fcm > 35:
            alpha_1 = (35 / fcm) ** 0.7
            alpha_2 = (35 / fcm) ** 0.2
            alpha_3 = (35 / fcm) ** 0.5
        else:
            alpha_1 = 1
            alpha_2 = 1
            alpha_3 = 1

        if self.cement == "S":
            alpha_ = -1
            s_ = 0.38
        elif self.cement == "N":
            alpha_ = 0
            s_ = 0.25
        elif self.cement == "R":
            alpha_ = 1
            s_ = 0.20
        else:
            alpha_ = 0
            s_ = 0

        return alpha_, alpha_1, alpha_2, alpha_3, s_

    def plot_creep_curve(
        self,
        notional_size: float,
        t0_start: int,
        final_day: int | None = None,
        humidity_rh: float = 60,
        sigma_c: float = 0.0,
    ) -> None:
        """
        Prints the creep curve.
        """
        if final_day is None:
            final_day = self.t_days
        days = []
        creeps = []
        day = t0_start

        while day <= final_day:
            days.append(day)
            creep = self.creep(
                notional_size=notional_size,
                t0_start=t0_start,
                t_creep=day,
                humidity_rh=humidity_rh,
                sigma_c=sigma_c,
            )[0]
            creeps.append(creep)
            day += 1

        fig, cb_creep = plt.subplots()
        cb_creep.plot(days, creeps)
        cb_creep.set(
            xlabel="Age du béton [jours]",
            ylabel="Coefficient de fluage [-]",
            title="Évolution du fluage",
        )
        cb_creep.grid()
        plt.show

        return None

    def plot_shrink_curve(
        self,
        notional_size: float,
        humidity_rh: float = 60,
        drying_start: int = 3,
        final_day: int | None = None,
    ) -> None:
        """
        Prints the shrink curve.
        """
        if final_day is None:
            final_day = self.t_days
        days = []
        shrinks = []
        day = 0

        while day <= final_day:
            days.append(day)
            shrink = (
                self.shrink(
                    notional_size=notional_size,
                    humidity_rh=humidity_rh,
                    drying_start=drying_start,
                    t_shrink=day,
                )[0]
                * 1000
            )
            shrinks.append(shrink)
            day += 1

        fig, cb_shrink = plt.subplots()
        cb_shrink.plot(days, shrinks)
        cb_shrink.set(
            xlabel="Age du béton [jours]",
            ylabel="Retrait du béton [‰]",
            title="Évolution du retrait",
        )
        cb_shrink.grid()
        plt.show

        return None

    def __str__(self) -> str:
        instance_name = [
            k for k, v in inspect.currentframe().f_back.f_locals.items() if v is self
        ][0]
        result = f"Material Definition - EC2 Advanced Concrete:  {instance_name}\n"
        result += f"\tCharacteristic compressive strength: fck = { self.fck} MPa\n"
        result += f"\tCement class: {self.cement}\n"
        result += f"\tAge of the concrete: {self.t_days}\n"
        return result
