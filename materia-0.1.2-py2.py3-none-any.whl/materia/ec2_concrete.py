"""
EC2 Concrete Module.

Defines the concrete material in accordance with Eurocode 2 Part 1-1 § 3.1.
Based on characteristic compressive strength and other optional parameters,
defines all the properties and behavior of the concrete.
Advanced behavior (creep, shrinkage) of concrete material is coverd by the EC2AdvancedConcrete class.
"""

# Standard library imports
from dataclasses import dataclass
import functools
import inspect
import math

# Third party imports
import matplotlib.pyplot as plt

# Local applications imports


@dataclass
class EC2Concrete:
    """
    EC2 Concrete Class.

    Defines the concrete material in accordance with Eurocode 2 Part 1-1 § 3.1.
    Based on characteristic compressive strength and other optional parameters,
    defines all the properties and behavior of the concrete.
    Advanced behavior (creep, shrinkage) of concrete material is covered by the EC2AdvancedConcrete class.

    @param fck: Characteristic concrete cylinder compressive strength at age 28 days - [MPa]
    @param diagram_type: Type of stress / strain diagram among :
        ['sls_uncracked']
        ['sls_cracked']
        ['uls_sargin']
        ['uls_parabola']
        ['uls_rectangle']
        ['uls_bi_linear']
    @param gamma_c: Partial factor for concrete - [-]
    @param alpha_cc: long term effect coefficient (compression)
    @param alpha_ct: long term effect coefficient (traction)
    @param phi_creep:  Creep coefficient - [-]
    """

    fck: float
    diagram_type: str = "uls_parabola"
    gamma_c: float = 1.5
    alpha_cc: float = 1.0
    alpha_ct: float = 1.0
    phi_creep: float = 0.0

    def __post_init__(self):
        self.diagram_type = self.diagram_type.lower()
        self.tuple_diagram_type = (
            "sls_uncracked",
            "sls_cracked",
            "uls_sargin",
            "uls_parabola",
            "uls_rectangle",
            "uls_bi_linear",
        )
        self.ensure_valid_diagram_type()

    def ensure_valid_diagram_type(self):
        if not self.is_diagram_type_valid():
            raise ValueError(f"Diagram type mismatch: [{self.tuple_diagram_type}]")

    def is_diagram_type_valid(self) -> bool:
        return self.diagram_type in self.tuple_diagram_type

    @property
    def fcm(self) -> float:
        """
        Mean compressive strenght of concrete at 28 days [EN 1992-1-1 - Table 3.1].
        """
        return self.fck + 8

    @property
    def fcd(self) -> float:
        """
        Concrete design compressive strength [EN 1992-1-1 - §3.1.6 (1)P].
        """
        return self.alpha_cc * self.fck / self.gamma_c

    @property
    def fctm(self) -> float:
        """
        Mean axial tensile strength [EN 1992-1-1 - Table 3.1].
        """
        return min(0.30 * self.fck ** (2 / 3), 2.12 * math.log(1 + self.fcm / 10))

    @property
    def fctk_005(self) -> float:
        """
        Characteristic axial tensile strength of concrete - 5 % fractile [EN 1992-1-1 - Table 3.1].
        """
        return 0.7 * self.fctm

    @property
    def fctk_095(self) -> float:
        """
        Characteristic acial tensile strength of concrete - 95 % fractile [EN 1992-1-1 - Table 3.1].
        """
        return 1.3 * self.fctm

    @property
    def fctd(self) -> float:
        """
        Design tensile strength [EN 1992-1-1 - §3.1.6 (2)P].
        """
        return self.alpha_ct * self.fctk_005 / self.gamma_c

    @property
    def nu_eq_6N(self) -> float:
        """
        Strength reduction factor for concrete cracked due shear [EN 1992-1-1 - 6.2.1 (6) - eq (6N)].
        """
        return 0.60 * (1 - self.fck / 250)

    @property
    def nu1_eq_69(self) -> float:
        """
        Strength reduction factor for concrete cracked due shear [EN 1992-1-1 - 6.2.3 (3) - eq (6.9)].
        """
        return self.nu_eq_6N

    @property
    def modul_Ecm(self) -> float:
        """
        Secant modulus of elasticity of concrete [EN 1992-1-1 - Table 3.1].
        """
        return 22 * (self.fcm / 10) ** 0.3 * 10**3

    @property
    def modul_Ec_eff(self) -> float:
        """
        Effective modulus of elasticity of concrete accounting for creep deformations [EN 1992-1-1 - eq (7.20)].
        """
        return self.modul_Ecm / (1 + self.phi_creep)

    @property
    def modul_Ecd(self) -> float:
        """
        Design value of the modulus of elasticity of concrete accounting for creep deformations [EN 1992-1-1 - eq (5.20)].
        """
        return self.modul_Ecm / 1.2

    @property
    def modul_Ecd_eff(self) -> float:
        """
        Design effective modulus of elasticity of concrete accounting for creep deformations [EN 1992-1-1 - eq (5.27)].
        """
        return self.modul_Ecd / (1 + self.phi_creep)

    @functools.cached_property
    def _epsilon_c1(self) -> float:
        """
        Compressive strain in the concrete at the peak strenght fc [EN 1992-1-1 - Table 3.1].
        """
        return min(0.7 * self.fcm**0.31, 2.8) * 10 ** (-3)

    @functools.cached_property
    def _epsilon_cu1(self) -> float:
        """
        Ultimate compressive strain in the concrete [EN 1992-1-1 - Table 3.1].
        """
        return min(2.8 + 27 * ((98 - self.fcm) / 100) ** 4, 3.5) * 10 ** (-3)

    @functools.cached_property
    def _epsilon_c2(self) -> float:
        """
        Compressive strain in the concrete at the peak strenght fc [EN 1992-1-1 - Table 3.1].
        """
        if self.fck <= 50:
            return 2.0 * 10 ** (-3)
        else:
            return (2 + 0.085 * (self.fck - 50) ** 0.53) * 10 ** (-3)

    @functools.cached_property
    def _epsilon_cu2(self) -> float:
        """
        Ultimate compressive strain in the concrete [EN 1992-1-1 - Table 3.1].
        """
        return min(2.6 + 35 * ((90 - self.fck) / 100) ** 4, 3.5) * 10 ** (-3)

    @functools.cached_property
    def _epsilon_c3(self) -> float:
        """
        Compressive strain in the concrete at the peak strenght fc [EN 1992-1-1 - Table 3.1].
        """
        return max(1.75 + 0.55 * ((self.fck - 50) / 40), 1.75) * 10 ** (-3)

    @functools.cached_property
    def _epsilon_cu3(self) -> float:
        """
        Ultimate compressive strain in the concrete [EN 1992-1-1 - Table 3.1].
        """
        return min(2.6 + 35 * ((90 - self.fck) / 100) ** 4, 3.5) * 10 ** (-3)

    @property
    def epsilon_c(self) -> float:
        """
        Returns the compressive strain in the concrete at the peak stress fc, according to the diagram type
        """
        if self.diagram_type == self.tuple_diagram_type[0]:
            return None
        elif self.diagram_type == self.tuple_diagram_type[1]:
            return None
        elif self.diagram_type == self.tuple_diagram_type[2]:
            return self._epsilon_c1
        elif self.diagram_type == self.tuple_diagram_type[3]:
            return self._epsilon_c2
        elif self.diagram_type == self.tuple_diagram_type[4]:
            return self._epsilon_c3
        elif self.diagram_type == self.tuple_diagram_type[5]:
            return self._epsilon_c3
        else:
            return None

    @property
    def epsilon_cu(self) -> float:
        """
        Returns the ultimate compressive strain in the concrete, according to the diagram type
        """
        if self.diagram_type == self.tuple_diagram_type[0]:
            return None
        elif self.diagram_type == self.tuple_diagram_type[1]:
            return None
        elif self.diagram_type == self.tuple_diagram_type[2]:
            return self._epsilon_cu1
        elif self.diagram_type == self.tuple_diagram_type[3]:
            return self._epsilon_cu2
        elif self.diagram_type == self.tuple_diagram_type[4]:
            return self._epsilon_cu3
        elif self.diagram_type == self.tuple_diagram_type[5]:
            return self._epsilon_cu3
        else:
            return None

    @functools.cached_property
    def _n_2(self) -> float:
        """
        n2 parameter according to Table 3.1 of EN 1992-1-1.
        """
        return min(1.4 + 23.4 * ((90 - self.fck) / 100) ** 4, 2.0)

    @functools.cached_property
    def _lambda_3(self) -> float:
        """
        Factor lambda, defining the effective height of the compression zone for the ULS rectangular diagram.
        """
        return min(0.8 - (self.fck - 50) / 400, 0.8)

    @functools.cached_property
    def _eta_3(self) -> float:
        """
        Factor eta, defining the effective concrete strength for the ULS rectangular diagram.
        """
        return min(1 - (self.fck - 50) / 200, 1.0)

    def set_gamma_c(self, gamma_c: float) -> None:
        """
        Modifies the partial coefficient gamma_c (default value is 1.5).
        """
        self.gamma_c = gamma_c
        return None

    def set_phi_creep(self, phi_creep: float) -> None:
        """
        Modifies the creep coefficient (default value is 0.).
        """
        self.phi_creep = phi_creep
        return None

    def set_diagram_type(self, diagram_type: str) -> None:
        """
        Modifies the diagram type of the concrete (default value is 'uls_parabola').
        @param diagram_type: Type of stress / strain diagram, with :
            ['sls_uncracked']
            ['sls_cracked']
            ['uls_sargin']
            ['uls_parabola']
            ['uls_rectangle']
            ['uls_bi_linear']
        """
        self.diagram_type = diagram_type.lower()
        self.ensure_valid_diagram_type()
        return None

    def get_stress(self, epsilon) -> float:
        """
        Returns the stress in the concrete for the given strain, according to the diagram type
        """
        if self.diagram_type == self.tuple_diagram_type[0]:
            return self.diagram_sls_uncracked(epsilon)
        elif self.diagram_type == self.tuple_diagram_type[1]:
            return self.diagram_sls_cracked(epsilon)
        elif self.diagram_type == self.tuple_diagram_type[2]:
            return self.diagram_uls_sargin(epsilon)
        elif self.diagram_type == self.tuple_diagram_type[3]:
            return self.diagram_uls_parabola(epsilon)
        elif self.diagram_type == self.tuple_diagram_type[4]:
            return self.diagram_uls_rectangle(epsilon)
        elif self.diagram_type == self.tuple_diagram_type[5]:
            return self.diagram_uls_bi_linear(epsilon)
        else:
            return 0

    def diagram_sls_uncracked(self, epsilon: float) -> float:
        """
        Perfectly elastic stress-strain diagram (including tension)
        No stress limitation

        @param epsilon: The strain in the concrete - [-]
        @return: The stress level in the concrete for epsilon - [MPa]
        """
        return epsilon * self.modul_Ecm / (1 + self.phi_creep)

    def diagram_sls_cracked(self, epsilon: float, sigma_lim: float = 0) -> float:
        """
        Elastic stress-strain diagram (no tension)
        No stress limitation

        @param epsilon: The strain in the concrete - [-]
        @param sigma_lim: Limited tensile stress in concrete - [MPa]
        @return: The compressive stress level in the concrete for epsilon - [MPa]
        """
        sigma = epsilon * self.modul_Ecm / (1 + self.phi_creep)
        return sigma if sigma >= sigma_lim else 0

    def diagram_uls_sargin(self, epsilon: float) -> float:
        """
        Stress-strain relation for concrete in compression (Sargin or "real" diagram)

        @param epsilon: The strain in the concrete - [-]
        @return: The compressive stress level in the concrete for epsilon - [MPa]
        """
        epsilon_c_eff = self._epsilon_c1 * (1 + self.phi_creep)
        epsilon_cu_eff = self._epsilon_cu1 * (1 + self.phi_creep)
        if epsilon <= 0:
            stress = 0
        elif epsilon <= epsilon_cu_eff:
            eta = epsilon / epsilon_c_eff
            module_cd = self.modul_Ecm / 1.2
            module_cd_eff = module_cd / (1 + self.phi_creep)
            k = 1.05 * module_cd_eff * epsilon_c_eff / (self.fcd)
            stress = self.fcd * (k * eta - eta**2) / (1 + (k - 2) * eta)
        else:
            stress = 0

        return stress

    def diagram_uls_parabola(self, epsilon: float) -> float:
        """
        Parabola-rectangle diagram for concrete under compression

        @param epsilon: The strain in the concrete - [-]
        @return: The compressive stress level in the concrete for epsilon - [MPa]
        """
        if epsilon <= 0:
            stress = 0
        elif epsilon <= self._epsilon_c2:
            stress = self.fcd * (1 - (1 - epsilon / self._epsilon_c2) ** self._n_2)
        elif epsilon <= self._epsilon_cu2:
            stress = self.fcd
        else:
            stress = 0

        return stress

    def diagram_uls_rectangle(self, epsilon: float) -> float:
        """
        Rectangular stress distribution for concrete under compression

        @param epsilon: The strain in the concrete - [-]
        @return: The compressive stress level in the concrete for epsilon - [MPa]
        """
        if epsilon <= (1 - self._lambda_3) * self._epsilon_cu3:
            stress = 0
        elif epsilon <= self._epsilon_cu3:
            stress = self._eta_3 * self.fcd
        else:
            stress = 0

        return stress

    def diagram_uls_bi_linear(self, epsilon: float) -> float:
        """
        Bi-linear stress-strain relation for concrete under compression

        @param epsilon: The strain in the concrete - [-]
        @return: The compressive stress level in the concrete for epsilon - [MPa]
        """
        if epsilon <= 0:
            stress = 0
        elif epsilon <= self._epsilon_c3:
            stress = self.fcd * epsilon / self._epsilon_c3
        elif epsilon <= self._epsilon_cu3:
            stress = self.fcd
        else:
            stress = 0

        return stress

    def plot_curve(
        self, initial_strain: float = -0.001, final_strain: float | None = None
    ):
        """
        Prints the strain / stress curve according to the selected diagram type.
        """
        if final_strain == None:
            final_strain = self._epsilon_cu1 + 0.0001
        strain = []
        stress = []
        epsilon = initial_strain

        while epsilon <= final_strain:
            strain.append(epsilon)
            stress.append(self.get_stress(epsilon))
            epsilon += 0.0001

        fig, cb_strain_stress = plt.subplots()
        cb_strain_stress.plot(strain, stress)
        cb_strain_stress.set(
            xlabel="Déformation [‰]",
            ylabel="Contrainte [MPa]",
            title="Loi contrainte / déformation du béton",
        )
        cb_strain_stress.grid()
        plt.show

        return None

    def __str__(self) -> str:
        instance_name = [
            k for k, v in inspect.currentframe().f_back.f_locals.items() if v is self
        ][0]
        result = f"Material Definition - EC2 Concrete:  {instance_name}\n"
        result += f"\tCharacteristic compressive strength: fck = { self.fck} MPa\n"
        result += f"\tSecant modulus of elasticity: Ecm = {round(self.modul_Ecm/1000, 1)} GPa\n"
        result += f"\tCreep coefficient: \u03C6 = {self.phi_creep}\n"
        return result
