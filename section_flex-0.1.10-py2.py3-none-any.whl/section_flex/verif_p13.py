# Standard library imports
import math
import time

# Third party imports
from rich import print
import numpy as np

# Local applications imports
import materia
from geometry.circle import Circle
from geometry.point import Point
from geometry.polygon import Polygon
from geometry.vector import Vector
from materia import EC2Concrete, SteelRebar, FibreReinforcedPolymer
from section.concrete_section import ConcreteSection
from section.frp_strips import FRPStrips
from section.grid import Grid
from section.region import Region
from section.plane_of_deformation import PlaneOfDeformation
from section.rebars import Rebars
from section.frp_strips import FRPStrips
from section.create_section import create_circular_section, create_annular_section, create_concrete_section

start_time = time.time()

C30 = EC2Concrete(30, diagram_type="uls_parabola")
C40 = EC2Concrete(40, diagram_type="uls_parabola")
TFC = FibreReinforcedPolymer()
B500B = SteelRebar(gamma_s=1.15)
B500B_prefa = SteelRebar(gamma_s=1.10)

bw = 1
hw = 0.24
As_sup = 5e-4
es_sup = 0.055
As_inf = 10e-4
es_inf = 0.06

Af = 10e-4


point_a = Point(-bw/2, -hw/2)
point_b = Point(bw/2, -hw/2)
point_c = Point(bw/2, hw/2)
point_d = Point(-bw/2, hw/2)
pt_ha_inf = Point(0, -hw/2 + es_inf)
pt_ha_sup = Point(0, hw/2 - es_sup)
pt_af_inf = Point(0, -hw/2)
rebar_As_inf = Rebars(0, As_inf, B500B, [pt_ha_inf], 1)
rebar_As_sup = Rebars(0, As_sup, B500B, [pt_ha_sup], 2)
tfc_Af_inf = FRPStrips(0, Af, TFC, [pt_af_inf], 1)

poly1 = Polygon([point_a, point_b, point_c, point_d])
reg1 = Region(0, [poly1], C30)
R_section = ConcreteSection([reg1], [rebar_As_inf, rebar_As_sup], [tfc_Af_inf], 0.5, 0.0012)

R_section.plot_geometry_v2()
print(f"Mrd_max = {R_section.Mrd_max(0): .2f} kN.m")

pod = R_section.from_forces_to_curvature(0, 100, 0)
print(R_section.rebars_internal_state(pod))
print(R_section.frp_internal_state(pod))
print(R_section.concrete_internal_state(pod))

# pod = R_section.from_forces_to_curvature(0, -55., 0)
# print(R_section.from_curvature_to_forces(pod))
# print(R_section.concrete_internal_state(pod))
# print(R_section.rebars_internal_state(pod))
# R_section.plot_interaction_diagram_v2(
#     theta=0,
#     finess=0,
#     zones=[1, 4],
#     # add_points=[(0, 42.5)]
# )

C30 = EC2Concrete(30, diagram_type="uls_rectangle", )
C40 = EC2Concrete(40, diagram_type="uls_rectangle")
B500B = SteelRebar(gamma_s=1.15)

M_elu = 0.8
bw = 0.3
hw = 0.7
ds = 0.6
dsc = 0.08
B500B.set_ductility_class("H")

As_sup = 0
As_inf = 40.64e-4

point_a = Point(-bw/2, -hw/2)
point_b = Point(bw/2, -hw/2)
point_c = Point(bw/2, hw/2)
point_d = Point(-bw/2, hw/2)
pt_ha_inf = Point(0, hw/2 - ds)
pt_ha_sup = Point(0, hw/2 - dsc)
rebar_As_inf = Rebars(0, As_inf, B500B_prefa, [pt_ha_inf], 1)
rebar_As_sup = Rebars(0, As_sup, B500B_prefa, [pt_ha_sup], 2)

poly1 = Polygon([point_a, point_b, point_c, point_d])
reg1 = Region(0, [poly1], C40)
R_section = ConcreteSection([reg1], [rebar_As_inf, rebar_As_sup], [], 0.01, 0.01)
R_section.plot_geometry_v2()
print(R_section.Mrd_max())
