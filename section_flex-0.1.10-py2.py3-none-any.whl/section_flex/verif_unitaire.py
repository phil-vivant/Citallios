
import materia
from rectangle_section import RectangleSection
from check_shear_wall import CheckShearWall
from rich import print

from section_flex import ConcreteSection
from section_flex.geometry.point import Point
from section_flex.geometry.polygon import Polygon
from section_flex.section.region import Region
from section_flex.section.rebars import Rebars
from section_flex.section.frp_strips import FRPStrips

import os
#print('\n \n', os.getcwd(), '\n \n')

B30 = materia.EC2Concrete(
    fck=30,
    diagram_type="uls_parabola",
    gamma_c=1.3,
    alpha_cc=1,
    alpha_ct=1,
    phi_creep=0,
)
B25 = materia.EC2Concrete(
    fck=25,
    diagram_type="uls_parabola",
    gamma_c=1.3,
    alpha_cc=1,
    alpha_ct=1,
    phi_creep=0,
)
B500B = materia.SteelRebar(
    ductility_class="B",
    yield_strength_fyk=500,
    young_modulus_es=200000,
    diagram_type="uls",
    tension_only=False,
    gamma_s=1,
)
TFC = materia.TFC_350


torseurs = [(1, 0.5, 0.5), (0, 1.8, 0.5)]

R_section = RectangleSection(
    concrete=B30,
    steel_rebar=B500B,
    frp_material=TFC,
    bw = 0.22,
    h = 2.5,
    As1 = 10e-4,
    As2 = 10e-4,
    es1 = 0.20,
    es2 = 0.20,
    Asrs = 5e-4,
    Asws = 7e-4,
    type = "voile",
)


shear_wall = CheckShearWall(
    section = R_section,
    torseurs = torseurs,
    panel_height = 3.5,
    stiffener = 0,
    rugosite = "rugueuse",
)

print (shear_wall.results)


bw = 0.2
h = 7.08
As1 = 8.04248e-4
As2 = 9.1e-4
As3 = 9.1e-4
As4 = 8.04248e-4
es1 = 0.15
es2 = 0.885
es3 = 6.195
es4 = 6.93


point_a = Point(-bw/2, -h/2)
point_b = Point(bw/2, -h/2)
point_c = Point(bw/2, h/2)
point_d = Point(-bw/2, h/2)
pt_s1 = Point(0, h/2 - es1)
pt_s2 = Point(0, h/2 - es2)
pt_s3 = Point(0, h/2 - es3)
pt_s4 = Point(0, h/2 - es4)



As1 = Rebars(0, As1, B500B, [pt_s1], 1)
As2 = Rebars(0, As2, B500B, [pt_s2], 2)
As3 = Rebars(0, As3, B500B, [pt_s3], 3)
As4 = Rebars(0, As4, B500B, [pt_s4], 4)
Asm = Rebars(0, 17.1e-4, B500B, [Point(0, 3), Point(0, -3)], 4)
FRP = FRPStrips(0, 0e-4, TFC, [Point(0, -h/2), Point(0, h/2)], 1)

poly = Polygon([point_a, point_b, point_c, point_d])
reg = Region(0, [poly], B25)

fibre_size_y = bw / 2
fibre_size_z = max(h / 200, 0.01)

# voile = ConcreteSection([reg], [As1, As2, As3, As4], [FRP], fibre_size_y, fibre_size_z)
voile = ConcreteSection([reg], [Asm], [], fibre_size_y, fibre_size_z)

voile.plot_geometry()
plan = voile.from_forces_to_curvature(nx=1440, my=10050, mz=0)
print(voile.from_curvature_to_forces(plan))
print(voile.concrete_internal_state(plan))
print(voile.rebars_internal_state(plan))
print(voile.frp_internal_state(plan))

print(voile.compression_force(plan))
print(voile.compressed_area(plan))

voile.plot_NM_interaction_diagram(
    theta=0,
    finess=0,
    negatif=False,
    add_curves=[[[0, 0]]],
)

print(voile.Mrd_max())
