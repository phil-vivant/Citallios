# Standard library imports
import math
from dataclasses import dataclass

# Third party imports

# Local applications imports
from materia import EC2Concrete
from section_flex.geometry.nums import is_close_to_zero
from section_flex.geometry.geom_functions import principal_directions
from section_flex.geometry.point import Point
from section_flex.geometry.polygon import Polygon


@dataclass
class Region:

    initial_phase: int
    polygons: list[Polygon]
    material: EC2Concrete

    def __post_init__(self):
        self.ensure_valid_material()
        self.ensure_valid_section()
        self.geom_properties = self.geometric_properties()
        self.geom_stiffness = self.geometric_stiffness()
        self.principal_directions = principal_directions(
            self.moment_inertia_yg,
            self.moment_inertia_zg,
            self.product_inertia_yzg
        )

    def ensure_valid_material(self):
        if not self.concrete_material():
            raise ValueError(f"Inconsistent material: EC2 Concrete expected")

    def concrete_material(self) -> bool:
        return isinstance(self.material, EC2Concrete)

    def ensure_valid_section(self):
        if self.overlapping_polygons():
            raise ValueError(f"Inconsistent Section: Overlapping Polygons")

    def overlapping_polygons(self) -> bool:
        count = 0
        for i in range(len(self.polygons)):
            for j in range(i+1, len(self.polygons)):
                count += self.polygons[i].overlaps_with_polygon(self.polygons[j])
        return True if count > 0 else False

    def inside_count(self, polygon) -> int:
        count = 0
        for poly in self.polygons:
            count += polygon.is_inside_polygon(poly)
        return count

    def is_void(self, polygon) -> bool:
        if self.inside_count(polygon) % 2 == 0:
            return False
        return True

    @property
    def lower_boundary(self) -> Point:
        mini_y = min(poly.lower_boundary.y for poly in self.polygons)
        mini_z = min(poly.lower_boundary.z for poly in self.polygons)
        return Point(mini_y, mini_z)

    @property
    def upper_boundary(self) -> Point:
        maxi_y = max(poly.upper_boundary.y for poly in self.polygons)
        maxi_z = max(poly.upper_boundary.z for poly in self.polygons)
        return Point(maxi_y, maxi_z)

    @property
    def area(self) -> float:
        return self.geom_properties[0]

    @property
    def centroid(self) -> Point:
        return Point(
            self.geom_properties[1],
            self.geom_properties[2],
        )

    @property
    def first_moment_yo(self) -> float:
        return self.geom_properties[3]

    @property
    def first_moment_zo(self) -> float:
        return self.geom_properties[4]

    @property
    def moment_inertia_yo(self) -> float:
        return self.geom_properties[5]

    @property
    def moment_inertia_zo(self) -> float:
        return self.geom_properties[6]

    @property
    def product_inertia_yzo(self) -> float:
        return self.geom_properties[7]

    @property
    def moment_inertia_yg(self) -> float:
        return self.moment_inertia_yo - self.area * self.centroid.z ** 2

    @property
    def moment_inertia_zg(self) -> float:
        return self.moment_inertia_zo - self.area * self.centroid.y ** 2

    @property
    def product_inertia_yzg(self) -> float:
        inertia_yzg = self.product_inertia_yzo - self.area * self.centroid.y * self.centroid.z
        if is_close_to_zero(inertia_yzg):
            return 0.0
        else:
            return inertia_yzg

    @property
    def alpha_rad(self) -> float:
        return self.principal_directions[0]

    @property
    def alpha_deg(self) -> float:
        return self.alpha_rad * 180 / math.pi

    @property
    def moment_inertia_1(self) -> float:
        return self.principal_directions[1]

    @property
    def moment_inertia_2(self) -> float:
        return self.principal_directions[2]

    def geometric_properties(self) -> list[float]:
        area = 0.0
        first_moment_yo = 0.0
        first_moment_zo = 0.0
        moment_inertia_yo = 0.0
        moment_inertia_zo = 0.0
        product_inertia_yzo = 0.0

        for poly in self.polygons:
            if self.is_void(poly):
                sign = -1
            else:
                sign = +1
            area += sign * poly.area
            first_moment_yo += sign * poly.first_moment_yo
            first_moment_zo += sign * poly.first_moment_zo
            moment_inertia_yo += sign * poly.moment_inertia_yo
            moment_inertia_zo += sign * poly.moment_inertia_zo
            product_inertia_yzo += sign * poly.product_inertia_yzo

        centroid_y = first_moment_zo / area
        centroid_z = first_moment_yo / area

        return [
            area,
            centroid_y,
            centroid_z,
            first_moment_yo,
            first_moment_zo,
            moment_inertia_yo,
            moment_inertia_zo,
            product_inertia_yzo
        ]

    def geometric_stiffness(self) -> list[float]:
        e_area = 0.0
        e_first_moment_yo = 0.0
        e_first_moment_zo = 0.0
        e_moment_inertia_yo = 0.0
        e_moment_inertia_zo = 0.0
        e_product_inertia_yzo = 0.0

        for poly in self.polygons:
            if self.is_void(poly):
                sign = -1
            else:
                sign = +1
            e_area += sign * poly.area * self.material.modul_Ecm
            e_first_moment_yo += sign * poly.first_moment_yo * self.material.modul_Ecm
            e_first_moment_zo += sign * poly.first_moment_zo * self.material.modul_Ecm
            e_moment_inertia_yo += sign * poly.moment_inertia_yo * self.material.modul_Ecm
            e_moment_inertia_zo += sign * poly.moment_inertia_zo * self.material.modul_Ecm
            e_product_inertia_yzo += sign * poly.product_inertia_yzo * self.material.modul_Ecm

        return [
            e_area,
            e_first_moment_yo,
            e_first_moment_zo,
            e_moment_inertia_yo,
            e_moment_inertia_zo,
            e_product_inertia_yzo
        ]
