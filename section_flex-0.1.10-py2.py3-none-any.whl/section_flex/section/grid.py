# Standard library imports
import math
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry.polygon import Point
from section_flex.section.mesh import Mesh


@dataclass
class Grid:
    lower_boundary: Point
    upper_boundary: Point
    mesh_size_y: float
    mesh_size_z: float

    def __post_init__(self):
        self.meshes = self.get_meshes()

    @property
    def number_of_columns(self) -> int:
        return math.ceil((self.upper_boundary.y - self.lower_boundary.y) / self.mesh_size_y)

    @property
    def number_of_rows(self) -> int:
        return math.ceil((self.upper_boundary.z - self.lower_boundary.z) / self.mesh_size_z)

    @property
    def total_number_of_meshes(self) -> int:
        return self.number_of_columns * self.number_of_rows

    @property
    def mesh_area(self) -> float:
        return self.mesh_size_y * self.mesh_size_z

    def mesh_id(self, m: int, n: int) -> int | None:
        if m > self.number_of_rows or n > self.number_of_columns:
            return None
        else:
            coeff = max(self.number_of_rows, self.number_of_columns)
            return m * coeff + n

    def mesh_position(self, m: int, n: int) -> Point:
        _y = self.lower_boundary.y + (n - 1 / 2) * self.mesh_size_y
        _z = self.lower_boundary.z + (m - 1 / 2) * self.mesh_size_z
        return Point(_y, _z)

    def get_nm_from_id(self, _id: int) -> tuple[int]:
        coeff = max(self.number_of_rows, self.number_of_columns)
        m = math.floor(_id / coeff)
        n = _id - m * coeff
        return m, n

    def get_meshes(self) -> list[Mesh]:
        _meshes = []
        for m in range(1, self.number_of_rows + 1):
            for n in range(1, self.number_of_columns + 1):
                _id = self.mesh_id(m, n)
                mesh_mn = Mesh(_id, self.mesh_position(m, n), self.mesh_size_y, self.mesh_size_z)
                _meshes.append(mesh_mn)
        return _meshes
