# Standard library imports
import math

# Third party imports
from rich import print

# Local applications imports
from section_flex.geometry.point import Point
from section_flex.geometry.circle import Circle
from section_flex.geometry.polygon import Polygon
from materia import EC2Concrete, SteelRebar, FibreReinforcedPolymer
from section.concrete_section import ConcreteSection
from section_flex.section.frp_strips import FRPStrips
from section_flex.section.region import Region
from section_flex.section.rebars import Rebars
from section_flex.section.frp_strips import FRPStrips


def create_concrete_section(
        concrete: EC2Concrete,
        coffrage: list[tuple[float, float]],
        steel: SteelRebar,
        rebars: dict[int: [float, float, float]],
        frp_material = FibreReinforcedPolymer | None,
        frp_strips = dict[int: [float, float, float]] | None,
) -> ConcreteSection:

    # Coffrage
    points = []
    for position in coffrage:
        points.append(Point(position[0], position[1]))
    polygon = Polygon(points)
    region = [Region(0, [polygon], concrete)]

    # List of rebars
    HA = []
    for key, value in rebars.items():
        area = value[0]
        position = Point(value[1], value[2])
        HA.append(Rebars(0, area=area, material=steel, positions=[position], first_idx=key))

    # List of FRP Strips
    FRP = []
    if isinstance(frp_material, FibreReinforcedPolymer) and frp_strips != None:
        for key, value in frp_strips.items():
            area = value[0]
            position = Point(value[1], value[2])
            FRP.append(FRPStrips(0, area=area, material=frp_material, positions=[position], first_idx=key))

    return ConcreteSection(region, HA, FRP, 0.01, 0.01)


def circular_poly(diameter: float, center: Point=Point(0,0), divisions: int=64) -> Polygon:
    """Création du polygone définissant une section circulaire.

    Args:
        diamter (float): _description_
        center (Point, optional): _description_. Defaults to Point(0,0).

    Returns:
        Polygon: _description_
    """
    return Circle(center, diameter / 2).to_polygon(divisions)


def rebar_circular_layout(diameter: float, nb_rebars: int, center: Point=Point(0, 0)) -> list[Point]:
    """Renvoie la liste de point pour une disposition circulaire des armatures.

    Args:
        diameter (float): Diamètre du contour des armatures
        nb_rebar (int): Nombre de barres à disposer sur le contour
        center (Point, optional): Position du centre du contour. Defaults to Point(0, 0).

    Returns:
        list[Point]: Renvoie la liste de points (un point par barre).
    
    Attention:
        Si nb_rebars = 1, l'armature est positionnée au centre du cercle.
    """

    if nb_rebars == 0:
        return []

    if nb_rebars == 1:
        return [center]

    theta = 2 * math.pi / nb_rebars
    theta_0 = theta_offset(nb_rebars)
    acc = []

    if nb_rebars <=8:
        theta_0 = theta_offset(nb_rebars)
    else:
        theta_0 = 0

    for i in range(nb_rebars):
        y = diameter / 2 * math.cos(theta_0 + i * theta) + center.y
        z = diameter / 2 * math.sin(theta_0 + i * theta) + center.z
        acc.append(Point(y, z))

    return acc

def theta_offset(nb_rebars: int) -> float:
    """Détermination du décalage angulaire pour le positionnement des armatures circulaires.

    Args:
        nb_rebars (int): Nombre de barres dans la section.

    Returns:
        float: Angle en [radians].
    
    Nous avons suivi le principe suivant :
      - Lorsque le nombre d'armatures est inférieur ou égal à 3 :
          L'armature inférieure est positionnée le plus bas possible.
      - Sinon :
          Les armatures inférieures sont positionnées le plus haut possible.
      A partir de 8 barres, nous estimons que le décalage angulaire est négligeable.
    """
    theta_offset = {
        2: -1/2,
        3: -1/6,
        4: 1/4,
        5: 1/10,
        6: 1/3,
        7: -1/14,
        8: 1/8,
    }

    if nb_rebars <=8:
        return math.pi * theta_offset[nb_rebars]
    else:
        return 0




def create_circular_section(
        concrete_material: EC2Concrete,
        rebar_material: SteelRebar,
        concrete_diameter: float,
        rebar_number: int,
        rebar_area: float,
        rebar_cover: float
) -> ConcreteSection:
    # Definition du coffrage:
    coff = circular_poly(concrete_diameter)
    circular_region = Region(0, [coff], concrete_material)

    # Définition des armatures:
    ha_diameter = concrete_diameter - rebar_cover
    ha_positions = rebar_circular_layout(ha_diameter, rebar_number)
    rebars = Rebars(0, rebar_area, rebar_material, ha_positions, 1)

    circular_section = ConcreteSection(
        regions=[circular_region],
        rebars=[rebars],
        frp_strips=[],
        fibre_size_y=0.01,
        fibre_size_z=0.01,
    )

    return circular_section


def create_annular_section(
        concrete_material: EC2Concrete,
        rebar_material: SteelRebar,
        concrete_diameter: tuple[float, float],
        rebar_number: tuple[int, int],
        rebar_area: tuple[float, float],
        rebar_cover: tuple[float, float],
) -> ConcreteSection:

    concrete_out_diameter = concrete_diameter[0]
    concrete_int_diameter = concrete_diameter[1]
    rebar_out_number = rebar_number[0]
    rebar_int_number = rebar_number[1]
    rebar_out_area = rebar_area[0]
    rebar_int_area = rebar_area[1]
    rebar_out_cover = rebar_cover[0]
    rebar_int_cover = rebar_cover[1]


    # Definition du coffrage:
    coff_out = circular_poly(concrete_out_diameter)
    coff_int = circular_poly(concrete_int_diameter)
    annular_region = Region(0, [coff_out, coff_int], concrete_material)

    # Définition des armatures - contour exterieur:
    ha_out_diameter = concrete_out_diameter - rebar_out_cover
    ha_out_positions = rebar_circular_layout(ha_out_diameter, rebar_out_number)
    rebars_out = Rebars(0, rebar_out_area, rebar_material, ha_out_positions, 1)

    # Définition des armatures - contour interieur:
    ha_int_diameter = concrete_int_diameter + rebar_int_cover
    ha_int_positions = rebar_circular_layout(ha_int_diameter, rebar_int_number)
    rebars_int = Rebars(0, rebar_int_area, rebar_material, ha_int_positions, rebar_out_area + 1)

    annular_section = ConcreteSection(
        regions=[annular_region],
        rebars=[rebars_out, rebars_int],
        frp_strips=[],
        fibre_size_y=0.01,
        fibre_size_z=0.01,
    )

    return annular_section
