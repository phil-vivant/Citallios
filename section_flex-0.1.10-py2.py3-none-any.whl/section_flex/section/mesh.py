# Standard library imports
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry.polygon import Point


@dataclass
class Mesh:
    id: int
    position: Point
    mesh_size_y: float
    mesh_size_z: float

    @property
    def area(self) -> float:
        return self.mesh_size_y * self.mesh_size_z

    def __str__(self) -> str:
        result = f"Mesh #{self.id}:\tarea: {self.area:.6f} ;\ty = {self.position.y:.4f} ;\tz = {self.position.z:.4f}"
        return result
