# Standard library imports
import inspect
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.section.plane_of_deformation import PlaneOfDeformation


@dataclass
class PlaneStrainHistory:
    def __post_init__(self):
        self.history = []

    @property
    def initial_plane_strain(self) -> PlaneOfDeformation:
        return self.history[0]

    def get_plane_strain_at_phase(self, phase: int) -> PlaneOfDeformation:
        return self.history[phase]

    def add_plane_strain(self, plane_strain: PlaneOfDeformation):
        self.history.append(plane_strain)

    def clear(self):
        return self.history.clear

    def __str__(self) -> str:
        instance_name = [k for k, v in inspect.currentframe().f_back.f_locals.items() if v is self][0]
        result = f"Plane Strain History: {instance_name}\n"
        for i, plane_strain in enumerate(self.history):
            result += f"\tPhase {i}: {str(plane_strain)}\n"
        return result
