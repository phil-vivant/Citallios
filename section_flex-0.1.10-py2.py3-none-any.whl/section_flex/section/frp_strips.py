# Standard library imports
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry.point import Point
from materia import FibreReinforcedPolymer
from section_flex.section.fibre import Fibre


# Ceci pourrait être plus simplement une fonction qui gère la création des fibres.


@dataclass
class FRPStrips:

    initial_phase: int
    area: float
    material: FibreReinforcedPolymer
    positions: list[Point]
    first_idx: int = 1

    def __post_init__(self):
        self.ensure_valid_material()
        self.list = self.generate_fibres(self.first_idx)

    def ensure_valid_material(self):
        if not self.frp_material():
            raise ValueError(f"Inconsistent material: Fibre Reinforced Polymer expected")

    def frp_material(self) -> bool:
        return isinstance(self.material, FibreReinforcedPolymer)

    @property
    def number_of_strips(self) -> int:
        return len(self.positions)

    def generate_fibres(self, first_idx=1) -> list[Fibre]:
        list_of_frp_strips = []

        for i in range(self.number_of_strips):
            _idx = first_idx + i
            frp_name = f"frp_{_idx}"
            frp_fibre = Fibre(
                name=frp_name,
                initial_phase=self.initial_phase,
                position=self.positions[i],
                area=self.area,
                material=self.material
            )
            list_of_frp_strips.append(frp_fibre)

        return list_of_frp_strips

    @property
    def max_id(self) -> int:
        return self.first_idx + len(self.list)
