# Standard library imports
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.section.fibre import Fibre
from section_flex.section.plane_of_deformation import PlaneOfDeformation
from materia import EC2Concrete
from materia import SteelRebar
from materia import SteelTendon
from materia import FibreReinforcedPolymer


# Pas de raison de gérer le tri des types de fibres ici. à revoir

@dataclass
class Curvature:
    fibres: list[Fibre]
    plane_strain: PlaneOfDeformation
    phase: int

    def __post_init__(self):
        self.concrete_fibres = {}
        self.rebar_fibres = {}
        self.tendon_fibres = {}
        self.frp_fibres = {}
        self.phase_name = f"phase_{self.phase}"
        self.sort_fibres()

    @property
    def global_normal_force(self) -> float:
        return self.global_torsor.nx

    @property
    def global_bending_moment_y(self) -> float:
        return self.global_torsor.my

    @property
    def global_bending_moment_z(self) -> float:
        return self.global_torsor.mz

    @property
    def concrete_torsor(self):
        nx = 0
        my = 0
        mz = 0
        for fibre in self.concrete_fibres:
            nx += fibre.data['force'][f'{self.phase_name}']
            my += fibre.data["moment_y"][f'{self.phase_name}']
            mz += fibre.data["moment_z"][f'{self.phase_name}']
        return SolicitationTorsor(nx, my, mz)

    @property
    def rebar_torsor(self):
        nx = 0
        my = 0
        mz = 0
        for fibre in self.rebar_fibres:
            nx += fibre.data['force'][f'{self.phase_name}']
            my += fibre.data["moment_y"][f'{self.phase_name}']
            mz += fibre.data["moment_z"][f'{self.phase_name}']
        return SolicitationTorsor(nx, my, mz)

    @property
    def tendon_torsor(self):
        nx = 0
        my = 0
        mz = 0
        for fibre in self.rebar_fibres:
            nx += fibre.data['force'][f'{self.phase_name}']
            my += fibre.data["moment_y"][f'{self.phase_name}']
            mz += fibre.data["moment_z"][f'{self.phase_name}']
        return SolicitationTorsor(nx, my, mz)

    @property
    def frp_torsor(self):
        nx = 0
        my = 0
        mz = 0
        for fibre in self.rebar_fibres:
            nx += fibre.data['force'][f'{self.phase_name}']
            my += fibre.data["moment_y"][f'{self.phase_name}']
            mz += fibre.data["moment_z"][f'{self.phase_name}']
        return SolicitationTorsor(nx, my, mz)

    @property
    def global_torsor(self):
        nx = self.concrete_torsor.nx + self.rebar_torsor.nx + self.tendon_torsor.nx + self.frp_torsor.nx
        my = self.concrete_torsor.my + self.rebar_torsor.my + self.tendon_torsor.my + self.frp_torsor.my
        mz = self.concrete_torsor.mz + self.rebar_torsor.mz + self.tendon_torsor.mz + self.frp_torsor.mz
        return SolicitationTorsor(nx, my, mz)

    def global_torsor_without_pt(self):
        nx = self.concrete_torsor.nx + self.rebar_torsor.nx + self.frp_torsor.nx
        my = self.concrete_torsor.my + self.rebar_torsor.my + self.frp_torsor.my
        mz = self.concrete_torsor.mz + self.rebar_torsor.mz + self.frp_torsor.mz
        return SolicitationTorsor(nx, my, mz)

    @property
    def min_concrete_strain(self) -> float:
        return min(fibre.data['epsilon'][f'{self.phase_name}'] for fibre in self.concrete_fibres)

    @property
    def max_concrete_strain(self) -> float:
        return max(fibre.data['epsilon'][f'{self.phase_name}'] for fibre in self.concrete_fibres)

    @property
    def min_concrete_stress(self) -> float:
        return min(fibre.data['sigma'][f'{self.phase_name}'] for fibre in self.concrete_fibres)

    @property
    def max_concrete_stress(self) -> float:
        return max(fibre.data['sigma'][f'{self.phase_name}'] for fibre in self.concrete_fibres)

    @property
    def min_rebar_strain(self) -> float:
        return min(fibre.data['epsilon'][f'{self.phase_name}'] for fibre in self.rebar_fibres)

    @property
    def max_rebar_strain(self) -> float:
        return max(fibre.data['epsilon'][f'{self.phase_name}'] for fibre in self.rebar_fibres)

    @property
    def min_rebar_stress(self) -> float:
        return min(fibre.data['sigma'][f'{self.phase_name}'] for fibre in self.rebar_fibres)

    @property
    def max_rebar_stress(self) -> float:
        return max(fibre.data['sigma'][f'{self.phase_name}'] for fibre in self.rebar_fibres)

    @property
    def min_tendon_strain(self) -> float:
        return min(fibre.data['epsilon'][f'{self.phase_name}'] for fibre in self.tendon_fibres)

    @property
    def max_tendon_strain(self) -> float:
        return max(fibre.data['epsilon'][f'{self.phase_name}'] for fibre in self.tendon_fibres)

    @property
    def min_tendon_stress(self) -> float:
        return min(fibre.data['sigma'][f'{self.phase_name}'] for fibre in self.tendon_fibres)

    @property
    def max_tendon_stress(self) -> float:
        return max(fibre.data['sigma'][f'{self.phase_name}'] for fibre in self.tendon_fibres)

    @property
    def min_frp_strain(self) -> float:
        return min(fibre.data['epsilon'][f'{self.phase_name}'] for fibre in self.frp_fibres)

    @property
    def max_frp_strain(self) -> float:
        return max(fibre.data['epsilon'][f'{self.phase_name}'] for fibre in self.frp_fibres)

    @property
    def min_frp_stress(self) -> float:
        return min(fibre.data['sigma'][f'{self.phase_name}'] for fibre in self.frp_fibres)

    @property
    def max_frp_stress(self) -> float:
        return max(fibre.data['sigma'][f'{self.phase_name}'] for fibre in self.frp_fibres)

    def sort_fibres(self) -> None:
        for fibre in self.fibres:
            if isinstance(fibre.material, EC2Concrete):
                self.concrete_fibres[fibre.index] = fibre
            if isinstance(fibre.material, SteelRebar):
                self.rebar_fibres[fibre.index] = fibre
            if isinstance(fibre.material, SteelTendon):
                self.tendon_fibres[fibre.index] = fibre
            if isinstance(fibre.material, FibreReinforcedPolymer):
                self.frp_fibres[fibre.index] = fibre

    def print_detailed_results(self) -> None:
        concrete_result = f"\nRésultats pour les fibres béton:"
        rebars_result = f"\nRésultats pour les armatures passives:"
        tendons_result = f"\nRésultats pour les armatures actives:"
        frp_result = f"\nRésultats pour les armatures de renfort carbone:"
        for fibre in self.concrete_fibres:
            concrete_result += f"\tFibre # {fibre['index']}:\t\u03B5c = test \u2030"
            concrete_result += f"  -  \u03C3c = {fibre['sigma']:.2f} MPa"
        for fibre in self.rebar_fibres:
            rebars_result += f"\tFibre # {fibre['index']}:\t\u03B5s = test \u2030"
            rebars_result += f"  -  \u03C3s = {fibre['sigma']:.2f} MPa"
        for fibre in self.tendon_fibres:
            tendons_result += f"\tFibre # {fibre['index']}:\t\u03B5p = test \u2030"
            tendons_result += f"  -  \u03C3p = {fibre['sigma']:.2f} MPa"
        for fibre in self.frp_fibres:
            frp_result += f"\tFibre # {fibre['index']}:\t\u03B5f = test \u2030"
            frp_result += f"  -  \u03C3f = {fibre['sigma']:.2f} MPa"
        print(concrete_result)
        print(rebars_result)
        print(tendons_result)
        print(frp_result)
        self.print_summarized_results()

    def print_summarized_results(self) -> None:
        print(f'\nTorseur béton :   N = {self.concrete_torsor.nx:.1f} kN  -  My = {self.concrete_torsor.my:.1f} kN.m'
              f'  -  Mz = {self.concrete_torsor.mz:.1f} kN.m')
        print(f'Torseur HA :        N = {self.rebar_torsor.nx:.1f} kN  -  My = {self.rebar_torsor.my:.1f} kN.m'
              f'  -  Mz = {self.rebar_torsor.mz:.1f} kN.m')
        print(f'Torseur PT :        N = {self.tendon_torsor.nx:.1f} kN  -  My = {self.tendon_torsor.my:.1f} kN.m'
              f'  -  Mz = {self.tendon_torsor.mz:.1f} kN.m')
        print(f'Torseur FRP :       N = {self.frp_torsor.nx:.1f} kN  -  My = {self.frp_torsor.my:.1f} kN.m'
              f'  -  Mz = {self.frp_torsor.mz:.1f} kN.m')
        print(f'Torseur global :    N =  {self.global_torsor.nx:.1f} kN  -  My = {self.global_torsor.my:.1f} kN.m'
              f'  -  Mz = {self.global_torsor.mz: .1f} kN.m')

        print("\nLe torseur global équilibré est donc :")
        print(f"\tN  = {self.global_torsor.nx:.1f} kN")
        print(f"\tMy = {self.global_torsor.my:.1f} kN.m")
        print(f"\tMz = {self.global_torsor.mz:.1f} kN.m")

        print(f'\nLes déformations de la section sont comprises entre :\n\t '
              f'{self.min_concrete_strain:.2f} \u2030   \u2264   \u03B5c   \u2264'
              f'   +{self.max_concrete_strain:.2f} \u2030')

        print(f'Les déformations des armatures HA sont comprises entre :\n\t '
              f'{self.min_rebar_strain:.2f} \u2030   \u2264   \u03B5s   \u2264   +{self.max_rebar_strain:.2f} \u2030')

        print(f'Les déformations des armatures précontraintes sont comprises entre :\n\t '
              f'{self.min_tendon_strain:.2f} \u2030   \u2264   \u03B5p   \u2264   +{self.max_tendon_strain:.2f} \u2030')

        print(f'Les déformations des armatures FRP sont comprises entre :\n\t '
              f'{self.min_frp_strain:.2f} \u2030   \u2264   \u03B5f   \u2264   +{self.max_frp_strain:.2f} \u2030')

        print(f'Les contraintes dans le béton sont comprises entre :\n\t '
              f'{self.min_concrete_stress:.2f} MPa  \u2264   \u03C3c   \u2264   {self.max_concrete_stress:.2f} MPa')

        print(f'Les contraintes dans les armatures HA sont comprises entre :\n\t '
              f'{self.min_rebar_stress:.1f} MPa  \u2264   \u03C3s   \u2264   {self.max_rebar_stress:.1f} MPa')

        print(f'Les contraintes dans les armatures actives sont comprises entre :\n\t '
              f'{self.min_tendon_stress:.1f} MPa  \u2264   \u03C3p   \u2264   {self.max_tendon_stress:.1f} MPa')

        print(f'Les contraintes dans les armatures FRP sont comprises entre :\n\t '
              f'{self.min_frp_stress:.1f} MPa  \u2264   \u03C3f   \u2264   {self.max_frp_stress:.1f} MPa')
