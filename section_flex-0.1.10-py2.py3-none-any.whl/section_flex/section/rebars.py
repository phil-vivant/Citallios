# Standard library imports
import math
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry.point import Point
from materia import SteelRebar
from section_flex.section.fibre import Fibre


# Ceci pourrait être plus simplement une fonction qui gère la création des fibres.


@dataclass
class Rebars:
    initial_phase: int
    area: float
    material: SteelRebar
    positions: list[Point]
    first_idx: int = 1

    def __post_init__(self):
        self.ensure_valid_material()
        self.list = self.generate_fibres()

    def ensure_valid_material(self):
        if not self.rebar_material():
            raise ValueError(f"Inconsistent material: Steel Rebar expected")

    def rebar_material(self) -> bool:
        return isinstance(self.material, SteelRebar)

    @property
    def number_of_rebars(self) -> int:
        return len(self.positions)

    def generate_fibres(self) -> list[Fibre]:
        """
        Returns a list of the rebar fibres from the input.
        """
        list_of_rebars = []

        for i in range(self.number_of_rebars):
            _idx = self.first_idx + i
            rebar_name = f"rebar_{_idx}"
            rebar_fibre = Fibre(
                name=rebar_name,
                initial_phase=self.initial_phase,
                position=self.positions[i],
                area=self.area,
                material=self.material
            )
            list_of_rebars.append(rebar_fibre)

        return list_of_rebars

    def geometric_properties(self) -> list[float]:
        """
        Détermine les propriétés géométriques de l'ensemble des armatures, à partir de la section des barres
        et de leur position.
        @return: liste des propriétés géométriques:
                - area
                - centroid_y
                - centroid_z
                - first_moment_yo
                - first_moment_zo
                - moment_inertia_yo
                - moment_inertia_zo
                - product_inertia_yzo
        """
        area = len(self.positions) * self.area
        first_moment_yo = 0.0
        first_moment_zo = 0.0
        moment_inertia_yo = 0.0
        moment_inertia_zo = 0.0
        product_inertia_yzo = 0.0

        for position in self.positions:
            first_moment_yo += self.area * position.z
            first_moment_zo += self.area * position.y
            moment_inertia_yo += self.area * position.z ** 2
            moment_inertia_zo += self.area * position.y ** 2
            product_inertia_yzo += self.area * position.y  * position.y

        centroid_y = first_moment_zo / area
        centroid_z = first_moment_yo / area

        return [
            area,
            centroid_y,
            centroid_z,
            first_moment_yo,
            first_moment_zo,
            moment_inertia_yo,
            moment_inertia_zo,
            product_inertia_yzo
        ]

    def geometric_stiffness(self) -> list[float]:
        """
        Détermine les raideurs à partir des propriétés géométriques et du module élastique du matériau.
        @return: liste des propriétés géométriques:
                - e_area
                - e_centroid_y
                - e_centroid_z
                - e_first_moment_yo
                - e_first_moment_zo
                - e_moment_inertia_yo
                - e_moment_inertia_zo
        """
        elastic_modulus = self.material.young_modulus_es
        e_area = self.geometric_properties()[0] * elastic_modulus
        e_first_moment_yo = self.geometric_properties()[3] * elastic_modulus
        e_first_moment_zo = self.geometric_properties()[4] * elastic_modulus
        e_moment_inertia_yo = self.geometric_properties()[5] * elastic_modulus
        e_moment_inertia_zo = self.geometric_properties()[6] * elastic_modulus
        e_product_inertia_yzo = self.geometric_properties()[7] * elastic_modulus

        return [
            e_area,
            e_first_moment_yo,
            e_first_moment_zo,
            e_moment_inertia_yo,
            e_moment_inertia_zo,
            e_product_inertia_yzo
        ]

    def principal_directions(self) -> list[float]:
        a1 = self.moment_inertia_yg
        a2 = self.moment_inertia_zg
        b = - self.product_inertia_yzg
        pi = math.pi

        # Angle alpha
        d = a1 - a2
        phi_rad = math.atan(2.0 * b / d)
        if phi_rad < - pi / 2:
            alpha2_rad = phi_rad + pi
        elif phi_rad > pi / 2:
            alpha2_rad = phi_rad - pi
        else:
            alpha2_rad = phi_rad

        alpha_rad = alpha2_rad / 2

        # Values
        if d > 0:
            sign = 1.0
        else:
            sign = -1.0
        h_sum = 1 / 2 * (a1 + a2)
        h_root = 1 / 2 * math.sqrt(d ** 2 + 4 * b ** 2)

        # I1 = a1_star & I2 = a2_star
        a1_star = h_sum + sign * h_root
        a2_star = h_sum - sign * h_root

        return alpha_rad, a1_star, a2_star
