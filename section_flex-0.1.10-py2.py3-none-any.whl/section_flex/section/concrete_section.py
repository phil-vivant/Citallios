# Standard library imports
import math
from dataclasses import dataclass
import functools

# Third party imports
import numpy as np
from numpy.linalg import inv
from scipy.optimize import brentq
import random
import matplotlib.pyplot as plt
from matplotlib.collections import PatchCollection
from matplotlib.patches import Circle as pltCircle
from matplotlib.patches import Polygon as pltPolygon
from intersect import intersection
import plotly.graph_objects as go
import plotly.express as px
from rich import print

# Local applications imports
from section_flex.geometry.geom_functions import principal_directions
from section_flex.geometry.nums import is_close_to_zero
from section_flex.geometry.point import Point
from section_flex.geometry.polygon import Polygon
from materia import EC2Concrete
from materia import SteelRebar
from materia import FibreReinforcedPolymer
from section_flex.results import plotting_curves
from section_flex.section.fibre import Fibre
from section_flex.section.frp_strips import FRPStrips
from section_flex.section.grid import Grid
from section_flex.results.gross_properties import GrossProperties
from section_flex.section.region import Region
from section_flex.section.plane_of_deformation import PlaneOfDeformation
from section_flex.section.rebars import Rebars
from section_flex.solver.newton_raphson_33 import NewtonRaphson33
from section_flex.utils.lists import invert_list
from section_flex.utils.utils_functions import signe


PIVOT_SEQUENCE = [1, 1, 1, 1, 1, 1, 1]


@dataclass
class ConcreteSection:
    """
    Class of Concrete section 
    """
    regions: list[Region]
    rebars: list[Rebars]
    frp_strips: list[FRPStrips]
    fibre_size_y: float = 0.01
    fibre_size_z: float = 0.01

    def __post_init__(self):
        """The fibres are created at the instanciation.
        """
        self.grid = self.generate_grid()
        self.list_of_concrete_fibres = self.create_concrete_fibres()
        self.list_of_rebars = self.compile_rebars()
        self.list_of_frp_strips = self.compile_frp_strips()
        self.list_of_negative_concrete_fibres = self.create_negative_fibres()
        self.list_of_extreme_fibres = self.create_extreme_fibres()

        self.geom_properties = self.geometric_properties()
        self.gross_properties = GrossProperties()
        self.calculate_gross_properties()
        self.ensure_valid_grid()

    def generate_grid(self) -> Grid:
        """Creates a grid build from the boundaries (upper and lower) and the fibre sizes.

        Returns:
            Grid: the grid used to creates the section's fibres
        """
        low_boundary = Point(self.lower_boundary.y - self.fibre_size_y, self.lower_boundary.z - self.fibre_size_z)
        high_boundary = Point(self.upper_boundary.y + self.fibre_size_y, self.upper_boundary.z + self.fibre_size_z)
        return Grid(low_boundary, high_boundary, self.fibre_size_y, self.fibre_size_z)

    @property
    def number_of_concrete_fibres(self) -> int:
        """Number of concrete fibres making up the section.

        Returns:
            int: number of fibres
        """
        return len(self.list_of_concrete_fibres)

    @property
    def number_of_extreme_fibres(self) -> int:
        """Returns the number of extrem fibres in the concrete section

        Returns:
            int: number of extreme fibres
        """
        return len(self.list_of_extreme_fibres)

    @property
    def number_of_rebars(self) -> int:
        """Number of steel rebars fibres.

        Returns:
            int: number of fibres
        """
        return len(self.list_of_rebars)

    @property
    def number_of_frp_strips(self) -> int:
        """Number of FRP fibres.

        Returns:
            int: number of fibres
        """
        return len(self.list_of_frp_strips)

    @property
    def number_of_negative_concrete_fibres(self) -> int:
        """Number of negative concrete fibres

        Returns:
            int: number of fibres
        """
        return len(self.list_of_negative_concrete_fibres)

    @property
    def total_number_of_fibres(self) -> int:
        """Number of fibres (all materials) making up the section.

        Returns:
            int: number of fibres
        """
        total = self.number_of_concrete_fibres + self.number_of_negative_concrete_fibres
        total += self.number_of_rebars + self.number_of_frp_strips
        return total
    
    @property
    def lower_boundary(self) -> Point:
        """Returns the Point() of the lower left angle of the rectangle enveloping the section.

        Returns:
            Point: Point of the lower boundary
        """
        mini_y = min(section.lower_boundary.y for section in self.regions)
        mini_z = min(section.lower_boundary.z for section in self.regions)
        return Point(mini_y, mini_z)

    @property
    def upper_boundary(self) -> Point:
        """Returns the Point() of the upper right angle of the rectangle enveloping the section.

        Returns:
            Point: Point of the upper boundary
        """
        maxi_y = max(section.upper_boundary.y for section in self.regions)
        maxi_z = max(section.upper_boundary.z for section in self.regions)
        return Point(maxi_y, maxi_z)
    
    def ensure_valid_grid(self):
        """Checks that the grid dimensions is envelop of the concrete section.

        Raises:
            ValueError: "The grid does not cover the section geometry!"
        """
        if not self.check_grid_boundaries():
            raise ValueError(f"The grid does not cover the section geometry!")

    def check_grid_boundaries(self) -> bool:
        """Checks that the grid dimensions is envelop of the concrete section.

        Returns:
            bool: True if the grid geometry is correct
        """
        test = 1.
        test *= self.lower_boundary.y > self.grid.lower_boundary.y
        test *= self.lower_boundary.z > self.grid.lower_boundary.z
        test *= self.upper_boundary.y < self.grid.upper_boundary.y
        test *= self.upper_boundary.z < self.grid.upper_boundary.z
        return test

    def create_concrete_fibres(self, first_idx=1) -> list[Fibre]:
        """Generates the concrete fibres from the gross sections definition.

        Args:
            first_idx (int, optional): Index of the first concrete fibres. Defaults to 1.

        Returns:
            list[Fibre]: list of concrete fibres
        """
        list_of_concrete_fibres = []
        _idx = first_idx

        for section in self.regions:
            material = section.material
            initial_phase = section.initial_phase
            for mesh in self.grid.meshes:
                _id = mesh.id
                if self.is_concrete(mesh.position, section.polygons):
                    concrete_fibre_name = f"concrete_fibre_{_idx}"
                    concrete_fibre = Fibre(
                        name=concrete_fibre_name,
                        initial_phase=initial_phase,
                        position=mesh.position,
                        area=mesh.area,
                        material=material
                    )
                    list_of_concrete_fibres.append(concrete_fibre)
                    _idx += 1

        return list_of_concrete_fibres

    def create_extreme_fibres(self, first_idx=1) -> list[Fibre]:
        """Generates the section's extreme fibres.

        Args:
            first_idx (int, optional): Index of the first extreme fibres. Defaults to 1.

        Returns:
            list[Fibre]: list of extreme fibres
        """
        list_of_extreme_fibres = []
        _idx = first_idx

        for section in self.regions:
            material = section.material
            initial_phase = section.initial_phase
            for poly in section.polygons:
                for point in poly.vertices:
                    ext_fibre_name = f"ext_fibre_{_idx}"
                    concrete_fibre = Fibre(
                        name=ext_fibre_name,
                        initial_phase=initial_phase,
                        position=point,
                        area=0,
                        material=material
                    )
                    list_of_extreme_fibres.append(concrete_fibre)
                    _idx += 1

        return list_of_extreme_fibres

    def create_negative_fibres(self, first_idx=1) -> list[Fibre]:
        """
        Création de fibres béton aux droits des armatures HA. Ces fibres béton ont une surface négative.
        Args:
            first_idx:  numérotation de la première fibre

        Returns: une liste de fibres dites "négatives"

        """
        list_of_negative_concrete_fibres = []
        _idx = first_idx

        for rebar in self.list_of_rebars:
            rebar_position = rebar.position
            for section in self.regions:
                section_material = section.material
                if self.is_concrete(rebar_position, section.polygons):
                    negative_fibre_name = f"negative_fibre_{_idx}"
                    concrete_fibre = Fibre(
                        name=negative_fibre_name,
                        initial_phase=rebar.initial_phase,
                        position=rebar_position,
                        area=-1 * rebar.area,
                        material=section_material
                    )
                    list_of_negative_concrete_fibres.append(concrete_fibre)
                    _idx += 1

        return list_of_negative_concrete_fibres

    def compile_rebars(self) -> list[Fibre]:
        """Compile the lists of rebars.

        Returns:
            list[Fibre]: List of rebar fibres
        """
        list_of_rebars = []
        for rebar in self.rebars:
            list_of_rebars.extend(rebar.list)
        return list_of_rebars

    def compile_frp_strips(self) -> list[Fibre]:
        """Compile the lists of frp strips.

        Returns:
            list[Fibre]: List of frp strips fibres
        """
        list_of_frp_strips = []
        for strips in self.frp_strips:
            list_of_frp_strips.extend(strips.list)
        return list_of_frp_strips

    def is_concrete(self, position: Point, polygons: list[Polygon]) -> bool:
        """Checks if a mesh is inside the concrete section.

        Args:
            position (Point): position of the mesh to check
            polys (list[Polygon]): concrete polygons of the section

        Returns:
            bool: True if the mesh is in the concrete
        """
        inside_count = 0
        for poly in polygons:
            inside_count += poly.contains_point(position)
        return (inside_count % 2) != 0

    def calculate_gross_properties(self) -> None:
        """Calculate the geometric gross properties of the concrete section.
        """
        gross_prop = self.gross_properties

        # Propriétés géométriques dans le repère global
        for gross_section in self.regions:
            gross_prop.gross_area += gross_section.area
            gross_prop.e_area += gross_section.area * gross_section.material.modul_Ecm

            gross_prop.gross_first_moment_yo += gross_section.first_moment_yo
            gross_prop.e_first_moment_yo += gross_section.first_moment_yo * gross_section.material.modul_Ecm

            gross_prop.gross_first_moment_zo += gross_section.first_moment_zo
            gross_prop.e_first_moment_zo += gross_section.first_moment_zo * gross_section.material.modul_Ecm

            gross_prop.gross_moment_inertia_yo += gross_section.moment_inertia_yo
            gross_prop.e_moment_inertia_yo += gross_section.moment_inertia_yo * gross_section.material.modul_Ecm

            gross_prop.gross_moment_inertia_zo += gross_section.moment_inertia_zo
            gross_prop.e_moment_inertia_zo += gross_section.moment_inertia_zo * gross_section.material.modul_Ecm

            gross_prop.gross_product_inertia_yzo += gross_section.product_inertia_yzo
            gross_prop.e_product_inertia_yzo += gross_section.product_inertia_yzo * gross_section.material.modul_Ecm

        gross_centroid_y = gross_prop.gross_first_moment_zo / gross_prop.gross_area
        gross_centroid_z = gross_prop.gross_first_moment_yo / gross_prop.gross_area
        gross_prop.gross_centroid = Point(gross_centroid_y, gross_centroid_z)

        e_centroid_y = gross_prop.e_first_moment_zo / gross_prop.e_area
        e_centroid_z = gross_prop.e_first_moment_yo / gross_prop.e_area
        gross_prop.e_centroid = Point(e_centroid_y, e_centroid_z)

        # Propriétés géométriques au niveau du CDG de la section
        gross_prop.gross_moment_inertia_yg = gross_prop.gross_moment_inertia_yo - \
                                             gross_prop.gross_area * gross_prop.gross_centroid.z ** 2
        gross_prop.e_moment_inertia_yg = gross_prop.e_moment_inertia_yo \
                                         - gross_prop.e_area * gross_prop.e_centroid.z ** 2

        gross_prop.gross_moment_inertia_zg = gross_prop.gross_moment_inertia_zo \
                                             - gross_prop.gross_area * gross_prop.gross_centroid.y ** 2
        gross_prop.e_moment_inertia_zg = gross_prop.e_moment_inertia_zo \
                                         - gross_prop.e_area * gross_prop.e_centroid.y ** 2

        gross_inertia_yzg = gross_prop.gross_product_inertia_yzo - gross_prop.gross_area * gross_prop.gross_centroid.y \
                            * gross_prop.gross_centroid.z

        gross_prop.gross_radius_gyration_y = (gross_prop.gross_moment_inertia_yg / gross_prop.gross_area) ** (1 / 2)
        gross_prop.gross_radius_gyration_z = (gross_prop.gross_moment_inertia_zg / gross_prop.gross_area) ** (1 / 2)

        gross_prop.e_radius_gyration_y = (gross_prop.e_moment_inertia_yg / gross_prop.e_area) ** (1 / 2)
        gross_prop.e_radius_gyration_z = (gross_prop.e_moment_inertia_zg / gross_prop.e_area) ** (1 / 2)

        if is_close_to_zero(gross_inertia_yzg):
            gross_prop.gross_product_inertia_yzg = 0
        else:
            gross_prop.gross_product_inertia_yzg = gross_inertia_yzg

        e_inertia_yzg = gross_prop.e_product_inertia_yzo - gross_prop.e_area * gross_prop.e_centroid.y \
                        * gross_prop.e_centroid.z

        if is_close_to_zero(e_inertia_yzg):
            gross_prop.e_product_inertia_yzg = 0
        else:
            gross_prop.e_product_inertia_yzg = e_inertia_yzg

        # Propriétés géométriques principales
        myg = gross_prop.gross_moment_inertia_yg
        mzg = gross_prop.gross_moment_inertia_zg
        myzg = gross_prop.gross_product_inertia_yzg
        principal_dir = principal_directions(myg, mzg, myzg)
        gross_prop.gross_alpha_rad = principal_dir[0]
        gross_prop.gross_alpha_deg = principal_dir[0] * 180 / math.pi
        gross_prop.gross_moment_inertia_1 = principal_dir[1]
        gross_prop.gross_moment_inertia_2 = principal_dir[2]
        gross_prop.gross_radius_gyration_1 = (gross_prop.gross_moment_inertia_1 / gross_prop.gross_area) ** (1 / 2)
        gross_prop.gross_radius_gyration_2 = (gross_prop.gross_moment_inertia_2 / gross_prop.gross_area) ** (1 / 2)

        e_myg = gross_prop.e_moment_inertia_yg
        e_mzg = gross_prop.e_moment_inertia_zg
        e_myzg = gross_prop.e_product_inertia_yzg
        e_principal_dir = principal_directions(e_myg, e_mzg, e_myzg)
        gross_prop.e_alpha_rad = e_principal_dir[0]
        gross_prop.e_alpha_deg = e_principal_dir[0] * 180 / math.pi
        gross_prop.e_moment_inertia_1 = e_principal_dir[1]
        gross_prop.e_moment_inertia_2 = e_principal_dir[2]
        gross_prop.e_radius_gyration_1 = (gross_prop.e_moment_inertia_1 / gross_prop.e_area) ** (1 / 2)
        gross_prop.e_radius_gyration_2 = (gross_prop.e_moment_inertia_2 / gross_prop.e_area) ** (1 / 2)

    def get_gross_properties(self) -> GrossProperties:
        """REturns the geometric gross properties of the concrete section.

        Returns:
            GrossProperties: _description_
        """
        return self.gross_properties

    def geometric_properties(self) -> list[float]:
        area = 0.0
        first_moment_yo = 0.0
        first_moment_zo = 0.0
        moment_inertia_yo = 0.0
        moment_inertia_zo = 0.0
        product_inertia_yzo = 0.0

        for section in self.regions:
            area += section.area
            first_moment_yo += section.first_moment_yo
            first_moment_zo += section.first_moment_zo
            moment_inertia_yo += section.moment_inertia_yo
            moment_inertia_zo += section.moment_inertia_zo
            product_inertia_yzo += section.product_inertia_yzo

        centroid_y = first_moment_zo / area
        centroid_z = first_moment_yo / area

        return [
            area,
            centroid_y,
            centroid_z,
            first_moment_yo,
            first_moment_zo,
            moment_inertia_yo,
            moment_inertia_zo,
            product_inertia_yzo
        ]

    @functools.cached_property
    def geometric_properties_from_fibres(self) -> list[float]:
        area = 0.0
        first_moment_yo = 0.0
        first_moment_zo = 0.0
        moment_inertia_yo = 0.0
        moment_inertia_zo = 0.0
        product_inertia_yzo = 0.0

        for concrete_fibre in self.list_of_concrete_fibres:
            area += concrete_fibre.area
            first_moment_yo += concrete_fibre.first_moment_yo
            first_moment_zo += concrete_fibre.first_moment_zo
            moment_inertia_yo += concrete_fibre.moment_inertia_yo
            moment_inertia_zo += concrete_fibre.moment_inertia_zo
            product_inertia_yzo += concrete_fibre.product_inertia_yzo

        centroid_y = first_moment_zo / area
        centroid_z = first_moment_yo / area

        return [
            area,
            centroid_y,
            centroid_z,
            first_moment_yo,
            first_moment_zo,
            moment_inertia_yo,
            moment_inertia_zo,
            product_inertia_yzo
        ]

    @functools.cached_property
    def centroid(self) -> Point:
        """Returns the geometric centroid of the concrete section.

        Returns:
            Point: centroid of the section
        """
        return Point(self.geometric_properties()[1], self.geometric_properties()[2])

    @property
    def height(self) -> float:
        z_max = -math.inf
        z_min = math.inf
        for fibre in self.list_of_extreme_fibres:
            z_max = max(z_max, fibre.position.z)
            z_min = min(z_min, fibre.position.z)
        return z_max - z_min

    @property
    def width(self) -> float:
        y_max = -math.inf
        y_min = math.inf
        for fibre in self.list_of_extreme_fibres:
            y_max = max(y_max, fibre.position.y)
            y_min = min(y_min, fibre.position.y)
        return y_max - y_min

    def height_theta(self, theta: float=0) -> float:
        """
        Détermination de la hauteur de la section pour l'inclinaison theta.

        :param theta: inclinaison de l'axe neutre en degrés
        """

        bottom = calcul_ksi_bottom(self.list_of_extreme_fibres, self.centroid, theta)
        top = calcul_ksi_top(self.list_of_extreme_fibres, self.centroid, theta)
        return top - bottom

    @property
    def equivalent_height(self) -> float:
        return self.gross_properties.gross_radius_gyration_y * (12) ** (1 / 2)

    @property
    def equivalent_width(self) -> float:
        return self.gross_properties.gross_radius_gyration_z * (12) ** (1 / 2)

    @property
    def rebars_total_area(self) -> float:
        return sum(rebar.area for rebar in self.list_of_rebars)

    @property
    def rho_s(self) -> float:
        return self.rebars_total_area / self.gross_properties.gross_area

    def find_forces(self, epsilon_0: float, omega_y: float, omega_z: float) -> tuple[float, float, float]:
        """Returns the forces balanced by the section (all materials) for a given plane of deformation.

        Args:
            curvature (PlaneStrain): Deformation of the section

        Returns:
            tuple[float, float, float]: The set of forces (Nx, My, Mz)
        """
        pod = PlaneOfDeformation(epsilon_0, omega_y, omega_z)
        fibres = []
        fibres += self.list_of_concrete_fibres
        fibres += self.list_of_negative_concrete_fibres
        fibres += self.list_of_rebars
        fibres += self.list_of_frp_strips

        forces = self.get_forces(pod, fibres)

        return forces[0], forces[1], forces[2]

    def get_forces(self, pod: PlaneOfDeformation, fibres: list[Fibre]) -> tuple[float]:
        """Returns the forces balanced by the fibres for a given plane strain.

        Args:
            pod (PlaneStrain): Deformation of the section
            fibres (list[Fibre]): list of fibres

        Returns:
            tuple[float]: The set of forces (Nx, My, Mz, Mpsi, Mksi)
        """
        theta_rad = pod.theta_radians
        force_x = 0.
        moment_y = 0.
        moment_z = 0.

        for fibre in fibres:
            strain = pod.strain_at_position(fibre.position)
            forces = fibre.calculate_forces(strain, self.centroid)
            force_x += forces[0]
            moment_y += forces[1]
            moment_z += forces[2]

        moment_psi = moment_y * np.cos(theta_rad) + moment_z * np.sin(theta_rad)
        moment_ksi = - moment_y * np.sin(theta_rad) + moment_z * np.cos(theta_rad)

        return force_x, moment_y, moment_z, moment_psi, moment_ksi

    def calculate_forces(self, pod: PlaneOfDeformation) -> tuple[float]:
        """Calculate the internal forces for the section (all materials).

        Args:
            pod (PlaneOfDeformation): State od deformation applied to the section

        Returns:
            tuple[float]: the axial force nx, the bending moments my and mz
        """
        acc = []
        acc += self.list_of_concrete_fibres
        acc += self.list_of_negative_concrete_fibres
        acc += self.list_of_rebars
        acc += self.list_of_frp_strips
        return self.get_forces(pod, acc)

    def calculate_concrete_forces(self, pod: PlaneOfDeformation) -> tuple[float]:
        """Calculate the internal forces for the section (concrete material only).

        Args:
            pod (PlaneOfDeformation): State od deformation applied to the section

        Returns:
            tuple[float, float, float]: the axial force nx, the bending moments my and mz
        """
        acc = self.list_of_concrete_fibres + self.list_of_negative_concrete_fibres
        return self.get_forces(pod, acc)

    def calculate_rebars_forces(self, curvature: PlaneOfDeformation, theta: float=0.) -> tuple[float]:
        """Calculate the internal forces for the section (steel rebar material only).

        Args:
            curvature (PlaneOfDeformation): State od deformation applied to the section
            theta (float, optional): inclination of the neutral axis. Defaults to 0..

        Returns:
            tuple[float, float, float]: the axial force nx, the bending moments my and mz
        """
        return self.get_forces(curvature, self.list_of_rebars)

    def calculate_frp_strips_forces(self, curvature: PlaneOfDeformation) -> tuple[float]:
        """Calculate the internal forces for the section (frp material only).

        Args:
            curvature (PlaneOfDeformation): State od deformation applied to the section

        Returns:
            tuple[float, float, float]: the axial force nx, the bending moments my and mz
        """
        return self.get_forces(curvature, self.list_of_frp_strips)

    def from_forces_to_curvature(self, nx: float, my: float, mz: float) -> PlaneOfDeformation:
        """Returns the curvature (PlaneStrain) that balances a given set of forces.

        Args:
            nx (float): target normal force Nx
            my (float): target bending moment My
            mz (float): target bending moment Mz

        Returns:
            PlaneStrain: the curvature required to balance the forces
        """

        solution = NewtonRaphson33(self.find_forces, [nx, my, mz])
        pod = solution.final_roots
        return PlaneOfDeformation(pod[0], pod[1], pod[2])

    def from_curvature_to_forces(self, pod: PlaneOfDeformation) -> tuple[float]:
        """Returns the set of forces calculate for a given curvature (PlaneStrain).

        Args:
            pod (PlaneStrain): the curvature applied on the section

        Returns:
            nx (float): normal force Nx
            my (float): bending moment My
            mz (float): bending moment Mz
        """
        return self.calculate_forces(pod)

    def concrete_internal_state(self, plane_of_deformation: PlaneOfDeformation):
        out_acc = {}
        for extreme_fibre in self.list_of_extreme_fibres:
            conc_dict = {}
            strain = plane_of_deformation.strain_at_position(extreme_fibre.position)
            conc_dict.update({"area": extreme_fibre.area})
            conc_dict.update({"strain": plane_of_deformation.strain_at_position(extreme_fibre.position)})
            conc_dict.update({"stress": extreme_fibre.calculate_stress(strain)})
           
            out_acc.update({f"{extreme_fibre.name}": conc_dict})
        return out_acc

    def concrete_full_internal_state(self, plane_of_deformation: PlaneOfDeformation):
        out_acc = {}
        for concrete_fibre in self.list_of_concrete_fibres:
            conc_dict = {}
            strain = plane_of_deformation.strain_at_position(concrete_fibre.position)
            conc_dict.update({"area": concrete_fibre.area})
            conc_dict.update({"strain": plane_of_deformation.strain_at_position(concrete_fibre.position)})
            conc_dict.update({"stress": concrete_fibre.calculate_stress(strain)})
           
            out_acc.update({f"{concrete_fibre.name}": conc_dict})
        for neg_concrete_fibre in self.list_of_negative_concrete_fibres:
            conc_dict = {}
            strain = plane_of_deformation.strain_at_position(neg_concrete_fibre.position)
            conc_dict.update({"area": neg_concrete_fibre.area})
            conc_dict.update({"strain": plane_of_deformation.strain_at_position(neg_concrete_fibre.position)})
            conc_dict.update({"stress": neg_concrete_fibre.calculate_stress(strain)})
           
            out_acc.update({f"{neg_concrete_fibre.name}": conc_dict})
        return out_acc

    def maximum_concrete_stress(self, pod: PlaneOfDeformation) -> float:
        return max(fibre["stress"] for fibre in self.concrete_internal_state(pod).values())

    def minimum_concrete_stress(self, pod: PlaneOfDeformation) -> float:
        return min(fibre["stress"] for fibre in self.concrete_internal_state(pod).values())

    def maximum_concrete_strain(self, pod: PlaneOfDeformation) -> float:
        return max(fibre["strain"] for fibre in self.concrete_internal_state(pod).values())

    def minimum_concrete_strain(self, pod: PlaneOfDeformation) -> float:
        return min(fibre["strain"] for fibre in self.concrete_internal_state(pod).values())

    def rebars_internal_state(self, plane_of_deformation: PlaneOfDeformation):
        out_acc = {}
        i = 0
        for rebar in self.list_of_rebars:
            rebar_dict = {}
            strain = plane_of_deformation.strain_at_position(rebar.position)
            rebar_dict.update({"area": rebar.area})
            rebar_dict.update({"strain": plane_of_deformation.strain_at_position(rebar.position)})
            rebar_dict.update({"stress": rebar.calculate_stress(strain)})
        
            if rebar.name in out_acc:
                i += 1
                out_acc.update({f"{rebar.name}_{i}": rebar_dict})
            else:
                out_acc.update({f"{rebar.name}": rebar_dict})
        return out_acc

    def maximum_rebars_stress(self, pod: PlaneOfDeformation) -> float:
        return max(fibre["stress"] for fibre in self.rebars_internal_state(pod).values())

    def minimum_rebars_stress(self, pod: PlaneOfDeformation) -> float:
        return min(fibre["stress"] for fibre in self.rebars_internal_state(pod).values())

    def frp_internal_state(self, plane_of_deformation: PlaneOfDeformation):
        out_acc = {}
        i = 0
        for frp in self.list_of_frp_strips:
            frp_dict = {}
            strain = plane_of_deformation.strain_at_position(frp.position)
            frp_dict.update({"area": frp.area})
            frp_dict.update({"strain": plane_of_deformation.strain_at_position(frp.position)})
            frp_dict.update({"stress": frp.calculate_stress(strain)})
                   
            if frp.name in out_acc:
                i += 1
                out_acc.update({f"{frp.name}_{i}": frp_dict})
            else:
                out_acc.update({f"{frp.name}": frp_dict})
        return out_acc

    def maximum_frp_stress(self, pod: PlaneOfDeformation) -> float:
        return max(fibre["stress"] for fibre in self.frp_internal_state(pod).values())

    def minimum_frp_stress(self, pod: PlaneOfDeformation) -> float:
        return min(fibre["stress"] for fibre in self.frp_internal_state(pod).values())

    def compression_force(self, pod: PlaneOfDeformation) -> float:
        compression_force = 0
        concrete_state = self.concrete_full_internal_state(pod)
        rebars_state = self.rebars_internal_state(pod)
        fpr_state = self.frp_internal_state(pod)

        for concrete in concrete_state.values():
            if concrete["strain"] > 0:
                compression_force += concrete["area"] * concrete["stress"]
        for rebar in rebars_state.values():
            if rebar["strain"] > 0:
                compression_force += rebar["area"] * rebar["stress"]
        for frp in fpr_state.values():
            if rebar["strain"] > 0:
                compression_force += frp["area"] * frp["stress"]
        return compression_force * 1e3

    def traction_force(self, pod: PlaneOfDeformation) -> float:
        traction_force = 0
        concrete_state = self.concrete_full_internal_state(pod)
        rebars_state = self.rebars_internal_state(pod)
        fpr_state = self.frp_internal_state(pod)

        for concrete in concrete_state.values():
            if concrete["strain"] < 0:
                traction_force += concrete["area"] * concrete["stress"]
        for rebar in rebars_state.values():
            if rebar["strain"] < 0:
                traction_force += rebar["area"] * rebar["stress"]
        for frp in fpr_state.values():
            if rebar["strain"] < 0:
                traction_force += frp["area"] * frp["stress"]
        return traction_force * 1e3

    def compressed_area(self, pod: PlaneOfDeformation) -> float:
        compressed_area = 0
        for fibre in self.list_of_concrete_fibres:
            compressed_area += fibre.area * (pod.strain_at_position(fibre.position) >= 0)
        return compressed_area

    def tense_area(self, pod: PlaneOfDeformation) -> float:
        tense_area = 0
        for fibre in self.list_of_concrete_fibres:
            tense_area += fibre.area * (pod.strain_at_position(fibre.position) < 0)
        return tense_area

    def rebar_comp_area(self, pod: PlaneOfDeformation) -> float:
        rebar_area = 0
        for fibre in self.list_of_rebars:
            rebar_area += fibre.area * (pod.strain_at_position(fibre.position) >= 0)
        return rebar_area

    def rebar_trac_area(self, pod: PlaneOfDeformation) -> float:
        rebar_area = 0
        for fibre in self.list_of_rebars:
            rebar_area += fibre.area * (pod.strain_at_position(fibre.position) <= 0)
        return rebar_area

    def from_multiple_curvatures_to_forces(self, curvatures: list[PlaneOfDeformation]) -> list[tuple[float]]:
        acc = []
        for plane_strain in curvatures:
                acc.append(self.from_curvature_to_forces(plane_strain))
        return acc
    
    def v_theta(self, theta: float= 0.) -> tuple[float, EC2Concrete]:
        """Returns the maximum distance bewteen the extreme top fibre (concrete) and the section's centroid for a given inclination of the neutral axis.

        Args:
            theta (float, optional): Angle bewteen the neutral axis and the y axis. Defaults to 0..

        Returns:
            tuple[float]: ksi_max & the fibre material
        """
        return calcul_ksi_top(self.list_of_extreme_fibres, self.centroid, theta)

    def vprim_theta(self, theta: float= 0) -> tuple[float, EC2Concrete]:
        """Returns the minimum distance bewteen the extreme bottom fibre (concrete) and the section's centroid for a given inclination of the neutral axis.

        Args:
            theta (float, optional): Angle bewteen the neutral axis and the y axis. Defaults to 0..

        Returns:
            tuple[float]: ksi_min & the fibre material
        """
        return calcul_ksi_bottom(self.list_of_extreme_fibres, self.centroid, theta)

    def height_theta(self, theta: float= 0) -> float:
        """Returns the height of the concrete section for a given inclination of the neutral axis.

        Args:
            theta (float, optional): Angle bewteen the neutral axis and the y axis. Defaults to 0..

        Returns:
            float: relative height
        """
        return self.v_theta(theta)[0] - self.vprim_theta(theta)[0]

    def vs_theta(self, theta: float= 0) -> tuple[float, SteelRebar]:
        """Returns the maximum distance bewteen the extreme top rebar and the section's centroid for a given inclination of the neutral axis.

        Args:
            theta (float, optional): Angle bewteen the neutral axis and the y axis. Defaults to 0..

        Returns:
            tuple[float]: ksi_max & the fibre material
        """
        return calcul_ksi_top(self.list_of_rebars, self.centroid, theta)

    def vsprim_theta(self, theta: float= 0) -> tuple[float, SteelRebar]:
        """Returns the minimum distance bewteen the extreme bottom rebar and the section's centroid for a given inclination of the neutral axis.

        Args:
            theta (float, optional): Angle bewteen the neutral axis and the y axis. Defaults to 0..

        Returns:
            tuple[float]: ksi_min & the fibre material
        """
        return calcul_ksi_bottom(self.list_of_rebars, self.centroid, theta)

    def vf_theta(self, theta: float= 0) -> tuple[float, FRPStrips]:
        """Returns the maximum distance bewteen the extreme top frp and the section's centroid for a given inclination of the neutral axis.

        Args:
            theta (float, optional): Angle bewteen the neutral axis and the y axis. Defaults to 0..

        Returns:
            tuple[float]: ksi_max & the fibre material
        """
        return calcul_ksi_top(self.list_of_frp_strips, self.centroid, theta)

    def vfprim_theta(self, theta: float= 0) -> tuple[float, FRPStrips]:
        """Returns the minimum distance bewteen the extreme bottom frp and the section's centroid for a given inclination of the neutral axis.

        Args:
            theta (float, optional): Angle bewteen the neutral axis and the y axis. Defaults to 0..

        Returns:
            tuple[float]: ksi_min & the fibre material
        """
        return calcul_ksi_bottom(self.list_of_frp_strips, self.centroid, theta)

    def omega_y(self, omega_theta: float, theta: float) -> float:
        """Renvoie la valeur de la courbure autour de l'axe y pour une courbure globale donnée.

        Args:
            omega_theta (float): Courbure générale (autour de l'axe neutre incliné de theta par rapport à y)
            theta (float): Inclinaison de l'axe neutre par rapport à l'axe y en [°]

        Returns:
            float: Courbure autour de l'axe y
        """
        return omega_theta * np.cos(np.radians(theta))

    def omega_z(self, omega_theta: float, theta: float) -> float:
        """Renvoie la valeur de la courbure autour de l'axe z pour une courbure globale donnée.

        Args:
            omega_theta (float): Courbure générale (autour de l'axe neutre incliné de theta par rapport à y)
            theta (float): Inclinaison de l'axe neutre par rapport à l'axe z en [°]

        Returns:
            float: Courbure autour de l'axe z
        """
        return omega_theta * np.sin(np.radians(theta))

    def get_plane_strain(
            self,
            epsilon_sup: float,
            epsilon_inf: float,
            ksi_bott: float,
            ksi_top: float,
            theta: float,
    ) -> PlaneOfDeformation:
        """Returns the plane strain corresponding to a deformation plane

        Args:
            epsilon_sup (float): _description_
            epsilon_inf (float): _description_
            ksi_bott (float): _description_
            ksi_top (float): _description_
            theta (float): _description_

        Returns:
            PlaneStrain: _description_
        """
        epsilon_0 = epsilon_sup - (epsilon_sup - epsilon_inf) / (ksi_top - ksi_bott) * ksi_top
        omega_theta = (epsilon_sup - epsilon_0) / ksi_top
        omega_y = self.omega_y(omega_theta, theta)
        omega_z = self.omega_z(omega_theta, theta)
 
        epsilon_0 +=  -1 * self.centroid.z * omega_y + self.centroid.y * omega_z

        return PlaneOfDeformation(epsilon_0, omega_y, omega_z)

    def data_for_given_theta(self, theta: float=0.) -> dict[str: float]:
        """Returns a dictionary with the data according a given theta.

        Args:
            theta (float, optional): angle between the neutral axis and the y axis. Defaults to 0..

        Returns:
            dict[str: float]: a dictionary with all the informations required to calculate the pivot
        """
        acc = {}
        vc = self.v_theta(theta)[0]
        vcprim = self.vprim_theta(theta)[0]
        height_theta = self.height_theta(theta)
        vs = self.vs_theta(theta)[0]
        vsprim = self.vsprim_theta(theta)[0]
        vf = self.vf_theta(theta)[0]
        vfprim = self.vfprim_theta(theta)[0]

        acc.update({
            'theta': theta,
            'vc': vc,
            'vcprim': vcprim,
            'height_theta': height_theta,
            'vs': vs,
            'vsprim': vsprim,
            'vf': vf,
            'vfprim': vfprim,
            })
        return acc

    def point_on_diagram_ps_0(self, data: dict[str: float]) -> PlaneOfDeformation:
        """Defines the point 0 of the interaction diagram.
           The point 0 corresponds to epsilon_ud for the top and botton reinforcement. 

        Args:
            data (_type_): the geometric informations of the section for a given theta

        Returns:
            PlaneOfDeformation: the state of deformation applied to the section
        """
        theta = data['theta']
        vc = data["vc"]
        vcprim = data["vcprim"]
        concrete_fibres = self.list_of_extreme_fibres
        reinforcement_fibres = self.list_of_rebars.copy()
        reinforcement_fibres.extend(self.list_of_frp_strips)

        if len(reinforcement_fibres) == 1:
            epsilon_lim = -1 * reinforcement_fibres[0].material.epsilon_ud
            return PlaneOfDeformation(epsilon_lim, 0, 0)

        epsilon_bar = -math.inf
        epsilon_sup = -math.inf
        epsilon_inf = -math.inf
        while len(reinforcement_fibres) > 0.:
            fibre_0 = reinforcement_fibres.pop(0)
            epsilon_lim_0 = -1 * get_limit_strain(fibre_0)
            ksi_0 = calcul_ksi(fibre_0, self.centroid, theta)
            epsilon_bar = max(epsilon_bar, epsilon_lim_0)

            for fibre in reinforcement_fibres:
                epsilon_lim = -1 * get_limit_strain(fibre)
                ksi = calcul_ksi(fibre, self.centroid, theta)
                epsilon_v = get_strain_at_position(epsilon_lim_0, ksi_0, epsilon_lim, ksi, vc)
                epsilon_vprim = get_strain_at_position(epsilon_lim_0, ksi_0, epsilon_lim, ksi, vcprim)
                epsilon_sup = max(epsilon_sup, epsilon_v)
                epsilon_inf = max(epsilon_inf, epsilon_vprim)
                epsilon_bar = max(epsilon_bar, epsilon_lim)
        
        epsilon_sup = min(epsilon_sup, epsilon_bar)
        epsilon_inf = min(epsilon_inf, epsilon_bar)
        
        return self.get_plane_strain(epsilon_sup, epsilon_inf, vcprim, vc, theta)

    def point_on_diagram_ps_1(self, data: dict[str: float]) -> PlaneOfDeformation:
        """Defines the point 1 of the interaction diagram.
           The point 1 corresponds to epsilon_ud for the botton reinforcement and epsilon_cu for the top concrete fibre.

        Args:
            data (_type_): the geometric informations of the section for a given theta

        Returns:
            PlaneOfDeformation: the state of deformation applied to the section
        """
        theta = data['theta']
        vc = data["vc"]
        vcprim = data["vcprim"]
        concrete_fibres = self.list_of_extreme_fibres
        reinforcement_fibres = self.list_of_rebars.copy()
        reinforcement_fibres.extend(self.list_of_frp_strips)

        epsilon_sup = math.inf
        epsilon_inf = -math.inf
        for extreme_fibre in concrete_fibres:
            if extreme_fibre.material.diagram_type.lower() == "uls_sargin":
                creep = extreme_fibre.material.phi_creep
            else:
                creep = 0
            epsilon_c = extreme_fibre.material.epsilon_cu * (1 + creep)
            v = calcul_ksi(extreme_fibre, self.centroid, theta)
            for fibre in reinforcement_fibres:
                epsilon_lim = -1 * get_limit_strain(fibre)
                ksi = calcul_ksi(fibre, self.centroid, theta)
                if v <= ksi:
                    pass
                else:
                    epsilon_vc = get_strain_at_position(epsilon_c, v, epsilon_lim, ksi, vc)
                    epsilon_vcprim = get_strain_at_position(epsilon_c, v, epsilon_lim, ksi, vcprim)
                    epsilon_sup = min(epsilon_sup, epsilon_vc)
                    epsilon_inf = max(epsilon_inf, epsilon_vcprim)

        return self.get_plane_strain(epsilon_sup, epsilon_inf, vcprim, vc, theta)

    def point_on_diagram_ps_2(self, data: dict[str: float]) -> PlaneOfDeformation:
        """Defines the point 2 of the interaction diagram.
           The point 2 corresponds to epsilon_ud / 2 for the botton reinforcement and epsilon_cu for the top concrete fibre.

        Args:
            data (_type_): the geometric informations of the section for a given theta

        Returns:
            PlaneOfDeformation: the state of deformation applied to the section
        """
        theta = data['theta']
        vc = data["vc"]
        vcprim = data["vcprim"]
        concrete_fibres = self.list_of_extreme_fibres
        reinforcement_fibres = self.list_of_rebars.copy()
        reinforcement_fibres.extend(self.list_of_frp_strips)

        epsilon_sup = math.inf
        epsilon_inf = -math.inf
        for extreme_fibre in concrete_fibres:
            if extreme_fibre.material.diagram_type.lower() == "uls_sargin":
                creep = extreme_fibre.material.phi_creep
            else:
                creep = 0
            epsilon_c = extreme_fibre.material.epsilon_cu * (1 + creep)
            v = calcul_ksi(extreme_fibre, self.centroid, theta)
            for fibre in reinforcement_fibres:
                epsilon_lim = -1/2 * get_limit_strain(fibre)
                ksi = calcul_ksi(fibre, self.centroid, theta)
                if v <= ksi:
                    pass
                else:
                    epsilon_vc = get_strain_at_position(epsilon_c, v, epsilon_lim, ksi, vc)
                    epsilon_vcprim = get_strain_at_position(epsilon_c, v, epsilon_lim, ksi, vcprim)
                    epsilon_sup = min(epsilon_sup, epsilon_vc)
                    epsilon_inf = max(epsilon_inf, epsilon_vcprim)

        return self.get_plane_strain(epsilon_sup, epsilon_inf, vcprim, vc, theta)

    def point_on_diagram_ps_3(self, data: dict[str: float]) -> PlaneOfDeformation:
        """Defines the point 3 of the interaction diagram.
           The point 3 corresponds to epsilon_ud / 5 for the botton reinforcement and epsilon_cu for the top concrete fibre.

        Args:
            data (_type_): the geometric informations of the section for a given theta

        Returns:
            PlaneOfDeformation: the state of deformation applied to the section
        """
        theta = data['theta']
        vc = data["vc"]
        vcprim = data["vcprim"]
        concrete_fibres = self.list_of_extreme_fibres
        reinforcement_fibres = self.list_of_rebars.copy()
        reinforcement_fibres.extend(self.list_of_frp_strips)

        epsilon_sup = math.inf
        epsilon_inf = -math.inf
        for extreme_fibre in concrete_fibres:
            if extreme_fibre.material.diagram_type.lower() == "uls_sargin":
                creep = extreme_fibre.material.phi_creep
            else:
                creep = 0
            epsilon_c = extreme_fibre.material.epsilon_cu * (1 + creep)
            v = calcul_ksi(extreme_fibre, self.centroid, theta)
            for fibre in reinforcement_fibres:
                epsilon_lim = -1/5 * get_limit_strain(fibre)
                ksi = calcul_ksi(fibre, self.centroid, theta)
                if v <= ksi:
                    pass
                else:
                    epsilon_vc = get_strain_at_position(epsilon_c, v, epsilon_lim, ksi, vc)
                    epsilon_vcprim = get_strain_at_position(epsilon_c, v, epsilon_lim, ksi, vcprim)
                    epsilon_sup = min(epsilon_sup, epsilon_vc)
                    epsilon_inf = max(epsilon_inf, epsilon_vcprim)

        return self.get_plane_strain(epsilon_sup, epsilon_inf, vcprim, vc, theta)

    def point_on_diagram_ps_4(self, data: dict[str: float]) -> PlaneOfDeformation:
        """Defines the point 4 of the interaction diagram.
           The point 4 corresponds to epsilon_yd for the botton reinforcement and epsilon_cu for the top concrete fibre.

        Args:
            data (_type_): the geometric informations of the section for a given theta

        Returns:
            PlaneOfDeformation: the state of deformation applied to the section
        """
        theta = data['theta']
        vc = data["vc"]
        vcprim = data["vcprim"]
        concrete_fibres = self.list_of_extreme_fibres
        reinforcement_fibres = self.list_of_rebars.copy()
        reinforcement_fibres.extend(self.list_of_frp_strips)

        epsilon_sup = math.inf
        epsilon_inf = -math.inf
        for extreme_fibre in concrete_fibres:
            if extreme_fibre.material.diagram_type.lower() == "uls_sargin":
                creep = extreme_fibre.material.phi_creep
            else:
                creep = 0
            epsilon_c = extreme_fibre.material.epsilon_cu * (1 + creep)
            v = calcul_ksi(extreme_fibre, self.centroid, theta)
            for fibre in reinforcement_fibres:
                epsilon_lim = -1 * get_reduce_limit_strain(fibre)
                ksi = calcul_ksi(fibre, self.centroid, theta)
                if v <= ksi:
                    pass
                else:
                    epsilon_vc = get_strain_at_position(epsilon_c, v, epsilon_lim, ksi, vc)
                    epsilon_vcprim = get_strain_at_position(epsilon_c, v, epsilon_lim, ksi, vcprim)
                    epsilon_sup = min(epsilon_sup, epsilon_vc)
                    epsilon_inf = max(epsilon_inf, epsilon_vcprim)

        return self.get_plane_strain(epsilon_sup, epsilon_inf, vcprim, vc, theta)

    def point_on_diagram_ps_5(self, data: dict[str: float]) -> PlaneOfDeformation:
        """Defines the point 5 of the interaction diagram.
           The point 5 corresponds to no strain for the botton reinforcement and epsilon_cu for the top concrete fibre.

        Args:
            data (_type_): the geometric informations of the section for a given theta

        Returns:
            PlaneOfDeformation: the state of deformation applied to the section
        """
        theta = data['theta']
        vc = data["vc"]
        vcprim = data["vcprim"]
        concrete_fibres = self.list_of_extreme_fibres
        reinforcement_fibres = self.list_of_rebars.copy()
        reinforcement_fibres.extend(self.list_of_frp_strips)

        epsilon_sup = math.inf
        epsilon_inf = -math.inf
        for extreme_fibre in concrete_fibres:
            if extreme_fibre.material.diagram_type.lower() == "uls_sargin":
                creep = extreme_fibre.material.phi_creep
            else:
                creep = 0
            epsilon_c = extreme_fibre.material.epsilon_cu * (1 + creep)
            v = calcul_ksi(extreme_fibre, self.centroid, theta)
            for fibre in reinforcement_fibres:
                epsilon_lim = 0
                ksi = calcul_ksi(fibre, self.centroid, theta)
                if v <= ksi:
                    pass
                else:
                    epsilon_vc = get_strain_at_position(epsilon_c, v, epsilon_lim, ksi, vc)
                    epsilon_vcprim = get_strain_at_position(epsilon_c, v, epsilon_lim, ksi, vcprim)
                    epsilon_sup = min(epsilon_sup, epsilon_vc)
                    epsilon_inf = max(epsilon_inf, epsilon_vcprim)

        return self.get_plane_strain(epsilon_sup, epsilon_inf, vcprim, vc, theta)

    def point_on_diagram_ps_6(self, data: dict[str: float]) -> PlaneOfDeformation:
        """Defines the point 6 of the interaction diagram.
           The point 6 corresponds to no strain for the botton concrete fibre and epsilon_cu for the top concrete fibre.

        Args:
            data (_type_): the geometric informations of the section for a given theta

        Returns:
            PlaneOfDeformation: the state of deformation applied to the section
        """
        theta = data['theta']
        vc = data["vc"]
        vcprim = data["vcprim"]
        concrete_fibres = self.list_of_extreme_fibres
        reinforcement_fibres = self.list_of_rebars.copy()
        reinforcement_fibres.extend(self.list_of_frp_strips)

        epsilon_sup = math.inf
        for fibre in concrete_fibres:
            epsilon_cu = fibre.material.epsilon_cu
            if fibre.material.diagram_type.lower() == "uls_sargin":
                creep = fibre.material.phi_creep
            else:
                creep = 0
            epsilon_cu = fibre.material.epsilon_cu * (1 + creep)
            epsilon_sup = min(epsilon_cu, epsilon_sup)

        epsilon_inf = 0.
        
        return self.get_plane_strain(epsilon_sup, epsilon_inf, vcprim, vc, theta)

    def point_on_diagram_ps_7(self, data: dict[str: float]) -> PlaneOfDeformation:
        """Defines the point 7 of the interaction diagram.
           The point 7 corresponds epsilon_c for the concrete (top and bottom).

        Args:
            data (_type_): the geometric informations of the section for a given theta

        Returns:
            PlaneOfDeformation: the state of deformation applied to the section
        """
        theta = data['theta']
        vc = data["vc"]
        vcprim = data["vcprim"]
        concrete_fibres = self.list_of_extreme_fibres
        reinforcement_fibres = self.list_of_rebars.copy()
        reinforcement_fibres.extend(self.list_of_frp_strips)

        epsilon_sup = math.inf
        for fibre in concrete_fibres:
            epsilon_c = fibre.material.epsilon_c
            if fibre.material.diagram_type.lower() == "uls_sargin":
                creep = fibre.material.phi_creep
            else:
                creep = 0
            epsilon_c = fibre.material.epsilon_c * (1 + creep)
            epsilon_sup = min(epsilon_c, epsilon_sup)

        return self.get_plane_strain(epsilon_sup, epsilon_sup, vcprim, vc, theta)

    def uls_pod_interaction_diagram(self, theta: float=0) -> list[PlaneOfDeformation]:
        """Returns the planes of deformation for the pivot points of the interaction diagram.

        Args:
            theta (float, optional): Inclination of the neutral axis. Defaults to 0..

        Returns:
            list[PlaneOfDeformation]: list of plane of deformation for the interaction diagram
        """
        acc = []
        data = self.data_for_given_theta(theta)
        ps_0 = self.point_on_diagram_ps_0(data)
        ps_1 = self.point_on_diagram_ps_1(data)
        ps_2 = self.point_on_diagram_ps_2(data)
        ps_3 = self.point_on_diagram_ps_3(data)
        ps_4 = self.point_on_diagram_ps_4(data)
        ps_5 = self.point_on_diagram_ps_5(data)
        ps_6 = self.point_on_diagram_ps_6(data)
        ps_7 = self.point_on_diagram_ps_7(data)

        acc.append(ps_0)
        acc.append(ps_1)
        acc.append(ps_2)
        acc.append(ps_3)
        acc.append(ps_4)
        acc.append(ps_5)
        acc.append(ps_6)
        acc.append(ps_7)

        return acc
    
    def uls_forces_point_on_diagram(self, alpha: float, theta: float=0) -> tuple[float]:
        """_summary_

        Args:
            alpha (float): _description_
            theta (float, optional): _description_. Defaults to 0..

        Returns:
            PlaneOfDeformation: _description_
        """
        points = self.uls_pod_interaction_diagram(theta)
        alpha = min(max(alpha, 0), 7 - 1e-6)
        alpha_int = int(alpha)
        pivot_a = points[alpha_int]
        pivot_b = points[alpha_int + 1]
        alpha_float = alpha - alpha_int
        plane_of_deformation = pivot_a + (pivot_b - pivot_a) * alpha_float
        return self.from_curvature_to_forces(plane_of_deformation)

    def uls_target_axial_force(self, alpha: float, nx: float=0, theta: float=0) -> float:
        return self.uls_forces_point_on_diagram(alpha, theta)[0] - nx

    def forces_for_given_nx(self, nx: float = 0, theta: float=0) -> tuple[float]:
        alpha = brentq(f=self.uls_target_axial_force, a=0, b=7, args=(nx, theta))
        return self.uls_forces_point_on_diagram(alpha, theta)

    def Mrd_max(self, nx: float = 0, theta: float=0) -> float:
        """Returns the maximum bending capacity of the section for a given normal force.

        Args:
            Nx (float, optional): the concomitant axial force applied to the section. Defaults to 0..
            theta (float, optional): Inclination  of the neutral axis. Defaults to 0..

        Returns:
            float: the bending capacity of the section
        """
        # On vérifie que l'effort normal n'est pas en dehors de la capacité de la section
        # On calcule Mrd quand cela est possible
        if nx > self.Nrd_max or nx < self.Nrd_min:
            mrd = 0
        else:
            mrd = self.forces_for_given_nx(nx, theta)[3]

        return mrd

    def Mrd_min(self, nx: float = 0, theta: float = 0) -> float:
        """Returns the minimum bending capacity of the section for a given normal force.

        Args:
            Nx (float, optional): the concomitant axial force applied to the section. Defaults to 0..
            theta (float, optional): Inclination  of the neutral axis. Defaults to 0..

        Returns:
            float: the bending capacity of the section
        """
        # On vérifie que l'effort normal n'est pas en dehors de la capacité de la section
        # On calcule Mrd quand cela est possible
        if nx > self.Nrd_max or nx < self.Nrd_min:
            mrd = 0
        else:
            mrd = self.Mrd_max(nx, theta + 180.)

        return mrd

    def N_bal(self, theta: float = 0) -> float:
        pod = self.uls_pod_interaction_diagram(theta)[4]
        torseur = self.from_curvature_to_forces(pod)
        return torseur[0]

    def M_bal(self, theta: float = 0) -> float:
        pod = self.uls_pod_interaction_diagram(theta)[4]
        torseur = self.from_curvature_to_forces(pod)
        return torseur[3]

    def n_bal(self, theta: float = 0) -> float:
        return self.N_bal(theta) / self.Nrd_max

    @property
    def Nrd_max(self) -> float:
        """Returns the maximum compression capacity of the section.

        Args:
            theta (float, optional): Inclination  of the neutral axis. Defaults to 0..

        Returns:
            float: the compression capacity of the section
        """
        theta = 0.
        return self.uls_forces_point_on_diagram(7, theta)[0]

    @property
    def Nrd_min(self) -> float:
        """Returns the minimum tension capacity of the section.

        Args:
            theta (float, optional): Inclination  of the neutral axis. Defaults to 0..

        Returns:
            float: the tension capacity of the section
        """
        theta = 0.
        return self.uls_forces_point_on_diagram(0, theta)[0]

    def search_epsilon_for_nx(self, epsilon, nx, omega_y, omega_z) -> float:
        pod = PlaneOfDeformation(epsilon, omega_y, omega_z)
        nx_omega = self.from_curvature_to_forces(pod)[0]
        return nx_omega - nx
    
    def emini_theta(self, theta: float = 0) -> float:
        return max(0.02, self.height_theta(theta) / 30)
    
    def line_emin_plus(self, theta: float = 0) -> list[tuple[float, float]]:
        Nrd = self.Nrd_max
        return [(0, Nrd * self.emini_theta(theta)), (0, Nrd)]

    def line_emin_minus(self, theta: float = 0) -> list[tuple[float, float]]:
        Nrd = self.Nrd_max
        return [(0, -1 * Nrd * self.emini_theta(theta)), (0, Nrd)]

    def moment_courbure_analysis(self, theta_deg: float = 0, nx: float = 0) -> list[tuple[float, float]]:
        """Construction de la courbe moment / courbure de la section.

        Args:
            theta_deg (float, optional): Inclinaison de l'axe neutre en [°]. Defaults to 0.
            nx (float, optional): Effort normal concomitant en [kN]. Defaults to 0.

        Returns:
            list[tuple[float, float]]: list des points [courbre, moment] de la courbe.
        """
        moment_max = self.Mrd_max(nx, theta_deg)
        my_max = moment_max * np.cos(np.radians(theta_deg))
        mz_max = -1 * moment_max * np.sin(np.radians(theta_deg))

        m_max_pod = self.from_forces_to_curvature(nx, my_max, mz_max)
        m_max_omega_y = m_max_pod.omega_y
        m_max_omega_z = m_max_pod.omega_z

        n_max_forces = self.uls_forces_point_on_diagram(7, theta_deg)
        n = n_max_forces[0]
        my = n_max_forces[1]
        mz = n_max_forces[2]
        n_max_pod = self.from_forces_to_curvature(n, my, mz)
        b_max = n_max_pod.epsilon_0 * 1.1

        courbure_min = 0
        courbure_max = 1.1 * (m_max_omega_y ** 2 + m_max_omega_z ** 2) ** (1 / 2)
        courbure_step = (courbure_max - courbure_min) / 50

        i = 0
        courbure_i = courbure_min
        courbures = []
        moments = []

        while i <= 1000 and courbure_i < 2 * courbure_max:
            courbure_i_y = courbure_i * np.cos(np.radians(theta_deg))
            courbure_i_z = -1 * courbure_i * np.sin(np.radians(theta_deg))
            try:
                epsilon_i = brentq(f=self.search_epsilon_for_nx, a=-0.1, b=b_max, args=(nx, courbure_i_y, courbure_i_z))
            except ValueError:
                break
            pod_i = PlaneOfDeformation(epsilon_i, courbure_i_y, courbure_i_z)
            m_psi = self.from_curvature_to_forces(pod_i)[3]

            courbures.append(courbure_i)
            moments.append(m_psi)

            i += 1
            courbure_i += courbure_step

        return courbures, moments

    def buckling_analysis_y(self, l0: float, e0: float=0.02, c: float=8, delta_m: float=10) -> list[tuple[float, float]]:
        axial_force = 0
        my_calculated = 0
        moment_e = 0
        excentricity = max(e0, 0.02)
        nm_curve = [(0, 0)]
        check = 1

        while check:
            moment_e += delta_m
            axial_force = moment_e / excentricity
            pod = self.from_forces_to_curvature(axial_force, moment_e, 0)
            epsilon_max = self.maximum_concrete_strain(pod)
            epsilon_min = self.minimum_concrete_strain(pod)
            h = self.height
            curvature = (epsilon_max - epsilon_min) / h
            e2 = curvature * l0 ** 2 / c
            excentricity = max(e0, 0.02) + e2
            my_calculated = self.from_curvature_to_forces(pod)[1]
            check = math.isclose(moment_e, my_calculated, abs_tol=1e-3)
            if check:
                nm_curve.append((axial_force, moment_e))

        return nm_curve


    def buckling_analysis_z(self, l0: float, e0: float=0.02, c: float=8, delta_m: float=10) -> list[tuple[float, float]]:
        axial_force = 0
        mz_calculated = 0
        moment_e = 0
        excentricity = max(e0, 0.02)
        nm_curve = [(0, 0)]
        check = 1

        while check:
            moment_e += delta_m
            axial_force = moment_e / excentricity
            pod = self.from_forces_to_curvature(axial_force, 0, moment_e)
            epsilon_max = self.maximum_concrete_strain(pod)
            epsilon_min = self.minimum_concrete_strain(pod)
            h = self.width
            curvature = (epsilon_max - epsilon_min) / h
            e2 = curvature * l0 ** 2 / c
            excentricity = max(e0, 0.02) + e2
            mz_calculated = self.from_curvature_to_forces(pod)[2]
            check = math.isclose(moment_e, mz_calculated, abs_tol=1e-3)
            if check:
                nm_curve.append((axial_force, moment_e))

        return nm_curve


    def plot_moment_courbure(self, theta_deg: float = 0, normal_forces: float = [0]) -> None:

        colors = ('C0', 'C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9')
        liste_couleurs = list(colors)
        x_label = "Courbure"
        y_label = "Moment"
        title = "Diagramme moment / courbure pour " r"$\theta$" f" ={theta_deg: .1f}°"

        fig, ax = plt.subplots()

        for normal_force in normal_forces:
            courbe = self.moment_courbure_analysis(theta_deg, normal_force)
            courbure = courbe[0]
            bending_moment = courbe[1]
            color_curve = liste_couleurs.pop(0)
            ax.plot(courbure, bending_moment, color=color_curve, label=f"N = {normal_force: .1f} kN")

        ax.legend()
        ax.set_xlabel(x_label)
        ax.set_ylabel(y_label)
        ax.set_title(title)

        plt.show()

        return None

    def set_plot_finess(self, finess: float) -> list[int]:
        """Set the finess of the interaction diagram.

        Args:
            finess (float): a number between 0. (coarse plotting) and 1. (fine plotting)

        Returns:
            list[int]: the steps to plot the diagram
        """
        acc = []
        for steps in PIVOT_SEQUENCE:
            finess = min(finess, 1)
            param = max(int(finess * 10), 0)
            acc.append(steps * (param + 1))
        return acc

    def plane_strains_for_interaction_diagram(self, theta: float, finess: float) -> list[PlaneOfDeformation]:
        """Construction of the plan of deformation to plot the interaction diagram.

        Args:
            theta (float, optional): Inclination of the neutral axis. Defaults to 0..
            finess (float, optional): numner (0 < - < 1) for the finess of the plot. Defaults to 0..

        Returns:
            list[PlaneOfDeformation]: Plane of deformation applied to the section
        """
        pivot_points = self.uls_pod_interaction_diagram(theta)
        pivot_sequence = self.set_plot_finess(finess)
        acc = []
        for idx in range(len(pivot_points) - 1):
            pivot_a = pivot_points[idx]
            pivot_b = pivot_points[idx + 1]
            steps = pivot_sequence[idx]
            for step in range(steps):
                acc.append(pivot_a + (pivot_b - pivot_a) * step / steps)
        acc.append(pivot_points[-1])
        return acc

    def build_NM_interaction_diagram(self, theta: float, finess: float) -> list[tuple[float]]:
        ps_1 = []
        ps_2 = []
        ps_1 = self.plane_strains_for_interaction_diagram(theta, finess)
        ps_2 = self.plane_strains_for_interaction_diagram(theta + 180., finess)
        invert_ps_2 = invert_list(ps_2)
        ps = ps_1 + invert_ps_2
        forces = self.from_multiple_curvatures_to_forces(ps)
        return forces

    def build_My_Mz_interaction_diagram(
            self,
            axial_forces: tuple[float],
            delta_theta: float,
            theta_min: float,
            theta_max: float
        ) -> list[tuple[float]]:
        curves_my_mz = []
        for nx in axial_forces:
            theta = theta_min
            my = []
            mz = []
            while theta <= theta_max:
                my_theta = self.forces_for_given_nx(nx, theta)[1]
                mz_theta = self.forces_for_given_nx(nx, theta)[2]
                my.append(my_theta)
                mz.append(mz_theta)
                theta += delta_theta
            curves_my_mz.append([nx, my, mz])
        return curves_my_mz

    def flat_head_diag(self, theta: float, inter_diag_curve: list[tuple[float, float]]):

        axial_force = []
        m_psi = []
        for point in inter_diag_curve:
            axial_force.append(point[0])
            m_psi.append(point[1])

        emin_m = self.line_emin_minus(theta)
        emin_p = self.line_emin_plus(theta)
        pt_a = intersection(emin_m[0], emin_m[1], m_psi, axial_force)
        pt_c = intersection(emin_p[0], emin_p[1], m_psi, axial_force)
        ma, na = pt_a[0][0], pt_a[1][0]
        mc, nc = pt_c[0][0], pt_c[1][0]
        mb, nb = 0, min(na, nc)

        inter_curve = []
        hat = [(nc, mc)]
        i_trunc = 0

        for point in inter_diag_curve:
            nx = point[0]
            mpsi = point[1]
            if nx <= nb or abs(mpsi) >= nx * self.emini_theta(theta):
                inter_curve.append(point)
            else:
                hat.append(point)
                if i_trunc == 0:
                    inter_curve.append((nc, mc))
                    inter_curve.append((nb, mb))
                    inter_curve.append((na, ma))
                i_trunc += 1
        hat.append((na, ma))

        return inter_curve, hat


    def plot_interaction_diagram_v2(
            self,
            theta: float = 0,
            finess: float = 0,
            zones: list[int] = [1, 2, 3, 4],
            flat_head: bool = True,
            pivot_markers: bool = True,
            plot_mksi: bool = False,
            add_curves: list[list[tuple[float, float]]] | None = None,
            add_points: list[tuple[float, float]] | None = None,
    ) -> None:

        colors = ('C0', 'C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9')
        color_plot = random.choice(colors)
        plot_parameters = {
            'color_plot': color_plot,
            'x_label': f"M [kN.m]",
            'y_label': f"N [kN]",
            'psi_label': r'$M_{\psi}$ '' (autour de l\'axe neutre)',
            'ksi_label': r'$M_{\xi}$ '' (perpendiculaire à l\'axe neutre)',
            'title': ("Diagramme d'interaction N-M\n Inclinaison de l'axe neutre : " r"$\theta$" " = {} °".format(theta)),
        }

        m_ksi_curve_by_zone = None
        pivots_points = None
        additional_curves = None
        additional_points = None
        flat_head_curve = None

        data = self.build_NM_interaction_diagram(theta, finess)
        m_psi_curve = []
        m_ksi_curve = []
        for point in data:
            m_psi_curve.append((point[0], point[3]))
            m_ksi_curve.append((point[0], point[4]))

        if flat_head == True:
            flat_head_calc = self.flat_head_diag(theta, m_psi_curve)
            m_psi_curve = flat_head_calc[0]
            flat_head_points = flat_head_calc[1]

        m_psi_curve_by_zone = plotting_curves.filtre_inter_diag(m_psi_curve, zones)
        if plot_mksi == True:
            m_ksi_curve_by_zone = [m_ksi_curve]
        
        if pivot_markers == True:
            pivots = []
            pivot_pod = self.uls_pod_interaction_diagram(theta)
            pivot_pod += self.uls_pod_interaction_diagram(theta + 180)
            for point in pivot_pod:
                forces = self.from_curvature_to_forces(point)
                pivots.append((forces[0], forces[3]))

            pivots_points = plotting_curves.filtre_points(pivots, zones)

        if add_curves != None:
            additional_curves = []
            for curve in add_curves:
                additional_curves.append(plotting_curves.filtre_points(curve, zones))

        if add_points != None:
            additional_points = plotting_curves.filtre_points(add_points, zones)

        if flat_head != False:
            flat_head_curve = plotting_curves.filtre_inter_diag(flat_head_points, zones)

        plotting_curves.plot_NM_interaction_diagram(
            mpsi_curves = m_psi_curve_by_zone,
            mksi_curves = m_ksi_curve_by_zone,
            flat_head_curve= flat_head_curve,
            add_curves = additional_curves,
            add_points = additional_points,
            marker_pivots = pivots_points,
            plot_parameters= plot_parameters,
        )

        pass

    def plot_NM_interaction_diagram(
            self,
            theta: float=0,
            finess=0,
            positif: bool=True,
            negatif: bool=True,
            compression: bool=True,
            traction: bool=True,
            add_curves: list[list[tuple[float, float]]] = [[(0, 0)]],
            pivot_marker: bool = True,
            color: str=None,
        ) -> None:
        data_prov = self.build_NM_interaction_diagram(theta, finess)
        data = []
        for torseur in data_prov:
            if torseur[0] * compression - 1e-9 >= 0:
                data.append(torseur)
            if torseur[0] * traction + 1e-9 <= 0:
                data.append(torseur)

        pivots_m = []
        pivots_n = []
        if pivot_marker == True:
            pivot_points = self.uls_pod_interaction_diagram(theta)
            pivot_points += self.uls_pod_interaction_diagram(theta + 180)
            for point in pivot_points:
                forces = self.from_curvature_to_forces(point)
                pivots_n.append(forces[0])
                pivots_m.append(forces[3])
        pivots = [pivots_m, pivots_n]

        plot_parameters = {
            'color_plot': color,
            'x_label': f"M [kN.m]",
            'y_label': f"N [kN]",
            'psi_label': r'$M_{\psi}$ '' (autour de l\'axe neutre)',
            'ksi_label': r'$M_{\xi}$ '' (perpendiculaire à l\'axe neutre)',
            'title': ("Diagramme d'interaction N-M\n Inclinaison de l'axe neutre : " r"$\theta$" " = {} °".format(theta)),
        }
        self.plot_interaction_diagram(
            data,
            theta,
            plot_parameters,
            add_curves,
            pivots)
        return None

    def plot_MyMz_interaction_diagram(
            self,
            axial_forces: list[float]=[0],
            delta_theta=10,
            theta_min: float=0,
            theta_max: float=360,
        ) -> None:

        colors = ('C0', 'C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9')
        line_style = ('solid', 'dotted', 'dashed', 'dashdot')

        data = self.build_My_Mz_interaction_diagram(axial_forces, delta_theta, theta_min, theta_max)
        liste_couleurs = list(colors)
        liste_styles = list(line_style)

        fig, ax = plt.subplots()
        compt = 0

        for curve in data:
            compt += 1
            axial_force = curve[0]
            my_abscissa = curve[1]
            mz_ordinate = curve[2]

            color_curve = liste_couleurs.pop(0)
            style_curve = liste_styles.pop(0)
            if not liste_couleurs:
                liste_couleurs = list(colors)
            if not liste_styles:
                liste_styles = list(line_style)

            ax.plot(my_abscissa, mz_ordinate, color=color_curve, linestyle=style_curve, label=f'N = {axial_force:.0f} kN'.replace(',', ' '))

        ax.legend()
        ax.set_xlabel(r'$M_{y}$' ' [kN.m]')
        ax.set_ylabel(r'$M_{z}$' ' [kN.m]')
        ax.set_title("Diagramme d'interaction\n "r'$M_{y}-M_{z}$')

        plt.show()
        return None

    def plot_interaction_diagram(
            self,
            points: list[tuple[float]],
            theta: float,
            plot_parameters,
            add_curves: list[list[tuple[float, float]]],
            pivots = list[list[float]]
        ) -> None:

        color_plot = plot_parameters['color_plot']
        if plot_parameters['color_plot'] is None:
            colors = ('C0', 'C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9')
            color_plot = random.choice(colors)
        x_label = plot_parameters['x_label']
        y_label = plot_parameters['y_label']
        psi_label = plot_parameters['psi_label']
        ksi_label = plot_parameters['ksi_label']
        title = plot_parameters['title']

        axial_force_N = []
        bending_moment_psi = []
        bending_moment_ksi = []
        for point in points:
            axial_force_N.append(point[0])
            bending_moment_psi.append(point[3])
            bending_moment_ksi.append(point[4])

        emin_m = self.line_emin_minus(theta)
        emin_p = self.line_emin_plus(theta)
        pt_a = intersection(emin_m[0], emin_m[1], bending_moment_psi, axial_force_N)
        pt_c = intersection(emin_p[0], emin_p[1], bending_moment_psi, axial_force_N)
        ma, na = pt_a[0][0], pt_a[1][0]
        mc, nc = pt_c[0][0], pt_c[1][0]
        mb, nb = 0, min(na, nc)

        i_trunc = 0
        bending_moment = []
        axial_force = []
        truncated_n = [nc]
        truncated_m = [mc]
        for i, nx in enumerate(axial_force_N):
            mpsi = bending_moment_psi[i]
            if nx <= nb or abs(mpsi) >= nx * self.emini_theta(theta):
                bending_moment.append(mpsi)
                axial_force.append(nx)
            else:
                truncated_n.append(nx)
                truncated_m.append(mpsi)
                if i_trunc == 0:
                    bending_moment.append(mc)
                    bending_moment.append(mb)
                    bending_moment.append(ma)
                    axial_force.append(nc)
                    axial_force.append(nb)
                    axial_force.append(na)
                i_trunc += 1
        
        truncated_n.append(na)
        truncated_m.append(ma)

        fig, ax = plt.subplots()
        ax.plot(bending_moment, axial_force, color=color_plot, label=psi_label)
        ax.plot(bending_moment_ksi, axial_force_N, color=color_plot, linestyle='dashed', label=ksi_label)
        ax.plot(truncated_m, truncated_n, color=color_plot, linestyle='dashed')
        ax.plot(pivots[0], pivots[1], color=color_plot, linestyle='None', marker='o')
        ax.fill_between(bending_moment, axial_force, color=color_plot, alpha=0.3)

        for curve in add_curves:
            n_torseur = []
            m_torseur = []
            for torseur in curve:
                n_torseur.append(torseur[0])
                m_torseur.append(torseur[1])
            ax.plot(m_torseur, n_torseur, color="k", marker=".")

        ax.legend()
        ax.set_xlabel(x_label)
        ax.set_ylabel(y_label)
        ax.set_title(title)

        plt.show()
        return None

    def plot_geometry(self) -> None:
        """
        Impression de la section béton, avec CDG et armatures (HA + FRP)
        :return: graphe 2D
        """
        List_abscisse = []
        List_ordonnee = []
        List_arm_y = []
        List_arm_z = []
        List_frp_y = []
        List_frp_z = []
        List_tendon_y = []
        List_tendon_z = []

        # Création des listes pour tracé
        for rebar in self.list_of_rebars:
            List_arm_y.append(rebar.position.y)
            List_arm_z.append(rebar.position.z)
        for frp in self.list_of_frp_strips:
            List_frp_y.append(frp.position.y)
            List_frp_z.append(frp.position.z)
        for conc in self.list_of_concrete_fibres:
            List_abscisse.append(conc.position.y)
            List_ordonnee.append(conc.position.z)
        centroid_y = self.centroid.y
        centroid_z = self.centroid.z

        # Tracé de la forme géométrique
        ax1 = plt.subplot()
        ax2 = plt.subplot()
        ax3 = plt.subplot()
        ax4 = plt.subplot()
        ax5 = plt.subplot()
        ax1.scatter(List_abscisse, List_ordonnee, s=30, color='C8', marker="s")
        ax2.scatter(centroid_y, centroid_z, s=120, color='C4', marker="X")
        ax3.scatter(List_arm_y, List_arm_z, s=40, color='C3', marker="o")
        ax4.scatter(List_frp_y, List_frp_z, s=160, color='C9', marker="*")
        ax3.scatter(List_tendon_y, List_tendon_z, s=80, color='C5', marker="o")
        plt.show()

        return None

    def plot_geometry_v2(self) -> None:

        colors = ["darkred", "indigo", "navy", "olive"]
        color_conc = "teal"

        fix, ax = plt.subplots()
        ax.set_xlim((self.lower_boundary.y, self.upper_boundary.y))
        ax.set_ylim((self.lower_boundary.z, self.upper_boundary.z))

        list_concrete = []
        for region in self.regions:
            concrete = f"C{region.material.fck}"
            concrete_alpha = region.material.fck/100
            for poly in region.polygons:
                if concrete not in list_concrete:
                    list_concrete.append(concrete)
                    concrete_name = concrete
                else:
                    concrete_name=""
                points = []
                for point in poly.vertices:
                    points.append((point.y, point.z))
                polygon = pltPolygon(
                    np.array(points),
                    closed=True,
                    edgecolor="black",
                    facecolor=color_conc,
                    alpha=concrete_alpha,
                    label=concrete_name,
                )
                ax.add_artist(polygon)

        list_steel = []
        for rebar in self.list_of_rebars:
            if rebar.material.ductility_class == "F":
                prefix = "Fe"
                suffix = ""
            else:
                prefix = "B"
                suffix = rebar.material.ductility_class
            steel = f"{prefix}{rebar.material.yield_strength_fyk}{suffix}"
            if steel not in list_steel:
                list_steel.append(steel)
                steel_name = steel
                steel_color = colors.pop()
            else:
                steel_name = ""
            list_steel.append(steel)
            circle = pltCircle(
                (rebar.position.y, rebar.position.z),
                math.sqrt(rebar.area / math.pi),
                edgecolor="black",
                facecolor=steel_color,
                label=steel_name,
            )
            ax.add_artist(circle)

        ax.legend()
        ax.set_title("Géométrie de la section")
        ax.set_aspect('equal', 'box')
        ax.set_axis_off()

        plt.show()

        return None

    def plot_geometry_v3(self):

        colors = ["lightblue", "lightgrey", "lightcoral", "lightgreen", "lightskyblue", "thistle"]
        # fig = go.Figure()
        fig = px.scatter()
        fig.update_layout(title="Géométrie")
        fig.update_xaxes(showgrid=False, )
        fig.update_yaxes(showgrid=False)
        fig.update_layout(showlegend=False)

        for region in self.regions:
            color_reg = random.choice(colors)
            i = 0
            for poly in region.polygons:
                points_x = []
                points_y = []
                for point in poly.vertices:
                    points_x.append(point.y)
                    points_y.append(point.z)
                points_x.append(poly.vertices[0].y)
                points_y.append(poly.vertices[0].z)
                fig.add_trace(
                    go.Scatter(
                        x=points_x,
                        y=points_y,
                        fill="toself",
                        line={'color': color_reg},
                        name=f"C{region.material.fck}",
                    ),
                )
                fig.add_trace(
                    go.Scatter(
                        x=[poly.centroid.y],
                        y=[poly.centroid.z],
                        mode="text",
                        text=[f"C{region.material.fck}"],
                        textposition='top center',
                    )
                )

        for rebar in self.list_of_rebars:
            radius = math.sqrt(rebar.area / math.pi)
            x0, x1 = rebar.position.y - radius, rebar.position.y + radius
            y0, y1 = rebar.position.z - radius, rebar.position.z + radius
            fig.add_shape(type="circle",
                          xref="x", yref="y",
                          fillcolor="black",
                          x0=x0, y0=y0, x1=x1, y1=y1,
                          line_color="black",
                          name="poly")

        fig.show()

        return None

    def plage_fck(self) -> tuple[float, float]:
        """Renvoie les valeurs min et max de fck dans la section.

        Returns:
            tuple[float, float]: tuple[fck_min, fck_max]
        """
        fck_min = math.inf
        fck_max = -math.inf
        for region in self.regions:
            fck_min = min(fck_min, region.material.fck)
            fck_max = max(fck_max, region.material.fck)
        
        return fck_min, fck_max


    def add_frp(
        self,
        frp_material: FibreReinforcedPolymer | None,
        frp_strips: dict[int: [float, float, float]] | None,
    ) -> None:
        """Ajout d'une ou plusieurs armatures FRP à la section existante.

        Args:
            frp_material (FibreReinforcedPolymer | None): Matériau de l'armature FRP
            frp_strips (_type_): Définition des armatures:
                                    {   id :[area, y, z],
                                        id :[area, y, z],
                                        etc...
                                    }
        """
        # Ajout des frp_strips à la liste self.list_of_frp_strips:
        if isinstance(frp_material, FibreReinforcedPolymer) and frp_strips != None:
            for key, value in frp_strips.items():
                area = value[0]
                position = Point(value[1], value[2])
                self.list_of_frp_strips.extend(FRPStrips(0, area=area, material=frp_material, positions=[position], first_idx=key).list)

        return None

    def add_rebar(
        self,
        rebar_material: SteelRebar | None,
        rebars: dict[int: [float, float, float]] | None,
    ) -> None:
        """Ajout d'une ou plusieurs armatures HA à la section existante.

        Args:
            rebar_material (SteelRebar | None): Matériau de l'armature FRP
            rebars (_type_): Définition des armatures:
                                    {   id :[area, y, z],
                                        id :[area, y, z],
                                        etc...
                                    }
        """
        # Ajout des armatures HA à la liste self.list_of_frp_strips:
        if isinstance(rebar_material, SteelRebar) and rebars != None:
            for key, value in rebars.items():
                area = value[0]
                position = Point(value[1], value[2])
                self.list_of_rebars.extend(Rebars(0, area=area, material=rebar_material, positions=[position], first_idx=key).list)

        return None
    

def rotation_matrix(y, z, theta):
    """Applies a matrix rotation to a point's coordinates (no translation).

    Args:
        y (_type_): y coordinate
        z (_type_): z coordinate
        theta (_type_): Angle between the neutral axis and the y axis.

    Returns:
        _type_: psi & ksi, the coordinates in the new coordinate system.
    """
    psi = y * np.cos(np.radians(theta)) - z * np.sin(np.radians(theta))
    ksi = y * np.sin(np.radians(theta)) + z * np.cos(np.radians(theta))
    return psi, ksi


def calcul_ksi_bottom(fibres: list[Fibre], centroid: Point=Point(0., 0.), theta: float=0.) -> tuple[float, EC2Concrete | SteelRebar | FibreReinforcedPolymer]:
    """
    Détermination de la distance max de la fibre extreme la plus basse / au CDG de la section pour l'inclinaison theta
    :param theta: inclinaison de l'axe neutre en degrés
    :return: ksi_bott (distance de la fibre extrême par rapport à l'axe neutre) + le materiau de la fibre
    """
    ksi_bott = math.inf
    if len(fibres) == 0:
        return None, None
    for fibre in fibres:
        delta_y = fibre.position.y - centroid.y
        delta_z = fibre.position.z - centroid.z
        ksi = rotation_matrix(delta_y, delta_z, theta)[1]
        if ksi < ksi_bott:
            ksi_bott = ksi
            material_bott = fibre.material
    return ksi_bott, material_bott


def calcul_ksi_top(fibres: list[Fibre], centroid: Point=Point(0., 0.), theta: float=0.) -> tuple[float]:
    """
    Détermination de la distance max de la fibre extreme la plus haute / au CDG de la section pour l'inclinaison theta
    :param theta: inclinaison de l'axe neutre en degrés
    :return: ksi_top (distance de la fibre extrême par rapport à l'axe neutre) + le materiau de la fibre
    """
    ksi_top = -math.inf
    if len(fibres) == 0:
        return None, None
    for fibre in fibres:
        delta_y = fibre.position.y - centroid.y
        delta_z = fibre.position.z - centroid.z
        ksi = rotation_matrix(delta_y, delta_z, theta)[1]
        if ksi > ksi_top:
            ksi_top = ksi
            material_top = fibre.material
    return ksi_top, material_top


def calcul_ksi(fibre: Fibre, centroid: Point=Point(0., 0.), theta: float=0.) -> float:
    """Retourne la position d'une fibre par rapport à l'axe neutre (pour une inclinaison theta donnée).

    Args:
        fibre (Fibre): fibre pour laquelle on cherche la distance ksi
        centroid (Point, optional): centre de la section. Defaults to Point(0., 0.).
        theta (float, optional): inclinaison de l'axe neutre. Defaults to 0..

    Returns:
        float: la distance de la fibre par rapport au centre de la section.
    """
    delta_y = fibre.position.y - centroid.y
    delta_z = fibre.position.z - centroid.z
    ksi = rotation_matrix(delta_y, delta_z, theta)[1]
    return ksi


def get_limit_strain(fibre: Fibre) -> float:
    if isinstance(fibre.material, SteelRebar):
        epsilon_lim = fibre.material.epsilon_ud
    elif isinstance(fibre.material, FibreReinforcedPolymer):
        epsilon_lim = abs(fibre.material.limit_strain)
    return epsilon_lim

def get_reduce_limit_strain(fibre: Fibre) -> float:
    if isinstance(fibre.material, SteelRebar):
        epsilon_lim = fibre.material.epsilon_yd
    elif isinstance(fibre.material, FibreReinforcedPolymer):
        epsilon_lim = abs(fibre.material.limit_strain) / 2
    return epsilon_lim

def get_strain_at_position(epsilon_1, v1, epsilon_2, v2, v):
    if v1 == v2:
        return  min(abs(epsilon_1), abs(epsilon_2)) * math.copysign(1, epsilon_1)
    else:
        return epsilon_1 + (epsilon_1 - epsilon_2) / (v1 - v2) * (v - v1)
