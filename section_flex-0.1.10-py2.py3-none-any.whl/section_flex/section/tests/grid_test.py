import unittest

from Omega_02_PV.geometry.point import Point
from Omega_02_PV.section.grid import Grid


class TestGrid(unittest.TestCase):

    point_a = Point(-2, -1)
    point_b = Point(3, 2)
    mesh_size_y = 0.01
    mesh_size_z = 0.01

    grid = Grid(point_a, point_b, mesh_size_y, mesh_size_z)

    def test_number_meshes_y(self):
        expected = 500
        actual = self.grid.number_of_meshes_y
        self.assertEqual(expected, actual)

    def test_number_meshes_z(self):
        expected = 300
        actual = self.grid.number_of_meshes_z
        self.assertEqual(expected, actual)

    def test_total_number_of_meshes(self):
        expected = 150_000
        actual = self.grid.total_number_of_meshes
        self.assertEqual(expected, actual)

    def test_mesh_area(self):
        expected = 0.0001
        actual = self.grid.mesh_area
        self.assertEqual(expected, actual)

    def test_mesh_id(self):
        expected = 75055
        actual = self.grid.mesh_id(55, 250)
        self.assertEqual(expected, actual)

    def test_mesh_position_y(self):
        expected = Point(-1.455, 1.495)
        actual = self.grid.mesh_position(55, 250)
        self.assertEqual(expected, actual)

    def test_n_m_from_id(self):
        expected = 55, 250
        actual = self.grid.get_nm_from_id(75055)
        self.assertEqual(expected, actual)
