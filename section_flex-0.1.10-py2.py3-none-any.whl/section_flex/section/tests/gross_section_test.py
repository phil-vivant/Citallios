import unittest

import math

from Omega_02_PV.geometry.point import Point
from Omega_02_PV.geometry.polygon import Polygon
from Omega_02_PV.section.grid import Grid
from Omega_02_PV.materials.ec2_concrete import EC2Concrete
from Omega_02_PV.section.region import Region


class TestSection(unittest.TestCase):
    vertices_a = [
        Point(2.0, 2.0),
        Point(5.56402609675347, 3.81596199895819),
        Point(4.65604509727438, 5.59797504733492),
        Point(1.09201900052091, 3.78201304837674)
    ]
    vertices_b = [
        Point(2.0, 3.0),
        Point(3.0, 3.0),
        Point(3.0, 4.0),
        Point(2.0, 4.0)
    ]
    vertices_c = [
        Point(2.2, 3.2),
        Point(2.8, 3.2),
        Point(2.8, 3.8),
        Point(2.2, 3.8)
    ]
    vertices_d = [
        Point(2.8, 3.78),
        Point(3.0, 3.78),
        Point(3.0, 3.80),
        Point(2.8, 3.80)
    ]
    vertices_e = [
        Point(1.0, 3.0),
        Point(5.0, 3.0),
        Point(5.0, 4.0),
        Point(1.0, 4.0)
    ]
    vertices_f = [
        Point(2.21850801222441, 2.67249851196396),
        Point(4.89152758478951, 4.0344700111826),
        Point(4.21054183518019, 5.3709797974651),
        Point(1.53752226261509, 4.0090082982465)
    ]
    polygon_a = Polygon(vertices_a)
    polygon_b = Polygon(vertices_b)
    polygon_c = Polygon(vertices_c)
    polygon_d = Polygon(vertices_d)
    polygon_e = Polygon(vertices_e)
    polygon_f = Polygon(vertices_f)

    C35 = EC2Concrete(35, 1.5, 2)
    grid = Grid(Point(1, 2), Point(6, 6), 0.01, 0.01)

    section_01 = Region(grid, 0, [polygon_a, polygon_b, polygon_c, polygon_d], C35)
    section_02 = Region(grid, 0, [polygon_a, polygon_f], C35)

    def test_valid_ko(self):
        with self.assertRaises(ValueError):
            Region(self.grid, 0, [self.polygon_a, self.polygon_e], self.C35)

    def test1_valid_ok(self):
        self.assertIsNone(self.section_01.ensure_valid_section())

    def test1_centroid(self):
        expected = Point(3.3998, 3.8250)
        actual = self.section_01.centroid
        delta = expected.distance_to(actual)
        self.assertLess(delta, 0.0001)

    def test1_area(self):
        expected = 7.364
        actual = round(self.section_01.area, 4)
        self.assertEqual(expected, actual)

    def test1_first_moment_yo(self):
        expected = 28.167
        actual = round(self.section_01.first_moment_yo, 3)
        self.assertEqual(expected, actual)

    def test1_first_moment_zo(self):
        expected = 25.036
        actual = round(self.section_01.first_moment_zo, 3)
        self.assertEqual(expected, actual)

    def test1_moment_inertia_yo(self):
        expected = 111.9189
        actual = round(self.section_01.moment_inertia_yo, 4)
        self.assertEqual(expected, actual)

    def test1_moment_inertia_zo(self):
        expected = 93.5848
        actual = round(self.section_01.moment_inertia_zo, 4)
        self.assertEqual(expected, actual)

    def test1_product_inertia_yzo(self):
        expected = 98.8250
        actual = round(self.section_01.product_inertia_yzo, 4)
        self.assertEqual(expected, actual)

    def test1_moment_inertia_yg(self):
        expected = 4.18
        actual = round(self.section_01.moment_inertia_yg, 2)
        self.assertEqual(expected, actual)

    def test1_moment_inertia_zg(self):
        expected = 8.47
        actual = round(self.section_01.moment_inertia_zg, 2)
        self.assertEqual(expected, actual)

    def test1_alpha_rad(self):
        expected = round(27.51 * math.pi / 180, 4)
        actual = round(self.section_01.alpha_rad, 4)
        self.assertEqual(expected, actual)

    def test1_alpha_deg(self):
        expected = 27.51
        actual = round(self.section_01.alpha_deg, 2)
        self.assertEqual(expected, actual)

    def test1_moment_inertia_1(self):
        expected = 2.5854
        actual = round(self.section_01.moment_inertia_1, 4)
        self.assertEqual(expected, actual)

    def test1_moment_inertia_2(self):
        expected = 10.0648
        actual = round(self.section_01.moment_inertia_2, 4)
        self.assertEqual(expected, actual)

    def test2_valid_ok(self):
        self.assertIsNone(self.section_02.ensure_valid_section())

    def test2_centroid(self):
        expected = Point(3.4739, 3.5126)
        actual = self.section_02.centroid
        delta = expected.distance_to(actual)
        self.assertLess(delta, 0.0001)

    def test2_area(self):
        expected = 3.50
        actual = round(self.section_02.area, 4)
        self.assertEqual(expected, actual)

    def test2_first_moment_yo(self):
        expected = 12.294
        actual = round(self.section_02.first_moment_yo, 3)
        self.assertEqual(expected, actual)

    def test2_first_moment_zo(self):
        expected = 12.159
        actual = round(self.section_02.first_moment_zo, 3)
        self.assertEqual(expected, actual)

    def test2_moment_inertia_yo(self):
        expected = 45.6238
        actual = round(self.section_02.moment_inertia_yo, 4)
        self.assertEqual(expected, actual)

    def test2_moment_inertia_zo(self):
        expected = 48.2711
        actual = round(self.section_02.moment_inertia_zo, 4)
        self.assertEqual(expected, actual)

    def test2_product_inertia_yzo(self):
        expected = 45.1812
        actual = round(self.section_02.product_inertia_yzo, 4)
        self.assertEqual(expected, actual)

    def test2_moment_inertia_yg(self):
        expected = 2.44
        actual = round(self.section_02.moment_inertia_yg, 2)
        self.assertEqual(expected, actual)

    def test2_moment_inertia_zg(self):
        expected = 6.03
        actual = round(self.section_02.moment_inertia_zg, 2)
        self.assertEqual(expected, actual)

    def test2_alpha_rad(self):
        expected = round(27.0 * math.pi / 180, 4)
        actual = round(self.section_02.alpha_rad, 4)
        self.assertEqual(expected, actual)

    def test2_alpha_deg(self):
        expected = 27.0
        actual = round(self.section_02.alpha_deg, 4)
        self.assertEqual(expected, actual)

    def test2_moment_inertia_1(self):
        expected = 1.1801
        actual = round(self.section_02.moment_inertia_1, 4)
        self.assertEqual(expected, actual)

    def test2_moment_inertia_2(self):
        expected = 7.2917
        actual = round(self.section_02.moment_inertia_2, 4)
        self.assertEqual(expected, actual)
