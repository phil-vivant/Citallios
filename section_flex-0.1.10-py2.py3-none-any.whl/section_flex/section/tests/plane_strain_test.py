import unittest

from Omega_02_PV.geometry.point import Point
from Omega_02_PV.section.plane_of_deformation import PlaneOfDeformation


class TestPlaneStrain(unittest.TestCase):
    plane_strain_null = PlaneOfDeformation(0.0, 0.0, 0.0)
    plane_strain_1 = PlaneOfDeformation(-0.003746505, 0.004418862, -0.000818948)

    def test_ps_null_epsilon(self):
        expected = 0.0
        actual = self.plane_strain_null.strain_at_position(Point(0.05, 5.0))
        self.assertEqual(expected, actual)

    def test_ps_null_neutral_axis(self):
        expected = None
        actual = self.plane_strain_null.neutral_axis
        self.assertEqual(expected, actual)

    def test_ps_null_slope(self):
        expected = 0.0
        actual = self.plane_strain_null.slope
        self.assertEqual(expected, actual)

    def test_ps_null_y_intersect(self):
        expected = None
        actual = self.plane_strain_null.neutral_axis_y_intersect
        self.assertEqual(expected, actual)

    def test_ps_null_z_intersect(self):
        expected = None
        actual = self.plane_strain_null.neutral_axis_y_intersect
        self.assertEqual(expected, actual)

    def test_ps_01_epsilon(self):
        expected = 0.01839
        actual = round(self.plane_strain_1.strain_at_position(Point(0.05, 5.0)), 5)
        self.assertEqual(expected, actual)

    def test_ps_01_slope(self):
        expected = 0.004494
        actual = round(self.plane_strain_1.slope, 6)
        self.assertEqual(expected, actual)

    def test_ps_01_y_intersect(self):
        expected = 4.5748
        actual = round(self.plane_strain_1.neutral_axis_y_intersect.y, 4)
        self.assertEqual(expected, actual)

    def test_ps_01_z_intersect(self):
        expected = 0.8478
        actual = round(self.plane_strain_1.neutral_axis_z_intersect.z, 4)
        self.assertEqual(expected, actual)
