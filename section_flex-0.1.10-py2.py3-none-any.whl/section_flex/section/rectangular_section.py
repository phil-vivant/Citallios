# Standard library imports
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry.point import Point
from materia import EC2Concrete
from section_flex.section.fibre import Fibre
from section_flex.section.rebars import Rebars


@dataclass
class rectangular_section:
    """
    Class for a reinforced concrete rectangular section
    the parameter are:
        - b_width:                  the width of the rectangular section
        - h_height:                 the height of the rectangular section
        - concrete:                 concrete object
        - number_concrete_fibres:   vertical meshing of the section
    """
    b_width: float
    h_height: float
    concrete: EC2Concrete
    rebars_list: list[Fibre]
    number_concrete_fibres: int = 100

    def create_concrete_fibres(self):
        """
        Creates the concrete fibres for the section
        Returns a list of concrete fibres
        """
        acc = []
        for i in range(self.number_concrete_fibres):
            i += 1
            fibre_height = self.h_height / self.number_concrete_fibres
            fibre_area = self.b_width * fibre_height
            fibre_z = -1 * self.h_height / 2 + fibre_height * (i - 1/2)
            fibre_position = Point(0, fibre_z)
            fibre_name = f"concrete_fibre_#{i}"
            fibre_phase = 0
            fibre = Fibre(
                fibre_name,
                fibre_phase,
                fibre_position,
                fibre_area,
                self.concrete,
            )
            acc.append(fibre)
        return acc
               



C30 = EC2Concrete(30, 1.5, 2.0)
section_01 = rectangular_section(.5, 1, C30, [0])
conc_fibres = section_01.create_concrete_fibres()
