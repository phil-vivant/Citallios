# Standard library imports
import inspect
import math
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry.point import Point
from section_flex.geometry.vector import Vector
from section_flex.geometry.vectors import make_vector_between
from section_flex.geometry.segment import Segment
from section_flex.geometry.line import Line
from section_flex.geometry.nums import is_close_to_zero


@dataclass
class PlaneOfDeformation:

    epsilon_0: float
    omega_y: float
    omega_z: float

    @property
    def slope(self) -> float:
        return math.sqrt(self.omega_y ** 2 + self.omega_z ** 2)

    @property
    def __a(self) -> float:
        return - self.omega_z

    @property
    def __b(self) -> float:
        return self.omega_y

    @property
    def __c(self) -> float:
        return self.epsilon_0

    @property
    def neutral_axis_y_intersect(self) -> Point | None:
        if is_close_to_zero(self.__a):
            return None
        else:
            return Point(-self.__c / self.__a, 0)

    @property
    def neutral_axis_z_intersect(self) -> Point | None:
        if is_close_to_zero(self.__b):
            return None
        else:
            return Point(0, -self.__c / self.__b)

    @property
    def neutral_axis(self) -> Line | None:
        if is_close_to_zero(self.__a) and is_close_to_zero(self.__b):
            return None
        elif is_close_to_zero(self.__a):
            return Line(self.neutral_axis_z_intersect, Vector(1, 0))
        elif is_close_to_zero(self.__b):
            return Line(self.neutral_axis_y_intersect, Vector(0, 1))
        else:
            segment = Segment(self.neutral_axis_y_intersect, self.neutral_axis_z_intersect)
            return Line(self.neutral_axis_y_intersect, segment.direction_vector)

    @property
    def theta_radians(self) -> float:
        if self.omega_y == 0 and self.omega_z == 0:
            theta_0 = 0
        elif self.omega_y == 0:
            theta_0 = math.pi / 2
        else:
            theta_0 = math.atan(self.omega_z / self.omega_y)
        
        if theta_0 < -1e-9:
            return theta_0 + math.pi
        return theta_0

    @property
    def theta_degres(self) -> float:
        return self.theta_radians  * 180 / math.pi

    def strain_at_position(self, position: Point) -> float:
        """Returns the strain in the PlaneStrain for a given position

        Args:
            position (Point): position where the strain is calculated

        Returns:
            float: strain at position
        """
        return self.epsilon_0 + self.omega_y * position.z - self.omega_z * position.y

    def description(self) -> str:
        """Returns the description of the plane strain

        Returns:
            str: string with the description informations
        """

        description = "\nDescription du plan de déformation :\n"
        description += f"\tL'équation de l'axe neutre est de la forme : {self.__a:.6f}*y + {self.__b:.6f}*z + {self.__c:.6f} = 0\n"
        description  += f"\tLa pente des déformations est : {self.slope:.6f}.\n"

        if self.epsilon_0 > 0:
            description += f"\tLa section est soumise à un raccourcissement uniforme : {self.epsilon_0:.9f}.\n"
        elif self.epsilon_0 < 0:
            description += f"\tLa section est soumise à un allongement uniforme : {self.epsilon_0:.9f}.\n"

        if abs(self.omega_y) > 0.0000001:
            description  += f"\tLa courbure autour de l'axe y est : {self.omega_y:.9f}.\n"

        if abs(self.omega_z) > 0.0000001:
            description  += f"\tLa courbure autour de l'axe z est : {self.omega_z:.9f}.\n"

        if is_close_to_zero(self.__a):
            description  += f"\tL'axe neutre est parallèle à l'axe Y et a pour équation :\n"
            description  += f"\t\tz = {self.neutral_axis_z_intersect.z:.4f} m\n"
        elif is_close_to_zero(self.__b):
            description  += f"\tL'axe neutre est parallèle à l'axe Z et a pour équation :\n"
            description  += f"\t\ty = {self.neutral_axis_y_intersect.y:.4f} m\n"
        else:
            description  += f"\tL'axe neutre coupe\tl'axe Y en z = {self.neutral_axis_y_intersect.y:.9f} m\n"
            description  += f"\t\t\t     et l'axe Z en y = {self.neutral_axis_z_intersect.z:.9f} m\n"

        description  += f"\t({self.epsilon_0:.9f}, {self.omega_y:.9f}, {self.omega_z:.9f})"
        
        return description

    def __str__(self) -> str:
        # instance_name = [k for k, v in inspect.currentframe().f_back.f_locals.items() if v is self][0]
        result = f"Courbure :({self.epsilon_0:.9f}, {self.omega_y:.9f}, {self.omega_z:.9f})"
        return result

    def __eq__(self, other) -> bool:
        if self is other:
            return True
        if not isinstance(other, PlaneOfDeformation):
            return False
        test = 1
        test *= self.epsilon_0 == other.epsilon_0
        test *= self.omega_y == other.omega_y
        test *= self.omega_z == other.omega_z
        return test

    def __add__(self, other):
        epsilon_0 = self.epsilon_0 + other.epsilon_0
        omega_y = self.omega_y + other.omega_y
        omega_z = self.omega_z + other.omega_z
        return PlaneOfDeformation(epsilon_0, omega_y, omega_z)

    def __sub__(self, other):
        epsilon_0 = self.epsilon_0 - other.epsilon_0
        omega_y = self.omega_y - other.omega_y
        omega_z = self.omega_z - other.omega_z
        return PlaneOfDeformation(epsilon_0, omega_y, omega_z)

    def __mul__(self, factor: float):
        epsilon_0 = self.epsilon_0 * factor
        omega_y = self.omega_y * factor
        omega_z = self.omega_z * factor
        return PlaneOfDeformation(epsilon_0, omega_y, omega_z)
    
    def __truediv__(self, denom: float):
        epsilon_0 = self.epsilon_0 / denom
        omega_y = self.omega_y / denom
        omega_z = self.omega_z / denom
        return PlaneOfDeformation(epsilon_0, omega_y, omega_z)
