# Standard library imports
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry.point import Point


@dataclass
class Fibre:
    name: str
    position: Point
    area: float = 0.
    material: None = None
    initial_phase: int = 0

    def __post_init__(self):
        epsilon = []
        sigma = []
        force_x = []
        moment_y = []
        moment_z = []

    @property
    def first_moment_yo(self) -> float:
        """Calculates the fibre's first moment around the y0 axis.

        Returns:
            float: first moment around the y0 axis
        """
        return self.area * self.position.z

    @property
    def first_moment_zo(self) -> float:
        """Calculates the fibre's first moment around the z0 axis.

        Returns:
            float: first moment around the z0 axis
        """
        return self.area * self.position.y

    @property
    def moment_inertia_yo(self) -> float:
        """Calculates the fibre's moment of interia around the y0 axis.

        Returns:
            float: Moment of inertia around the y0 axis
        """
        return self.area * self.position.z ** 2

    @property
    def moment_inertia_zo(self) -> float:
        """Calculates the fibre's moment of interia around the z0 axis

        Returns:
            float: Moment of inertia around the z0 axis
        """
        return self.area * self.position.y ** 2

    @property
    def product_inertia_yzo(self) -> float:
        """Calculates the product of inertia in the yz0 coordinate system.

        Returns:
            float: Product of inertia in the yz0 coordinate system
        """
        return self.area * self.position.y * self.position.z

    def calculate_stress(self, epsilon: float) -> float:
        """Returns the stress in the fibre for a given strain.

        Args:
            epsilon (float): strain at the fibre position

        Returns:
            float: stress in the fibre material
        """
        return self.material.get_stress(epsilon)

    def calculate_force_x(self, stress: float) -> float:
        """Returns the normal force in the fibre

        Args:
            stress (float): Stress in the fibre

        Returns:
            float: normal force resultant in the fibre
        """
        return self.area * stress * 1000

    def calculate_moment_y(self, stress: float, moment_centroid: Point) -> float:
        """Returns the my bending moment of the fibre.

        Args:
            stress (float): Stress in the fibre

        Returns:
            float: bending moment my in the yz0 coordinate system
        """
        return self.area * stress * (self.position.z - moment_centroid.z) * 1000

    def calculate_moment_z(self, stress: float, moment_centroid: Point) -> float:
        """Returns the mz bending moment of the fibre

        Args:
            stress (float): Stress in the fibre

        Returns:
            float: bending moment mz in the yz0 coordinate system
        """
        return -1 * self.area * stress * (self.position.y - moment_centroid.y) * 1000

    def calculate_forces(self, strain: float, moment_centroid: Point) -> tuple[float]:
        """Calculates the fibre's internal forces.

        Args:
            strain (float): strain of the fibre
            moment_centroid (Point): base of reference for calculating the bending moments

        Returns:
            float: normal force nx
            float: bending moment my
            float: bending moment mz
            float: sigma (fibre's stress)
            float: epsilon (fibre's strain)
        """
        stress = self.calculate_stress(strain)
        n_x = self.calculate_force_x(stress)
        m_y = self.calculate_moment_y(stress, moment_centroid)
        m_z = self.calculate_moment_z(stress, moment_centroid)
        return n_x, m_y, m_z

    def check_data_length(self, phase) -> bool:
        return phase == len(self.epsilon) == len(self.sigma) == len(self.force_x) == len(self.moment_y) == len(self.moment_z)

    def calculate_phase(self, phase: int, strain: float, moment_centroid: Point) -> None:
        # Check data length
        if not self.check_data_length(phase):
            raise ValueError("Problem with phase or data length")

        # Complete the lists of datas according to phase
        if phase < self.initial_phase:
            self.epsilon.append(None)
            self.sigma.append(None)
            self.force_x.append(None)
            self.moment_y.append(None)
            self.moment_z.append(None)
        elif phase == self.initial_phase:
            self.epsilon.append(0)
            self.sigma.append(0)
            self.force_x.append(0)
            self.moment_y.append(0)
            self.moment_z.append(0)
        else:
            stress = self.calculate_stress(strain)
            n_x = self.calculate_force_x(stress)
            m_y = self.calculate_moment_y(stress, moment_centroid)
            m_z = self.calculate_moment_z(stress, moment_centroid)
            self.epsilon.append(strain)
            self.sigma.append(stress)
            self.force_x.append(n_x)
            self.moment_y.append(m_y)
            self.moment_z.append(m_z)
