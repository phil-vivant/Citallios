import unittest

from Omega_02_PV.solver.quadratic_equation import QuadraticEquation


class TestQuadraticEquation(unittest.TestCase):
    equation_01 = QuadraticEquation(2, -1, -6)
    equation_02 = QuadraticEquation(2, -3, 1.125)
    equation_03 = QuadraticEquation(1, 3, 10)

    def test_eq1_delta(self):
        expected = 49
        actual = round(self.equation_01.delta, 9)
        self.assertEqual(expected, actual)

    def test_eq2_delta(self):
        expected = 0
        actual = round(self.equation_02.delta, 9)
        self.assertEqual(expected, actual)

    def test_eq3_delta(self):
        expected = -31
        actual = round(self.equation_03.delta, 9)
        self.assertEqual(expected, actual)

    def test_eq1_racine_1(self):
        racines = self.equation_01.solve_quadratic()
        expected = -3/2
        actual = round(racines[0], 9)
        self.assertEqual(expected, actual)

    def test_eq1_racine_2(self):
        racines = self.equation_01.solve_quadratic()
        expected = 2
        actual = round(racines[1], 9)
        self.assertEqual(expected, actual)

    def test_eq2_racine(self):
        racines = self.equation_02.solve_quadratic()
        expected = [3/4]
        self.assertEqual(expected, racines)

    def test_eq3_racine(self):
        expected = []
        actual = self.equation_03.solve_quadratic()
        self.assertEqual(expected, actual)

