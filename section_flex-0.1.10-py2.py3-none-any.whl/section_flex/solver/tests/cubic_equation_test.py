import unittest

from Omega_02_PV.solver.cubic_equation import CubicEquation


class TestCubicEquation(unittest.TestCase):
    equation_01 = CubicEquation(4, -5, -23, 6)
    equation_02 = CubicEquation(1_000_000, -111_000, 1_110, -1)
    equation_03 = CubicEquation(1, 3, 5, 6)
    equation_04 = CubicEquation(1, 3, 3, 1)
    equation_05 = CubicEquation(2, 15, 24, -16)
    equation_06 = CubicEquation(4, -5, -23, 6)
    equation_07 = CubicEquation(100_000_000, 299_980_000, -59_999, 3)

    def test_vt(self):
        expected = round(5 / 12, 9)
        actual = round(self.equation_01.vt, 9)
        self.assertEqual(expected, actual)

    def test_p(self):
        expected = round(-301 / 48, 9)
        actual = round(self.equation_01.p, 9)
        self.assertEqual(expected, actual)

    def test_q(self):
        expected = round(-899 / 864, 9)
        actual = round(self.equation_01.q, 9)
        self.assertEqual(expected, actual)

    def test_delta(self):
        expected = round(-9075 / 1024, 7)
        actual = round(self.equation_01.delta, 7)
        self.assertEqual(expected, actual)

    def test_eq1_racine_1(self):
        racines = self.equation_01.solve_cubic()
        expected = 3
        actual = round(racines[0], 9)
        self.assertEqual(expected, actual)

    def test_eq1_racine_2(self):
        racines = self.equation_01.solve_cubic()
        expected = -2
        actual = round(racines[1], 9)
        self.assertEqual(expected, actual)

    def test_eq1_racine_3(self):
        racines = self.equation_01.solve_cubic()
        expected = 1/4
        actual = round(racines[2], 9)
        self.assertEqual(expected, actual)

    def test_eq2_racine_1(self):
        racines = self.equation_02.solve_cubic()
        expected = 1/10
        actual = round(racines[0], 9)
        self.assertEqual(expected, actual)

    def test_eq2_racine_2(self):
        racines = self.equation_02.solve_cubic()
        expected = 1/1000
        actual = round(racines[1], 9)
        self.assertEqual(expected, actual)

    def test_eq2_racine_3(self):
        racines = self.equation_02.solve_cubic()
        expected = 1/100
        actual = round(racines[2], 9)
        self.assertEqual(expected, actual)

    def test_eq3_racine(self):
        expected = -2
        actual = round(self.equation_03.solve_cubic(), 9)
        self.assertEqual(expected, actual)

    def test_eq4_racine_1(self):
        racines = self.equation_04.solve_cubic()
        expected = -1
        actual = round(racines[0], 9)
        self.assertEqual(expected, actual)

    def test_eq4_racine_2(self):
        racines = self.equation_04.solve_cubic()
        expected = -1
        actual = round(racines[1], 9)
        self.assertEqual(expected, actual)

    def test_eq4_racine_3(self):
        racines = self.equation_04.solve_cubic()
        expected = -1
        actual = round(racines[2], 9)
        self.assertEqual(expected, actual)

    def test_eq5_racine_1(self):
        racines = self.equation_05.solve_cubic()
        expected = 1/2
        actual = round(racines[0], 9)
        self.assertEqual(expected, actual)

    def test_eq5_racine_2(self):
        racines = self.equation_05.solve_cubic()
        expected = -4
        actual = round(racines[1], 9)
        self.assertEqual(expected, actual)

    def test_eq5_racine_3(self):
        racines = self.equation_05.solve_cubic()
        expected = -4
        actual = round(racines[2], 9)
        self.assertEqual(expected, actual)

    def test_eq6_racine_1(self):
        racines = self.equation_06.solve_cubic()
        expected = 3
        actual = round(racines[0], 9)
        self.assertEqual(expected, actual)

    def test_eq6_racine_2(self):
        racines = self.equation_06.solve_cubic()
        expected = -2
        actual = round(racines[1], 9)
        self.assertEqual(expected, actual)

    def test_eq6_racine_3(self):
        racines = self.equation_06.solve_cubic()
        expected = 1/4
        actual = round(racines[2], 9)
        self.assertEqual(expected, actual)

    def test_eq7_racine_1(self):
        racines = self.equation_07.solve_cubic()
        expected = 1/10_000
        actual = round(racines[0], 9)
        self.assertEqual(expected, actual)

    def test_eq7_racine_2(self):
        racines = self.equation_07.solve_cubic()
        expected = -3
        actual = round(racines[1], 9)
        self.assertEqual(expected, actual)

    def test_eq7_racine_3(self):
        racines = self.equation_07.solve_cubic()
        expected = 1/10_000
        actual = round(racines[2], 9)
        self.assertEqual(expected, actual)
