# Standard library imports
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry.nums import is_close_to_zero


@dataclass
class Tolerance:
    values: list[float]

    def _list_of_values(self):
        list_of_values = []
        for i in self.values:
            if not is_close_to_zero(i):
                list_of_values.append(i)
        if len(list_of_values) == 0:
            list_of_values.append(0.)
        return list_of_values

    @property
    def _small(self):
        return min(self._list_of_values())

    @property
    def _big(self):
        return max(self._list_of_values())

    @property
    def value(self):
        tol_calc = min(abs(self._small), abs(self._big)) / 10_000
        min_tol = 1 / 100
        return max(tol_calc, min_tol)

    def __str__(self):
        result = f"Tolérance prise en compte pour la convergence: {self.value:4f}"
        return result
