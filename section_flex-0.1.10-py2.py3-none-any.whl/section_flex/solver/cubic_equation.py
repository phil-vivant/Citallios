# Standard library imports
import math
from dataclasses import dataclass

# Third party imports

# Local applications imports


def sgn(x):
    return (x > 0) - (x < 0)


@dataclass
class CubicEquation:
    """
    Classe pour résoudre une équation cubique de la forme a.x^3 + b.x^2 + c.x + d = 0
    Renvoie une liste contenant les solutions réelles.
    """
    a: float
    b: float
    c: float
    d: float

    @property
    def vt(self) -> float:
        return round(-self.b / (3 * self.a), 14)

    @property
    def minus_vt(self) -> float:
        return -self.vt

    def _calculate_p(self) -> float:
        p = self.c / self.a - self.b ** 2 / (3 * self.a ** 2)
        return round(p, 14) if abs(p) >= 1e-14 else 0

    def _calculate_q(self) -> float:
        q = 2 * self.b ** 3 / (27 * self.a ** 3) + self.d / self.a - self.b * self.c / (3 * self.a ** 2)
        return round(q, 14) if abs(q) >= 1e-14 else 0

    def _calculate_delta(self) -> float:
        p = self._calculate_p()
        q = self._calculate_q()
        delta = q ** 2 / 4 + p ** 3 / 27
        return round(delta, 14) if abs(delta) >= 1e-14 else 0

    @property
    def p(self) -> float:
        return self._calculate_p()

    @property
    def q(self) -> float:
        return self._calculate_q()

    @property
    def delta(self) -> float:
        return self._calculate_delta()

    def _calculate_kos(self) -> float:
        p = self._calculate_p()
        if p == 0:
            return 0
        else:
            return round(-self.q / (2 * math.sqrt(-p ** 3 / 27)), 14)

    def _calculate_r(self) -> float:
        return round(math.sqrt(-self._calculate_p() / 3), 14)

    def _calculate_alpha(self) -> float:
        kos = self._calculate_kos()
        if kos == 1:
            return round(-math.pi * (kos - 1) / 2, 14)
        else:
            return round(math.acos(kos), 14)

    def uv(self, sg) -> float:
        r = math.sqrt(self.delta)
        z = -self.q / 2 + sg * r
        return round(sgn(z) * abs(z) ** (1 / 3), 14)

    def solve_cubic(self):
        x = [0, 0, 0]

        if self.delta <= 0:
            r = self._calculate_r()
            alpha = self._calculate_alpha()

            for k in range(3):
                xk = 2 * r * math.cos((alpha + 2 * math.pi * k) / 3) + self.vt
                x[k] = round(xk, 14)
            return x

        else:
            return round(self.uv(1) + self.uv(-1) + self.vt, 14)
