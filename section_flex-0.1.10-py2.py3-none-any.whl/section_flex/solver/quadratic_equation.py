# Standard library imports
import math
from dataclasses import dataclass

# Third party imports

# Local applications imports


@dataclass
class QuadraticEquation:
    """
    Classe pour résoudre une équation quadratique de la forme a.x^2 + b.x + c = 0
    Renvoie une liste vide lorsque le déterminant est négatif.
    """
    a: float
    b: float
    c: float

    def _calculate_delta(self) -> float:
        delta = self.b ** 2 - 4 * self.a * self.c
        return round(delta, 14) if abs(delta) >= 1e-14 else 0

    @property
    def delta(self) -> float:
        return self._calculate_delta()

    def solve_quadratic(self):
        solutions = []
        if self.delta < 0:
            return solutions
        elif self.delta == 0:
            solutions.append(-self.b / (2 * self.a))
            return solutions
        else:
            x1 = (-self.b - math.sqrt(self.delta)) / (2 * self.a)
            x2 = (-self.b + math.sqrt(self.delta)) / (2 * self.a)
            solutions.extend([x1, x2])
            return solutions
