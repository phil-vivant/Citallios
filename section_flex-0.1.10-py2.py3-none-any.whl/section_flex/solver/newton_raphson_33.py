# Standard library imports
from dataclasses import dataclass
from typing import Callable

# Third party imports
import numpy as np
from numpy.linalg import inv, det

# Local applications imports
from section_flex.geometry.nums import are_close_enough
from section_flex.solver.tolerance import Tolerance

# Delta à appliquer sur les racines
delta_1 = 0.000001
delta_2 = 0.000001
delta_3 = 0.000001

@dataclass
class NewtonRaphson33:
    function: Callable
    target_values: list[float]
    initial_guess: list[float] = (0.0, 0.0, 0.0)

    def __post_init__(self):
        self.ensure_valid_data()
        self.results = self.solve()

    def ensure_valid_data(self):
        if not self.target_values_length():
            raise ValueError(f"Need 3 values")

    def target_values_length(self) -> bool:
        return len(self.target_values) == 3 and len(self.initial_guess) == 3

    @property
    def tolerance(self) -> Tolerance:
        return Tolerance(self.target_values)

    @property
    def convergence(self) -> bool:
        return self.results[0]

    @property
    def number_of_iterations(self) -> int:
        return self.results[1]

    @property
    def final_roots(self) -> list[float]:
        return self.results[2]

    @property
    def final_targets(self) -> list[float]:
        return self.results[3]

    def operator_phi_33(self, variables: list[float]):
        if len(variables) != 3:
            raise ValueError('Need 3 values')
        variable_1 = variables[0]
        variable_2 = variables[1]
        variable_3 = variables[2]

        design_point_1 = self.function(variable_1 + delta_1, variable_2, variable_3)
        design_point_2 = self.function(variable_1 - delta_1, variable_2, variable_3)
        design_point_3 = self.function(variable_1, variable_2 + delta_2, variable_3)
        design_point_4 = self.function(variable_1, variable_2 - delta_2, variable_3)
        design_point_5 = self.function(variable_1, variable_2, variable_3 + delta_3)
        design_point_6 = self.function(variable_1, variable_2, variable_3 - delta_3)

        a11 = (design_point_1[0] - design_point_2[0]) / (2 * delta_1)
        a12 = (design_point_3[0] - design_point_4[0]) / (2 * delta_2)
        a13 = (design_point_5[0] - design_point_6[0]) / (2 * delta_3)

        a21 = (design_point_1[1] - design_point_2[1]) / (2 * delta_1)
        a22 = (design_point_3[1] - design_point_4[1]) / (2 * delta_2)
        a23 = (design_point_5[1] - design_point_6[1]) / (2 * delta_3)

        a31 = (design_point_1[2] - design_point_2[2]) / (2 * delta_1)
        a32 = (design_point_3[2] - design_point_4[2]) / (2 * delta_2)
        a33 = (design_point_5[2] - design_point_6[2]) / (2 * delta_3)

        operator = np.array([[a11, a12, a13],
                             [a21, a22, a23],
                             [a31, a32, a33]])

        return operator

    def solve(self):
        i = 0
        condition = 0
        calculated_values = 0
        tolerance_value = self.tolerance.value
        roots_i = self.initial_guess
        target_1 = self.target_values[0]
        target_2 = self.target_values[1]
        target_3 = self.target_values[2]
        matrix_roots_i = np.array([[roots_i[0]],
                                   [roots_i[1]],
                                   [roots_i[2]]])

        while i <= 20:
            i += 1
            root_1 = matrix_roots_i[0][0]
            root_2 = matrix_roots_i[1][0]
            root_3 = matrix_roots_i[2][0]

            calculated_values = self.function(root_1, root_2, root_3)
            calculated_value_1 = calculated_values[0]
            calculated_value_2 = calculated_values[1]
            calculated_value_3 = calculated_values[2]

            operator_phi = self.operator_phi_33([root_1, root_2, root_3])

            if det(operator_phi) == 0:
                break
            else:
                inverse_operator_phi = inv(operator_phi)

            matrix_result_i = np.array([[target_1 - calculated_value_1],
                                        [target_2 - calculated_value_2],
                                        [target_3 - calculated_value_3]])

            matrix_roots_i += + np.dot(inverse_operator_phi, matrix_result_i)

            condition_1 = are_close_enough(target_1, calculated_value_1, tolerance_value)
            condition_2 = are_close_enough(target_2, calculated_value_2, tolerance_value)
            condition_3 = are_close_enough(target_3, calculated_value_3, tolerance_value)

            condition = condition_1 * condition_2 * condition_3

            if condition == 1:
                break

        final_targets = calculated_values
        final_roots = (matrix_roots_i[0][0], matrix_roots_i[1][0], matrix_roots_i[2][0])

        if condition != 1:
            final_targets = [0.0, 0.0, 0.0]
            final_roots = [0.0, 0.0, 0.0]

        return condition, i, final_roots, final_targets

    def __str__(self):
        if self.convergence:
            result = f"Méthode de Newton-Raphson - 3 x 3:\n"
            result += f"\tL'équilibre est obtenu après {self.number_of_iterations} itérations.\n"
            result += f"\t{self.tolerance}\n"
            result += f"\tRappel des valeurs cibles:\n"
            result += f"\t\tValeur_01 :   {self.final_targets[0]:.1f}\n"
            result += f"\t\tValeur_02 :   {self.final_targets[1]:.1f}\n"
            result += f"\t\tValeur_03 :   {self.final_targets[2]:.1f}\n"
            result += f"\tDéfinition des racines:\n"
            result += f"\t\tRacine_01 :   {self.final_roots[0]:.9f}\n"
            result += f"\t\tRacine_02 :   {self.final_roots[1]:.9f}\n"
            result += f"\t\tRacine_03 :   {self.final_roots[2]:.9f}\n"
            return result
        else:
            result = "La section ne peut pas équilibrer le torseur de sollicitations !\n"
            return result
