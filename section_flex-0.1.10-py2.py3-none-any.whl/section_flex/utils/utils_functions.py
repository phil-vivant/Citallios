"""
Fonctions utilitaires pour le package section_flex.
"""

def signe(x: float) -> int:
    """Retourne le signe de la valeur x.

    -1 pour une valeur négative
    +1 pour une valeur positive

    Args:
        x (float): valeur à tester

    Returns:
        int: -1 ou +1.
    """
    return (x >= 0) - (x < 0)
