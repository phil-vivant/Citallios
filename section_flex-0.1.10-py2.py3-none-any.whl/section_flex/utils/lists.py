def list_of_zeros(length: int):
    return [0] * length


def list_of_list_of_zeros(rows: int, cols: int):
    return [list_of_zeros(cols) for _ in range(rows)]


def invert_list(liste_a_inverser):
    """
    Renvoie la liste en ordre inverse
    """
    liste_acc = []
    for element in reversed(liste_a_inverser):
        liste_acc.append(element)
    return liste_acc
