"""
Package pour le calcul de section béton.
"""

__version__ = "0.1.10"


from section_flex.section.concrete_section import ConcreteSection
