# Standard library imports
import math
import time

# Third party imports
from rich import print
import numpy as np

# Local applications imports
import materia
from geometry.circle import Circle
from geometry.point import Point
from geometry.polygon import Polygon
from geometry.vector import Vector
from materia import EC2Concrete, SteelRebar, FibreReinforcedPolymer
from section.concrete_section import ConcreteSection
from section.frp_strips import FRPStrips
from section.grid import Grid
from section.region import Region
from section.plane_of_deformation import PlaneOfDeformation
from section.rebars import Rebars
from section.frp_strips import FRPStrips
from section.create_section import create_circular_section, create_annular_section, create_concrete_section

start_time = time.time()

C12 = EC2Concrete(12, diagram_type="uls_parabola")
C30 = EC2Concrete(30, diagram_type="uls_parabola", alpha_cc=0.85)
B500B = SteelRebar()
B450C = SteelRebar(ductility_class="F", yield_strength_fyk=500)

# bw = 0.50
# hw = 0.40
# As = 3.14e-4
# es = 0.065

# point_a = Point(-bw/2, -hw/2)
# point_b = Point(bw/2, -hw/2)
# point_c = Point(bw/2, hw/2)
# point_d = Point(-bw/2, hw/2)
# pt_ha1 = Point(-bw/2 + es, -hw/2 + es)
# pt_ha2 = Point(bw/2 - es, -hw/2 + es)
# pt_ha3 = Point(bw/2 - es, hw/2 - es)
# pt_ha4 = Point(-bw/2 + es, hw/2 - es)
# rebar_As = Rebars(0, As * 3, B500B, [pt_ha1, pt_ha2], 1)
# rebar_As2 = Rebars(0, As / 2, B450C, [pt_ha3, pt_ha4], 3)

# point_a2 = Point(-1, hw/2)
# point_b2 = Point(1, hw/2)
# point_c2 = Point(1, hw/2 + 0.2)
# point_d2 = Point(-1, hw/2 + 0.2)

# poly1 = Polygon([point_a, point_b, point_c, point_d])
# poly2 = Polygon([point_a2, point_b2, point_c2, point_d2])
# reg1 = Region(0, [poly1], C30)
# reg2 = Region(0, [poly2], C12)
# R_section = ConcreteSection([reg1, reg2], [rebar_As, rebar_As2], [], 0.01, 0.01)

# R_section.plot_geometry_v2()
# R_section.plot_geometry_v3()

C_section = create_circular_section(
    concrete_material=C30,
    rebar_material=B500B,
    concrete_diameter=0.50,
    rebar_number=8,
    rebar_area=4.91e-4,
    rebar_cover=0.10
)
# C_section.plot_geometry_v2()

A_section = create_annular_section(
    concrete_material=C30,
    rebar_material=B500B,
    concrete_diameter=[0.5, 0.3],
    rebar_number=[8, 0],
    rebar_area=[4.91e-4, 0],
    rebar_cover=[0.10, 0.10]
)
# A_section.plot_geometry_v2()
# print(A_section.list_of_rebars)


# A_section.plot_interaction_diagram_v2(
#     theta=0,
#     finess=0,
#     zones=[1],
#     flat_head=False,
# )


R_section = create_concrete_section(
    concrete=C30,
    coffrage=[(-0.15, -0.3), (0.15, -0.3), (0.15, 0.3), (-0.15, 0.3)],
    steel=B500B,
    rebars={
        1: [1e-99, 0, 0.25],
        2: [1e-99, 0, -0.25]
    },
    frp_material=None,
    frp_strips=None,
)

print(R_section.Mrd_max(2500))
print(R_section.Mrd_min(2500))

R_section.plot_geometry_v2()

print(f"Temps de calculs : {time.time() - start_time: .2f} s")
