# Standard library imports
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry.point import Point


@dataclass
class GrossProperties:

    gross_area: float = 0.
    gross_centroid: Point = 0.
    gross_first_moment_yo: float = 0.
    gross_first_moment_zo: float = 0.
    gross_moment_inertia_yo: float = 0
    gross_moment_inertia_zo: float = 0
    gross_product_inertia_yzo: float = 0
    gross_moment_inertia_yg: float = 0
    gross_moment_inertia_zg: float = 0
    gross_product_inertia_yzg: float = 0
    gross_radius_gyration_y: float = 0
    gross_radius_gyration_z: float = 0
    gross_alpha_rad: float = 0
    gross_alpha_deg: float = 0
    gross_moment_inertia_1: float = 0
    gross_moment_inertia_2: float = 0
    gross_radius_gyration_1: float = 0
    gross_radius_gyration_2: float = 0

    e_area: float = 0
    e_centroid: Point = 0.
    e_first_moment_yo: float = 0
    e_first_moment_zo: float = 0
    e_moment_inertia_yo: float = 0
    e_moment_inertia_zo: float = 0
    e_product_inertia_yzo: float = 0
    e_moment_inertia_yg: float = 0
    e_moment_inertia_zg: float = 0
    e_product_inertia_yzg: float = 0
    e_radius_gyration_y: float = 0
    e_radius_gyration_z: float = 0
    e_alpha_rad: float = 0
    e_alpha_deg: float = 0
    e_moment_inertia_1: float = 0
    e_moment_inertia_2: float = 0
    e_radius_gyration_1: float = 0
    e_radius_gyration_2: float = 0
