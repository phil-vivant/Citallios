import random
import matplotlib.pyplot as plt
import numpy as np
from intersect import intersection
from math import tan
import math
from section_flex.utils.utils_functions import signe

def creation_points_axes(courbe_a_traiter: list[tuple[float, float]]) -> list[tuple[float, float]]:
    """création des point manquants placés sur l'axe des abscisses et des ordonnées.

    Les points sont ajoutés dans la courbe.

    Args:
        courbe_a_traiter (list[list[float]]): liste des points de la courbe

    Returns:
        abscisse_liste_final, ordonnee_liste_final: listes des abscisses et ordonnées complétée avec les points créés
    """

    x_min = min(point[0] for point in courbe_a_traiter)
    x_max = max(point[0] for point in courbe_a_traiter)
    y_min = min(point[1] for point in courbe_a_traiter)
    y_max = max(point[1] for point in courbe_a_traiter)

    abscisse_axe_x = [x_min,x_max]
    ordonnee_axe_x = [0,0]

    abscisse_axe_y = [0,0]
    ordonnee_axe_y = [y_min,y_max]

    acc = [(courbe_a_traiter[0][0], courbe_a_traiter[0][1])]

    length = len(courbe_a_traiter)
    for i in range(length - 1):
        segment_abscisse = (courbe_a_traiter[i][0], courbe_a_traiter[i+1][0])
        segment_ordonnee = (courbe_a_traiter[i][1], courbe_a_traiter[i+1][1])
        x1, y1 = intersection(segment_abscisse, segment_ordonnee, abscisse_axe_x, ordonnee_axe_x)
        x2, y2 = intersection(segment_abscisse, segment_ordonnee, abscisse_axe_y, ordonnee_axe_y)
        if len(x1) >= 1:
            acc.append((x1[0], 0))
        if len(y2) >= 1:
            acc.append((0, y2[0]))
        
        acc.append((courbe_a_traiter[i+1][0], courbe_a_traiter[i+1][1]))
    return acc


def filtre_zone_i(points: list[tuple[float, float]], zone: int) -> list[tuple[float, float]]:
    """Tri des points de la courbe en fonction des differentes zones.

    Args:
        points (list[tuple[float, float]]): Points décrivant la courbe
        zone (int): Zones filtres parmi [1, 2, 3, 4]

    Returns:
        list[tuple[float, float]]: Points décrivant la courbe filtrée
    """
    acc = []
    for point in points:
        if test_zone_i(point, zone):
            acc.append(point)
    return acc


def test_zone_1(coords: tuple[float, float]) -> bool:
    """Teste la présence du point de coordonnées coords dans la zone 1.

    Args:
        coords (tuple[float, float]): Coordonnées du point à tester

    Returns:
        bool: True si dans la zone.
    """
    return coords[1] >= 0 and coords[0] >= 0


def test_zone_2(coords: tuple[float, float]) -> bool:
    """Teste la présence du point de coordonnées coords dans la zone 2.

    Args:
        coords (tuple[float, float]): Coordonnées du point à tester

    Returns:
        bool: True si dans la zone.
    """
    return coords[1] <= 0 and coords[0] >= 0


def test_zone_3(coords: tuple[float, float]) -> bool:
    """Teste la présence du point de coordonnées coords dans la zone 3.

    Args:
        coords (tuple[float, float]): Coordonnées du point à tester

    Returns:
        bool: True si dans la zone.
    """
    return coords[1] <= 0 and coords[0] <= 0


def test_zone_4(coords: tuple[float, float]) -> bool:
    """Teste la présence du point de coordonnées coords dans la zone 4.

    Args:
        coords (tuple[float, float]): Coordonnées du point à tester

    Returns:
        bool: True si dans la zone.
    """
    return coords[1] >= 0 and coords[0] <= 0


def test_zone_i(coords: tuple[float, float], zone: int) -> bool:
    """Teste la présence du point de coordonnées coords dans la zone i.

    Args:
        coords (tuple[float, float]): Coordonnées du point à tester

    Returns:
        bool: True si dans la zone.
    """
    if zone == 1:
        return test_zone_1(coords)
    if zone == 2:
        return test_zone_2(coords)
    if zone == 3:
        return test_zone_3(coords)
    if zone == 4:
        return test_zone_4(coords)
    else:
        return None


def ordre_trigo(points: list[tuple[float, float]]) -> list[tuple[float, float]]:
    """Fonction qui remet les points dans l'ordre trigonométrique.
    Args:
        points (list[tuple[float, float]]): Liste des points pas placés dans le bon ordre

    Returns:
        list[tuple[float, float]]: Liste des points replacés dans le bon ordre
    """
    if not points:
        return None

    # Supprimer les doublons en utilisant un set
    points = list(set(points))
    
    # Calculer le centroïde (centre des points)
    centroid_x = 0
    centroid_y = 0
    
    # Fonction pour calculer l'angle par rapport au centroïde dans [0, 2*pi)
    def angle_from_centroid(point):
        angle = math.atan2(abs(point[1] - centroid_y), abs(point[0] - centroid_x))
        return angle
    
    # Générer une liste de tuples contenant le point et son angle
    points_with_angles = [(point, angle_from_centroid(point)) for point in points]
    
    # Trier les points par l'angle
    points_with_angles.sort(key=lambda x: x[1])
    
    # Extraire les points triés
    points_sorted = [point for point, angle in points_with_angles]
    
    return points_sorted


def filtre_inter_diag(
        courbe_brute: list[tuple[float, float]],
        zones: list[int] = [1, 2, 3, 4],
) -> list[list[tuple[float, float]]]:
    """Filtre de la courbe du diagramme d'interaction suivant les zones indiquées.

    Args:
        courbe_brute (list[tuple[float, float]]): Listing des points décrivant la courbe
        zones (list[int], optional): zones à tester. Defaults to [1, 2, 3, 4].

    Returns:
        list[list[tuple[float, float]]]: La courbe du diagramme d'interaction après filtre
    """
    courbe = creation_points_axes(courbe_brute)
    acc = []
    for zone in zones:
        acc.append(filtre_zone_i(courbe, zone))
    acc_ordered = []
    for curve in acc:
        acc_ordered.append(ordre_trigo(curve))
    return acc_ordered


def filtre_points(
        points: list[tuple[float, float]],
        zones: list[int] = [1, 2, 3, 4],
) -> list[list[tuple[float, float]]]:
    """Filtre des points suivant les zones indiquées.

    Args:
        points (list[tuple[float, float]]): Points à tester
        zones (list[int], optional): zones à tester. Defaults to [1, 2, 3, 4].

    Returns:
        list[list[tuple[float, float]]]: Les points après filtre
    """
    acc = []
    for point in points:
        for zone in zones:
            x = point[0]
            y = point[1]
            if test_zone_i((x, y), zone):
                acc.append((x, y))
    return acc


def plot_NM_interaction_diagram(
        mpsi_curves: list[list[tuple[float, float]]] | None = None,
        mksi_curves: list[list[tuple[float, float]]] | None = None,
        flat_head_curve: list[tuple[float, float]] | None = None,
        add_curves: list[list[tuple[float, float]]] | None = None,
        add_points: list[tuple[float, float]] | None = None,
        marker_pivots: list[tuple[float, float]] | None = None,
        plot_parameters: dict[str, str] | None = None,
) -> None:
    """Tracé du diagramme d'interaction.

    Args:
        mpsi_curves (list[list[tuple[float, float]]] | None, optional): Courbe N/M_psi. Defaults to None.
        mksi_curves (list[list[tuple[float, float]]] | None, optional): Courbe N/M_ksi. Defaults to None.
        flat_head_curve (list[tuple[float, float]] | None, optional): Diagramme étêté. Defaults to None.
        add_curves (list[list[tuple[float, float]]] | None, optional): Courbes complémentaires à représenter. Defaults to None.
        add_points (list[tuple[float, float]] | None, optional): Torseurs complémentaires à représenter. Defaults to None.
        marker_pivots (list[tuple[float, float]] | None, optional): Représentation des pivots. Defaults to None.
        plot_parameters (dict[str, str] | None, optional): Paramètres du tracé. Defaults to None.

    Returns:
        _type_: _description_
    """

    if plot_parameters is None:
        colors = ('C0', 'C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9')
        color_plot = random.choice(colors)
        x_label = ""
        y_label = ""
        psi_label = ""
        ksi_label = ""
        title = ""
    else:
        color_plot = plot_parameters['color_plot']
        x_label = plot_parameters['x_label']
        y_label = plot_parameters['y_label']
        psi_label = plot_parameters['psi_label']
        ksi_label = plot_parameters['ksi_label']
        title = plot_parameters['title']

    fig, ax = plt.subplots()

    # Tracé de la courbe N / M_psi (moment autour de l'axe neutre)
    n_min, n_max = math.inf, -math.inf
    m_min, m_max = math.inf, -math.inf
    if mpsi_curves is None:
        pass
    else:
        for curve in mpsi_curves:
            abs_1 = []
            ord_1 = []
            for point in curve:
                abs_1.append(point[1])
                ord_1.append(point[0])
            n_min = min(n_min, min(ord_1))
            n_max = max(n_max, max(ord_1))
            m_min = min(m_min, min(abs_1))
            m_max = max(m_max, max(abs_1))
            ax.plot(abs_1, ord_1, color=color_plot, label=psi_label)
            ax.fill_between(abs_1, ord_1, color=color_plot, alpha=0.3)

    # tracé de la courbe N / M_ksi (moment perpendiculaire à l'axe neutre)
    if mksi_curves is None:
        pass
    else:
        abs_2 = []
        ord_2 = []
        for curve in mksi_curves:
            for point in curve:
                abs_2.append(point[1])
                ord_2.append(point[0])
            ax.plot(abs_2, ord_2, color=color_plot, label=ksi_label, linestyle='dashed')

    # Étêtage du diagramme d'interaction
    if flat_head_curve is None:
        pass
    else:
        abs_3 = []
        ord_3 = []
        for curve in flat_head_curve:
            if curve != None:
                for point in curve:
                    abs_3.append(point[1])
                    ord_3.append(point[0])
                n_min = min(n_min, min(ord_3))
                n_max = max(n_max, max(ord_3))
                m_min = min(m_min, min(abs_3))
                m_max = max(m_max, max(abs_3))
        ax.plot(abs_3, ord_3, color=color_plot, linewidth=0.7)

    # Tracé des courbes complémentaires sur le diagramme
    if add_curves is None:
        pass
    else:
        for curve in add_curves:
            abs_4 = []
            ord_4 = []
            for point in curve:
                abs_4.append(point[1])
                ord_4.append(point[0])
            ax.plot(abs_4, ord_4, color="black", marker=".")

    # Tracé des torseurs complémentaires sur le diagramme d'interaction
    if add_points is None:
        pass
    else:
        for point in add_points:
            abs_5 = point[1]
            ord_5 = point[0]
            ax.plot(abs_5, ord_5, color="grey", linestyle='None', marker='X')

    # Représentation des pivots
    if marker_pivots is None:
        pass
    else:
        for pivot in marker_pivots:
            abs_6 = pivot[1]
            ord_6 = pivot[0]
            ax.plot(abs_6, ord_6, color=color_plot, linestyle='None', marker='o')

    # Tracé des axes
    abs_7 = (1.05 * m_min, 1.05 * m_max)
    ord_7 = (1.05 * n_min, 1.05 * n_max)
    ax.plot(abs_7, (0, 0), color="black", linewidth=1)
    ax.plot((0, 0), ord_7, color="black", linewidth=1)

    # ax.legend()
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.set_title(title)

    return None


