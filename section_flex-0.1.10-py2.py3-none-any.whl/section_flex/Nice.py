# Standard library imports
import math
import time

# Third party imports
from rich import print
import numpy as np

# Local applications imports
import materia
from geometry.circle import Circle
from geometry.point import Point
from geometry.polygon import Polygon
from geometry.vector import Vector
from materia import EC2Concrete, SteelRebar, FibreReinforcedPolymer
from section.concrete_section import ConcreteSection
from section.frp_strips import FRPStrips
from section.grid import Grid
from section.region import Region
from section.plane_of_deformation import PlaneOfDeformation
from section.rebars import Rebars
from section.frp_strips import FRPStrips
from section.create_section import create_circular_section, create_annular_section, create_concrete_section

start_time = time.time()

C25 = EC2Concrete(25, diagram_type="uls_parabola")
TFC = FibreReinforcedPolymer()
B500B = SteelRebar(gamma_s=1.15)

Lw = 5
bw = 0.25
As_sup = 8e-4
es_sup = 0.25
As_inf = 8e-4
es_inf = 0.25

Af = 2.5e-4
ef = 0.5

point_a = Point(-bw/2, -Lw/2)
point_b = Point(bw/2, -Lw/2)
point_c = Point(bw/2, Lw/2)
point_d = Point(-bw/2, Lw/2)
pt_ha_inf = Point(0, -Lw/2 + es_inf)
pt_ha_sup = Point(0, Lw/2 - es_sup)
pt_af_sup = Point(0, Lw/2 - ef)
pt_af_inf = Point(0, -Lw/2 + ef)
rebar_As_inf = Rebars(0, As_inf, B500B, [pt_ha_inf], 1)
rebar_As_sup = Rebars(0, As_sup, B500B, [pt_ha_sup], 2)
tfc_Af_inf = FRPStrips(0, Af, TFC, [pt_af_sup, pt_af_inf], 1)

poly1 = Polygon([point_a, point_b, point_c, point_d])
reg1 = Region(0, [poly1], C25)
Section_BA = ConcreteSection([reg1], [rebar_As_inf, rebar_As_sup], [], 0.125, 0.01)

Section_BA.plot_geometry_v2()
print(f"Mrd_max = {Section_BA.Mrd_max(0): .1f} kN.m")

pod = Section_BA.from_forces_to_curvature(1200, 2600, 0)
print(pod)

print(Section_BA.rebars_internal_state(pod))
print(Section_BA.concrete_internal_state(pod))

Section_BA.compressed_area(pod)
Section_BA.compression_force(pod)

print(Section_BA.Mrd_min())
print(Section_BA.Mrd_max())
