# Standard library imports
import math
import operator
from dataclasses import dataclass

# Third party imports
from functools import reduce
from typing import List

# Local applications imports
from section_flex.geometry.nums import are_close_enough, is_close_to_zero
from section_flex.geometry.geom_functions import principal_directions
from section_flex.geometry.point import Point
from section_flex.geometry.point3d import Point3D
from section_flex.geometry.vectors import make_vector_between
from section_flex.geometry.segment import Segment
from section_flex.geometry.triangle_oab import TriangleOAB
from section_flex.utils.pairs import make_round_pairs


@dataclass
class Tetrahedron:
    """
    """
    vertices: list[Point3D]


    def __post_init__(self):
        self.check_number_vertices()

    def check_number_vertices(self):
        return len(self.vertices) == 4

    @property
    def y_x(self):
        return 1 /4 * (sum(point.x for point in self.vertices))

    @property
    def y_c(self):
        return 1 /4 * (sum(point.y for point in self.vertices))

    @property
    def z_c(self):
        return 1 /4 * (sum(point.z for point in self.vertices))