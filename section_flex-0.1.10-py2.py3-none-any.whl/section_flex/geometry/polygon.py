# Standard library imports
import math
import operator
from dataclasses import dataclass

# Third party imports
from functools import reduce
from typing import List

# Local applications imports
from section_flex.geometry.nums import are_close_enough, is_close_to_zero
from section_flex.geometry.geom_functions import principal_directions
from section_flex.geometry.point import Point
from section_flex.geometry.vectors import make_vector_between
from section_flex.geometry.segment import Segment
from section_flex.geometry.triangle_oab import TriangleOAB
from section_flex.utils.pairs import make_round_pairs


@dataclass
class Polygon:
    """
    A polygon is a two-dimensional figure defined by a sequence of
    a minimum of three ordered and non-coincident vertices
    connected to form a closed polygonal chain.
    """
    vertices: list[Point]

    def __post_init__(self):
        self.geom_properties = self.geometric_properties()
        if len(self.vertices) < 3:
            raise ValueError('Need 3 or more vertices')

    @property
    def lower_boundary(self) -> Point:
        mini_y = min(vertex.y for vertex in self.vertices)
        mini_z = min(vertex.z for vertex in self.vertices)
        return Point(mini_y, mini_z)

    @property
    def upper_boundary(self) -> Point:
        maxi_y = max(vertex.y for vertex in self.vertices)
        maxi_z = max(vertex.z for vertex in self.vertices)
        return Point(maxi_y, maxi_z)

    @property
    def area(self) -> float:
        return self.geom_properties[0]

    @property
    def perimeter(self) -> float:
        perimeter = 0
        for side in self.sides():
            perimeter += side.length
        return perimeter

    @property
    def notional_size(self) -> float:
        return 2 * self.area / self.perimeter

    @property
    def centroid(self) -> Point:
        return Point(
            self.geom_properties[1],
            self.geom_properties[2],
        )

    @property
    def first_moment_yo(self) -> float:
        return self.geom_properties[3]

    @property
    def first_moment_zo(self) -> float:
        return self.geom_properties[4]

    @property
    def moment_inertia_yo(self) -> float:
        return self.geom_properties[5]

    @property
    def moment_inertia_zo(self) -> float:
        return self.geom_properties[6]

    @property
    def product_inertia_yzo(self) -> float:
        return self.geom_properties[7]

    @property
    def moment_inertia_yg(self) -> float:
        return self.moment_inertia_yo - self.area * self.centroid.z ** 2

    @property
    def moment_inertia_zg(self) -> float:
        return self.moment_inertia_zo - self.area * self.centroid.y ** 2

    @property
    def product_inertia_yzg(self) -> float:
        inertia_yzg = self.product_inertia_yzo - self.area * self.centroid.y * self.centroid.z
        if is_close_to_zero(inertia_yzg):
            return 0.0
        else:
            return inertia_yzg

    @property
    def alpha_rad(self) -> float:
        return principal_directions(self.moment_inertia_yg, self.moment_inertia_zg, self.product_inertia_yzg)[0]

    @property
    def alpha_deg(self) -> float:
        return self.alpha_rad * 180 / math.pi

    @property
    def moment_inertia_1(self) -> float:
        return principal_directions(self.moment_inertia_yg, self.moment_inertia_zg, self.product_inertia_yzg)[1]

    @property
    def moment_inertia_2(self) -> float:
        return principal_directions(self.moment_inertia_yg, self.moment_inertia_zg, self.product_inertia_yzg)[2]

    def sides(self) -> list[Segment]:
        """
        Returns a list of the sides of the polygon. A side is a
        segment connecting two consecutive vertices.

        :return: list of sides
        """
        vertex_pairs = make_round_pairs(self.vertices)
        return [
            Segment(pair[0], pair[1])
            for pair in vertex_pairs
        ]

    def contains_point(self, point: Point) -> bool:
        """
        Tests whether the polygon contains the given point.

        :param point: `Point`
        :return: `bool` contains point?
        """
        if point in self.vertices:
            return True

        vecs = [make_vector_between(point, vertex)
                for vertex in self.vertices]
        paired_vecs = make_round_pairs(vecs)
        angle_sum = reduce(
            operator.add,
            [v1.angle_to(v2) for v1, v2 in paired_vecs]
        )

        return are_close_enough(angle_sum, 2 * math.pi)

    def contains_polygon(self, other) -> bool:
        if self == other:
            return False
        for vertex in other.vertices:
            if not self.contains_point(vertex):
                return False
        return True

    def is_inside_polygon(self, other) -> bool:
        if self == other:
            return False
        for vertex in self.vertices:
            if not other.contains_point(vertex):
                return False
        return True

    def overlaps_with_polygon(self, other) -> bool:
        """
        return False if contains or is_inside is true
        return False if the two polygons do not overlap
        otherwise, return True
        @param other: 2 polygons
        @return: boolean
        """

        if self.contains_polygon(other) or self.is_inside_polygon(other):
            return False

        count_1 = 0
        count_2 = 0
        for vertex in other.vertices:
            if self.contains_point(vertex):
                count_1 += 1
                for side in self.sides():
                    if is_close_to_zero(side.distance_to(vertex)):
                        count_1 -= 1
        if 0 < count_1 < len(self.vertices):
            return True
        else:
            for vertex in self.vertices:
                if other.contains_point(vertex):
                    count_2 += 1
                    for side in other.sides():
                        if is_close_to_zero(side.distance_to(vertex)):
                            count_2 -= 1
            if 0 < count_2 < len(other.vertices):
                return True
            else:
                return False

    def geometric_properties(self) -> list[float]:
        vertex_pairs = make_round_pairs(self.vertices)
        area = 0
        first_moment_yo = 0
        first_moment_zo = 0
        moment_inertia_yo = 0
        moment_inertia_zo = 0
        product_inertia_yzo = 0

        for pair in vertex_pairs:
            triangle_oab = TriangleOAB(pair[0], pair[1])
            area += triangle_oab.area
            first_moment_yo += triangle_oab.first_moment_yo
            first_moment_zo += triangle_oab.first_moment_zo
            moment_inertia_yo += triangle_oab.moment_inertia_yo
            moment_inertia_zo += triangle_oab.moment_inertia_zo
            product_inertia_yzo += triangle_oab.product_inertia_yzo

        centroid_y = first_moment_zo / area
        centroid_z = first_moment_yo / area

        return [
            area,
            centroid_y,
            centroid_z,
            first_moment_yo,
            first_moment_zo,
            moment_inertia_yo,
            moment_inertia_zo,
            product_inertia_yzo
        ]

    def __eq__(self, other) -> bool:
        """
        Two polygons are considered equal if they have the same
        vertices in the same order.

        :param other: `Polygon`
        :return: `bool` are polygons equal?
        """
        if self is other:
            return True

        if not isinstance(other, Polygon):
            return False

        return self.vertices == other.vertices

    def __str__(self) -> str:
        vertices_str = ', '.join(str(vertex) for vertex in self.vertices)
        return f'Polygon made from points: [{vertices_str}]'
