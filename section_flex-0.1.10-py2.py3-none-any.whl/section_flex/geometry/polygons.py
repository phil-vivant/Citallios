# Standard library imports
from typing import List

# Third party imports

# Local applications imports
from section_flex.geometry import Point, Polygon


def make_polygon_from_coords(coords: List[float]) -> Polygon:
    """
    Creates a `Polygon` instance using the passed in coordinates:
    `[y1 z1 y2 z2 ... yn zn]`.

    It raises a `ValueError` if the coordinates list doesn't have
    an even number of entries.

    :param coords: list of the coordinates of the vertices
    :return: `Polygon`
    """
    if len(coords) % 2 != 0:
        raise ValueError('Need an even number of coordinates')

    indices = range(0, len(coords), 2)
    return Polygon(
        [Point(coords[i], coords[i + 1]) for i in indices]
    )


def make_polygon_from_points(points: list[Point]) -> Polygon:
    """
    Creates a `Polygon` instance using the passed in coordinates:
    `[[y1, z1], [y2, z2] ... [yn, zn]]`.

    :param points: list of the points
    :return: `Polygon`
    """
    return Polygon(
        [point for point in points]
    )


def get_reversed(polygon: Polygon) -> Polygon:
    reversed_points = list(reversed(polygon.vertices))
    reversed_polygon = Polygon(reversed_points)
    return reversed_polygon


def is_clockwise(vertices: list[Point]) -> bool:
    __sum = 0
    for i, p in enumerate(vertices):
        j = i + 1 if i != len(vertices) - 1 else 0
        __sum += (vertices[j].x - p.x) * (vertices[j].y + p.y)
    return __sum < 0
