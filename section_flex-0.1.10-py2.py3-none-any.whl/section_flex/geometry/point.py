# Standard library imports
import math
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry import nums
from section_flex.geometry.vector import Vector


@dataclass
class Point:
    """
    Point is a position in the 2D plane, defined by its two
    coordinates: `y` and `z`.
    """
    y: float
    z: float

    def __add__(self, other):
        """
        Creates a `Point` result of adding the coordinates of this
        point and `other`.

        This operation doesn't make a lot of algebraic sense, but
        it will be useful for some operations.

        :param other: `Point`
        :return: `Point` sum of `self` and `other`
        """
        return Point(
            self.y + other.y,
            self.z + other.z
        )

    def __sub__(self, other):
        """
        Creates a `Vector` going from `other` to `self`.

        :param other: `Point`
        :return: `Vector`: `other` -> `self`
        """
        return Vector(
            self.y - other.y,
            self.z - other.z
        )

    def distance_to(self, other) -> float:
        """
        Computes the distance from this point to `other`.

        :param other: `Point`
        :return: `float` = distance(this, other)
        """
        delta_y = other.y - self.y
        delta_z = other.z - self.z
        return math.sqrt(delta_y ** 2 + delta_z ** 2)

    def displaced(self, vector: Vector, times: float = 1):
        """
        Creates a new `Point` result of displacing this one the
        given `vector` and number of times `times`.

        :param vector: displacement `Vector`
        :param times: times the displacement vector is applied
        :return: `Point`
        """
        scaled_vec = vector.scaled_by(times)
        return Point(
            self.y + scaled_vec.u,
            self.z + scaled_vec.v
        )

    def __eq__(self, other) -> bool:
        """
        Two points are equal if their coordinates are equal (or
        close enough).

        :param other: `Point`
        :return: are the points equal?
        """
        if self is other:
            return True

        if not isinstance(other, Point):
            return False

        return nums.are_close_enough(self.y, other.y) and nums.are_close_enough(self.z, other.z)

    def __str__(self) -> str:
        return f'({self.y}, {self.z})'

    def to_formatted_str(self, decimals: int) -> str:
        """
        Returns a string including the coordinates of the point
        rounded to the given number of decimals.

        :param decimals: number of decimals
        :return: `string` representation of the point
        """
        y = round(self.y, decimals)
        z = round(self.z, decimals)

        return f'({y}, {z})'
