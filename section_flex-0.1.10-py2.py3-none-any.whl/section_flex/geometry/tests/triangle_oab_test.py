import unittest

from Omega_02_PV.geometry.triangle_oab import TriangleOAB
from Omega_02_PV.geometry.point import Point


class TestTriangleOAB(unittest.TestCase):
    triangle_oab = TriangleOAB(Point(2.0, 0.0), Point(2.0, 2.0))

    def test_area(self):
        expected = 2.0
        actual = self.triangle_oab.area
        self.assertEqual(expected, actual)

    def test_first_moment_yo(self):
        expected = 4/3
        actual = self.triangle_oab.first_moment_yo
        self.assertEqual(expected, actual)

    def test_first_moment_zo(self):
        expected = 8/3
        actual = self.triangle_oab.first_moment_zo
        self.assertEqual(expected, actual)

    def test_moment_inertia_yo(self):
        expected = 4/3
        actual = self.triangle_oab.moment_inertia_yo
        self.assertEqual(expected, actual)

    def test_moment_inertia_zo(self):
        expected = 4.0
        actual = self.triangle_oab.moment_inertia_zo
        self.assertEqual(expected, actual)

    def test_product_inertia_yzo(self):
        expected = 2.0
        actual = self.triangle_oab.product_inertia_yzo
        self.assertEqual(expected, actual)

    def test_centroid_yo(self):
        expected = 4/3
        actual = self.triangle_oab.centroid_yo
        self.assertEqual(expected, actual)

    def test_centroid_zo(self):
        expected = 2/3
        actual = self.triangle_oab.centroid_zo
        self.assertEqual(expected, actual)
