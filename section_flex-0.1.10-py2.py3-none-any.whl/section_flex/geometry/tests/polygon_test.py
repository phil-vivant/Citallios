import unittest

import math

from Omega_02_PV.geometry.point import Point
from Omega_02_PV.geometry.polygon import Polygon
from Omega_02_PV.geometry.segment import Segment


class TestPolygon(unittest.TestCase):
    # rectangle size  4.0 x 2.0 - origin (2.0, 2.0) - Rotation +27°
    vertices_a = [
        Point(2.0, 2.0),
        Point(5.56402609675347, 3.81596199895819),
        Point(4.65604509727438, 5.59797504733492),
        Point(1.09201900052091, 3.78201304837674)
    ]
    vertices_b = [
        Point(2.0, 3.0),
        Point(3.0, 3.0),
        Point(3.0, 4.0),
        Point(2.0, 4.0)
    ]
    vertices_c = [
        Point(4.0, 3.0),
        Point(5.0, 3.0),
        Point(5.0, 4.0),
        Point(4.0, 4.0)
    ]
    polygon_a = Polygon(vertices_a)
    polygon_b = Polygon(vertices_b)
    polygon_c = Polygon(vertices_c)

    def test_sides(self):
        expected = [
            Segment(self.vertices_a[0], self.vertices_a[1]),
            Segment(self.vertices_a[1], self.vertices_a[2]),
            Segment(self.vertices_a[2], self.vertices_a[3]),
            Segment(self.vertices_a[3], self.vertices_a[0])
        ]
        actual = self.polygon_a.sides()
        self.assertEqual(expected, actual)

    def test_centroid(self):
        expected = Point(3.32802, 3.79899)
        actual = self.polygon_a.centroid
        delta = expected.distance_to(actual)
        self.assertLess(delta, 0.00001)

    def test_doesnt_contain_point(self):
        point = Point(15, 20)
        self.assertFalse(self.polygon_a.contains_point(point))

    def test_contains_point(self):
        point = Point(3, 3)
        self.assertTrue(self.polygon_a.contains_point(point))

    def test_contains_vertex(self):
        self.assertTrue(
            self.polygon_a.contains_point(self.vertices_a[0])
        )

    def test_area(self):
        expected = 8.0
        actual = round(self.polygon_a.area, 4)
        self.assertEqual(expected, actual)

    def test_perimeter(self):
        expected = 12.0
        actual = round(self.polygon_a.perimeter, 4)
        self.assertEqual(expected, actual)

    def test_notional_size(self):
        expected = round(2 * 8.0 / 12.0, 4)
        actual = round(self.polygon_a.notional_size, 4)
        self.assertEqual(expected, actual)

    def test_first_moment_yo(self):
        expected = 30.392
        actual = round(self.polygon_a.first_moment_yo, 3)
        self.assertEqual(expected, actual)

    def test_first_moment_zo(self):
        expected = 26.624
        actual = round(self.polygon_a.first_moment_zo, 3)
        self.assertEqual(expected, actual)

    def test_moment_inertia_yo(self):
        expected = 119.774
        actual = round(self.polygon_a.moment_inertia_yo, 3)
        self.assertEqual(expected, actual)

    def test_moment_inertia_zo(self):
        expected = 97.624
        actual = round(self.polygon_a.moment_inertia_zo, 3)
        self.assertEqual(expected, actual)

    def test_product_inertia_yzo(self):
        expected = 104.381
        actual = round(self.polygon_a.product_inertia_yzo, 3)
        self.assertEqual(expected, actual)

    def test_moment_inertia_yg(self):
        expected = 4.316
        actual = round(self.polygon_a.moment_inertia_yg, 3)
        self.assertEqual(expected, actual)

    def test_moment_inertia_zg(self):
        expected = 9.018
        actual = round(self.polygon_a.moment_inertia_zg, 3)
        self.assertEqual(expected, actual)

    def test_product_inertia_yzg(self):
        expected = 3.236
        actual = round(self.polygon_a.product_inertia_yzg, 3)
        self.assertEqual(expected, actual)

    def test_alpha_rad(self):
        expected = round(27.0 * math.pi / 180, 4)
        actual = round(self.polygon_a.alpha_rad, 4)
        self.assertEqual(expected, actual)

    def test_alpha_deg(self):
        expected = 27.0
        actual = round(self.polygon_a.alpha_deg, 4)
        self.assertEqual(expected, actual)

    def test_moment_inertia_1(self):
        expected = 2.6667
        actual = round(self.polygon_a.moment_inertia_1, 4)
        self.assertEqual(expected, actual)

    def test_moment_inertia_2(self):
        expected = 10.6667
        actual = round(self.polygon_a.moment_inertia_2, 4)
        self.assertEqual(expected, actual)

    def test_is_inside_polygon_true(self):
        self.assertTrue(self.polygon_b.is_inside_polygon(self.polygon_a))

    def test_is_inside_polygon_false_01(self):
        self.assertFalse(self.polygon_c.is_inside_polygon(self.polygon_a))

    def test_is_inside_polygon_false_02(self):
        self.assertFalse(self.polygon_c.is_inside_polygon(self.polygon_a))

    def test_is_inside_polygon_false_03(self):
        self.assertFalse(self.polygon_b.is_inside_polygon(self.polygon_c))

    def test_contains_polygon_true(self):
        self.assertTrue(self.polygon_a.contains_polygon(self.polygon_b))

    def test_contains_polygon_false_01(self):
        self.assertFalse(self.polygon_a.contains_polygon(self.polygon_c))

    def test_contains_polygon_false_02(self):
        self.assertFalse(self.polygon_b.contains_polygon(self.polygon_c))

    def test_overlap_true_01(self):
        self.assertTrue(self.polygon_a.overlaps_with_polygon(self.polygon_c))

    def test_overlap_true_02(self):
        self.assertTrue(self.polygon_c.overlaps_with_polygon(self.polygon_a))

    def test_overlap_false_01(self):
        self.assertFalse(self.polygon_a.overlaps_with_polygon(self.polygon_b))

    def test_overlap_false_02(self):
        self.assertFalse(self.polygon_b.overlaps_with_polygon(self.polygon_c))
