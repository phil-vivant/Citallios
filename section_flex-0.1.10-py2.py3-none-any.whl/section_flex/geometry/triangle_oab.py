# Standard library imports
from dataclasses import dataclass

# Third party imports

# Local applications imports
from section_flex.geometry.point import Point


@dataclass
class TriangleOAB:
    """
    """
    point_a: Point
    point_b: Point

    @property
    def area(self):
        return 1 / 2 * (self.point_a.y * self.point_b.z - self.point_a.z * self.point_b.y)

    @property
    def first_moment_yo(self):
        return self.area / 3 * (self.point_a.z + self.point_b.z)

    @property
    def first_moment_zo(self):
        return self.area / 3 * (self.point_a.y + self.point_b.y)

    @property
    def moment_inertia_yo(self):
        inertia_yo = self.area / 6 * (self.point_a.z ** 2 + self.point_b.z ** 2 + self.point_a.z * self.point_b.z)
        return inertia_yo

    @property
    def moment_inertia_zo(self):
        inertia_zo = self.area / 6 * (self.point_a.y ** 2 + self.point_b.y ** 2 + self.point_a.y * self.point_b.y)
        return inertia_zo

    @property
    def product_inertia_yzo(self):
        product_inertia = self.area * ((self.point_a.y * self.point_a.z + self.point_b.y * self.point_b.z) / 6
                                       + (self.point_a.y * self.point_b.z + self.point_b.y * self.point_a.z) / 12)
        return product_inertia

    @property
    def centroid_yo(self):
        if self.area == 0:
            return None
        else:
            return self.first_moment_zo / self.area

    @property
    def centroid_zo(self):
        if self.area == 0:
            return None
        else:
            return self.first_moment_yo / self.area
