# Standard library imports
import math

# Third party imports

# Local applications imports
from section_flex.geometry.nums import is_close_to_zero


def principal_directions(
        moment_inertia_yg: float,
        moment_inertia_zg: float,
        product_inertia_yzg: float,
) -> tuple[float, float, float]:
    """
    Calcul l'orientation des directions principales et les propriétés géométriques associées
     à partir des moments d'inertie calculés dans le repère Gyz (M_yg, M_zg, M_yzg)
    Args:
        moment_inertia_yg: Moment d'inertie autour de l'axe g_y
        moment_inertia_zg: Moment d'inertie autour de l'axe g_z
        product_inertia_yzg: Produit d'inertie M_yzg

    Returns:
        alpha_rad: inclinaison de l'axe principal 1 par rapport à y en radions
        inertia_1: Moment d'inertie principal autour de l'axe 1
        inertia_2: Moment d'inertie principal autour de l'axe 2

    """
    a1 = moment_inertia_yg
    a2 = moment_inertia_zg
    b = - product_inertia_yzg
    pi = math.pi

    d = a1 - a2

    if is_close_to_zero(b):
        phi_rad = 0
    else:
        if is_close_to_zero(d):
            phi_rad = pi / 2
        else:
            phi_rad = math.atan(2.0 * b / d)

    if phi_rad < - pi / 2:
        alpha2_rad = phi_rad + pi
    elif phi_rad > pi / 2:
        alpha2_rad = phi_rad - pi
    else:
        alpha2_rad = phi_rad

    alpha_rad = alpha2_rad / 2

    # Values
    if d > 0:
        sign = 1.0
    else:
        sign = -1.0
    h_sum = 1 / 2 * (a1 + a2)
    h_root = 1 / 2 * math.sqrt(d ** 2 + 4 * b ** 2)

    # I1 = a1_star & I2 = a2_star
    inertia_1 = h_sum + sign * h_root
    inertia_2 = h_sum - sign * h_root

    return alpha_rad, inertia_1, inertia_2
