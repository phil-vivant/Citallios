from section.create_section import create_concrete_section
from materia import EC2Concrete, SteelRebar, FibreReinforcedPolymer
import materia

C30 = EC2Concrete(30)
B500B = SteelRebar()
TFC = materia.TFC_350

cof = [(0, 0), (0.3, 0), (0.3, 0.6), (0.8, 0.6), (0.8, 0.8), (-0.5, 0.8), (-0.5, 0.6), (0, 0.6)]
rebars = {
    1: [0.0004, 0.1, 0.1],
    2: [0.0004, 0.2, 0.1],
    3: [0.0001, 0.1, 0.7],
    4: [0.0001, 0.2, 0.7],
}
frp_strips = {
    1: [0.00005, 0.15, 0.0],
}

rect_section = create_concrete_section(C30, cof, B500B, rebars, TFC, frp_strips)

rect_section.plot_geometry()
rect_section.plot_NM_interaction_diagram(0, 1)

print(rect_section.Mrd_max(0))
print(rect_section.Nrd_min)
print(rect_section.Nrd_max)
